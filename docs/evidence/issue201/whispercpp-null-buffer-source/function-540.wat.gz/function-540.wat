 (func $481 (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 i32)
  (block $block13
   (block $block1
    (block $block
     (br_if $block
      (i32.ne
       (local.tee $3
        (i32.load offset=36
         (local.get $0)
        )
       )
       (i32.load offset=4
        (local.get $1)
       )
      )
     )
     (br_if $block
      (i32.ne
       (i32.load offset=44
        (local.get $0)
       )
       (i32.load offset=8
        (local.get $1)
       )
      )
     )
     (br_if $block1
      (i32.le_s
       (local.get $3)
       (i32.const 0)
      )
     )
     (loop $label
      (local.set $3
       (i32.add
        (i32.load offset=32
         (local.get $0)
        )
        (i32.mul
         (local.get $2)
         (i32.const 176)
        )
       )
      )
      (block $block2
       (br_if $block2
        (i32.load offset=176
         (local.tee $4
          (i32.load
           (i32.add
            (i32.load offset=12
             (local.get $1)
            )
            (i32.shl
             (local.get $2)
             (i32.const 2)
            )
           )
          )
         )
        )
       )
       (br_if $block2
        (i32.load offset=168
         (local.get $4)
        )
       )
       (br_if $block
        (i32.lt_s
         (local.tee $5
          (i32.load
           (local.get $3)
          )
         )
         (i32.const 0)
        )
       )
       (br_if $block
        (i32.gt_u
         (call $58
          (i32.load
           (i32.add
            (i32.load
             (local.get $0)
            )
            (i32.shl
             (local.get $5)
             (i32.const 2)
            )
           )
          )
          (local.get $4)
         )
         (i32.load offset=12
          (local.get $3)
         )
        )
       )
      )
      (block $block3
       (br_if $block3
        (i32.eqz
         (local.tee $5
          (i32.load offset=128
           (local.get $4)
          )
         )
        )
       )
       (br_if $block3
        (i32.load offset=176
         (local.get $5)
        )
       )
       (br_if $block3
        (i32.load offset=168
         (local.get $5)
        )
       )
       (br_if $block
        (i32.lt_s
         (local.tee $6
          (i32.load offset=16
           (local.get $3)
          )
         )
         (i32.const 0)
        )
       )
       (br_if $block
        (i32.gt_u
         (call $58
          (i32.load
           (i32.add
            (i32.load
             (local.get $0)
            )
            (i32.shl
             (local.get $6)
             (i32.const 2)
            )
           )
          )
          (local.get $5)
         )
         (i32.load offset=28
          (local.get $3)
         )
        )
       )
      )
      (block $block4
       (br_if $block4
        (i32.eqz
         (local.tee $5
          (i32.load offset=132
           (local.get $4)
          )
         )
        )
       )
       (br_if $block4
        (i32.load offset=176
         (local.get $5)
        )
       )
       (br_if $block4
        (i32.load offset=168
         (local.get $5)
        )
       )
       (br_if $block
        (i32.lt_s
         (local.tee $6
          (i32.load offset=32
           (local.get $3)
          )
         )
         (i32.const 0)
        )
       )
       (br_if $block
        (i32.gt_u
         (call $58
          (i32.load
           (i32.add
            (i32.load
             (local.get $0)
            )
            (i32.shl
             (local.get $6)
             (i32.const 2)
            )
           )
          )
          (local.get $5)
         )
         (i32.load offset=44
          (local.get $3)
         )
        )
       )
      )
      (block $block5
       (br_if $block5
        (i32.eqz
         (local.tee $5
          (i32.load offset=136
           (local.get $4)
          )
         )
        )
       )
       (br_if $block5
        (i32.load offset=176
         (local.get $5)
        )
       )
       (br_if $block5
        (i32.load offset=168
         (local.get $5)
        )
       )
       (br_if $block
        (i32.lt_s
         (local.tee $6
          (i32.load offset=48
           (local.get $3)
          )
         )
         (i32.const 0)
        )
       )
       (br_if $block
        (i32.gt_u
         (call $58
          (i32.load
           (i32.add
            (i32.load
             (local.get $0)
            )
            (i32.shl
             (local.get $6)
             (i32.const 2)
            )
           )
          )
          (local.get $5)
         )
         (i32.load offset=60
          (local.get $3)
         )
        )
       )
      )
      (block $block6
       (br_if $block6
        (i32.eqz
         (local.tee $5
          (i32.load offset=140
           (local.get $4)
          )
         )
        )
       )
       (br_if $block6
        (i32.load offset=176
         (local.get $5)
        )
       )
       (br_if $block6
        (i32.load offset=168
         (local.get $5)
        )
       )
       (br_if $block
        (i32.lt_s
         (local.tee $6
          (i32.load offset=64
           (local.get $3)
          )
         )
         (i32.const 0)
        )
       )
       (br_if $block
        (i32.gt_u
         (call $58
          (i32.load
           (i32.add
            (i32.load
             (local.get $0)
            )
            (i32.shl
             (local.get $6)
             (i32.const 2)
            )
           )
          )
          (local.get $5)
         )
         (i32.load offset=76
          (local.get $3)
         )
        )
       )
      )
      (block $block7
       (br_if $block7
        (i32.eqz
         (local.tee $5
          (i32.load offset=144
           (local.get $4)
          )
         )
        )
       )
       (br_if $block7
        (i32.load offset=176
         (local.get $5)
        )
       )
       (br_if $block7
        (i32.load offset=168
         (local.get $5)
        )
       )
       (br_if $block
        (i32.lt_s
         (local.tee $6
          (i32.load offset=80
           (local.get $3)
          )
         )
         (i32.const 0)
        )
       )
       (br_if $block
        (i32.gt_u
         (call $58
          (i32.load
           (i32.add
            (i32.load
             (local.get $0)
            )
            (i32.shl
             (local.get $6)
             (i32.const 2)
            )
           )
          )
          (local.get $5)
         )
         (i32.load offset=92
          (local.get $3)
         )
        )
       )
      )
      (block $block8
       (br_if $block8
        (i32.eqz
         (local.tee $5
          (i32.load offset=148
           (local.get $4)
          )
         )
        )
       )
       (br_if $block8
        (i32.load offset=176
         (local.get $5)
        )
       )
       (br_if $block8
        (i32.load offset=168
         (local.get $5)
        )
       )
       (br_if $block
        (i32.lt_s
         (local.tee $6
          (i32.load offset=96
           (local.get $3)
          )
         )
         (i32.const 0)
        )
       )
       (br_if $block
        (i32.gt_u
         (call $58
          (i32.load
           (i32.add
            (i32.load
             (local.get $0)
            )
            (i32.shl
             (local.get $6)
             (i32.const 2)
            )
           )
          )
          (local.get $5)
         )
         (i32.load offset=108
          (local.get $3)
         )
        )
       )
      )
      (block $block9
       (br_if $block9
        (i32.eqz
         (local.tee $5
          (i32.load offset=152
           (local.get $4)
          )
         )
        )
       )
       (br_if $block9
        (i32.load offset=176
         (local.get $5)
        )
       )
       (br_if $block9
        (i32.load offset=168
         (local.get $5)
        )
       )
       (br_if $block
        (i32.lt_s
         (local.tee $6
          (i32.load offset=112
           (local.get $3)
          )
         )
         (i32.const 0)
        )
       )
       (br_if $block
        (i32.gt_u
         (call $58
          (i32.load
           (i32.add
            (i32.load
             (local.get $0)
            )
            (i32.shl
             (local.get $6)
             (i32.const 2)
            )
           )
          )
          (local.get $5)
         )
         (i32.load offset=124
          (local.get $3)
         )
        )
       )
      )
      (block $block10
       (br_if $block10
        (i32.eqz
         (local.tee $5
          (i32.load offset=156
           (local.get $4)
          )
         )
        )
       )
       (br_if $block10
        (i32.load offset=176
         (local.get $5)
        )
       )
       (br_if $block10
        (i32.load offset=168
         (local.get $5)
        )
       )
       (br_if $block
        (i32.lt_s
         (local.tee $6
          (i32.load offset=128
           (local.get $3)
          )
         )
         (i32.const 0)
        )
       )
       (br_if $block
        (i32.gt_u
         (call $58
          (i32.load
           (i32.add
            (i32.load
             (local.get $0)
            )
            (i32.shl
             (local.get $6)
             (i32.const 2)
            )
           )
          )
          (local.get $5)
         )
         (i32.load offset=140
          (local.get $3)
         )
        )
       )
      )
      (block $block11
       (br_if $block11
        (i32.eqz
         (local.tee $5
          (i32.load offset=160
           (local.get $4)
          )
         )
        )
       )
       (br_if $block11
        (i32.load offset=176
         (local.get $5)
        )
       )
       (br_if $block11
        (i32.load offset=168
         (local.get $5)
        )
       )
       (br_if $block
        (i32.lt_s
         (local.tee $6
          (i32.load offset=144
           (local.get $3)
          )
         )
         (i32.const 0)
        )
       )
       (br_if $block
        (i32.gt_u
         (call $58
          (i32.load
           (i32.add
            (i32.load
             (local.get $0)
            )
            (i32.shl
             (local.get $6)
             (i32.const 2)
            )
           )
          )
          (local.get $5)
         )
         (i32.load offset=156
          (local.get $3)
         )
        )
       )
      )
      (block $block12
       (br_if $block12
        (i32.eqz
         (local.tee $4
          (i32.load offset=164
           (local.get $4)
          )
         )
        )
       )
       (br_if $block12
        (i32.load offset=176
         (local.get $4)
        )
       )
       (br_if $block12
        (i32.load offset=168
         (local.get $4)
        )
       )
       (br_if $block
        (i32.lt_s
         (local.tee $5
          (i32.load offset=160
           (local.get $3)
          )
         )
         (i32.const 0)
        )
       )
       (br_if $block
        (i32.gt_u
         (call $58
          (i32.load
           (i32.add
            (i32.load
             (local.get $0)
            )
            (i32.shl
             (local.get $5)
             (i32.const 2)
            )
           )
          )
          (local.get $4)
         )
         (i32.load offset=172
          (local.get $3)
         )
        )
       )
      )
      (br_if $label
       (i32.lt_s
        (local.tee $2
         (i32.add
          (local.get $2)
          (i32.const 1)
         )
        )
        (i32.load offset=4
         (local.get $1)
        )
       )
      )
     )
     (br $block1)
    )
    (local.set $3
     (i32.const 0)
    )
    (br_if $block13
     (i32.ne
      (i32.load offset=12
       (local.get $0)
      )
      (i32.const 1)
     )
    )
    (br_if $block13
     (i32.eqz
      (call $483
       (local.get $0)
       (local.get $1)
       (i32.const 0)
       (i32.const 0)
      )
     )
    )
   )
   (if
    (i32.gt_s
     (i32.load offset=12
      (local.get $0)
     )
     (i32.const 0)
    )
    (then
     (local.set $3
      (i32.const 0)
     )
     (loop $label1
      (block $block14
       (br_if $block14
        (i32.eqz
         (local.tee $4
          (i32.load
           (i32.add
            (i32.load offset=4
             (local.get $0)
            )
            (i32.shl
             (local.get $3)
             (i32.const 2)
            )
           )
          )
         )
        )
       )
       (br_if $block14
        (i32.eqz
         (local.tee $2
          (i32.load
           (local.get $4)
          )
         )
        )
       )
       (call $64
        (local.get $2)
       )
       (br_if $block14
        (i32.eqz
         (local.tee $2
          (i32.load offset=4
           (local.get $4)
          )
         )
        )
       )
       (call $64
        (local.get $2)
       )
       (br_if $block14
        (i32.eqz
         (local.tee $2
          (i32.load offset=8
           (local.get $4)
          )
         )
        )
       )
       (call $64
        (local.get $2)
       )
       (br_if $block14
        (i32.eqz
         (local.tee $2
          (i32.load offset=12
           (local.get $4)
          )
         )
        )
       )
       (call $64
        (local.get $2)
       )
       (br_if $block14
        (i32.eqz
         (local.tee $2
          (i32.load offset=16
           (local.get $4)
          )
         )
        )
       )
       (call $64
        (local.get $2)
       )
       (br_if $block14
        (i32.eqz
         (local.tee $2
          (i32.load offset=20
           (local.get $4)
          )
         )
        )
       )
       (call $64
        (local.get $2)
       )
       (br_if $block14
        (i32.eqz
         (local.tee $2
          (i32.load offset=24
           (local.get $4)
          )
         )
        )
       )
       (call $64
        (local.get $2)
       )
       (br_if $block14
        (i32.eqz
         (local.tee $2
          (i32.load offset=28
           (local.get $4)
          )
         )
        )
       )
       (call $64
        (local.get $2)
       )
       (br_if $block14
        (i32.eqz
         (local.tee $2
          (i32.load offset=32
           (local.get $4)
          )
         )
        )
       )
       (call $64
        (local.get $2)
       )
       (br_if $block14
        (i32.eqz
         (local.tee $2
          (i32.load offset=36
           (local.get $4)
          )
         )
        )
       )
       (call $64
        (local.get $2)
       )
       (br_if $block14
        (i32.eqz
         (local.tee $2
          (i32.load offset=40
           (local.get $4)
          )
         )
        )
       )
       (call $64
        (local.get $2)
       )
       (br_if $block14
        (i32.eqz
         (local.tee $2
          (i32.load offset=44
           (local.get $4)
          )
         )
        )
       )
       (call $64
        (local.get $2)
       )
       (br_if $block14
        (i32.eqz
         (local.tee $2
          (i32.load offset=48
           (local.get $4)
          )
         )
        )
       )
       (call $64
        (local.get $2)
       )
       (br_if $block14
        (i32.eqz
         (local.tee $2
          (i32.load offset=52
           (local.get $4)
          )
         )
        )
       )
       (call $64
        (local.get $2)
       )
       (br_if $block14
        (i32.eqz
         (local.tee $2
          (i32.load offset=56
           (local.get $4)
          )
         )
        )
       )
       (call $64
        (local.get $2)
       )
       (br_if $block14
        (i32.eqz
         (local.tee $4
          (i32.load offset=60
           (local.get $4)
          )
         )
        )
       )
       (call $64
        (local.get $4)
       )
      )
      (br_if $label1
       (i32.lt_s
        (local.tee $3
         (i32.add
          (local.get $3)
          (i32.const 1)
         )
        )
        (i32.load offset=12
         (local.get $0)
        )
       )
      )
     )
    )
   )
   (if
    (i32.gt_s
     (i32.load offset=8
      (local.get $1)
     )
     (i32.const 0)
    )
    (then
     (local.set $3
      (i32.const 0)
     )
     (loop $label2
      (block $block15
       (if
        (local.tee $2
         (i32.load offset=168
          (local.tee $4
           (i32.load
            (i32.add
             (i32.load offset=24
              (local.get $1)
             )
             (i32.shl
              (local.get $3)
              (i32.const 2)
             )
            )
           )
          )
         )
        )
        (then
         (br_if $block15
          (i32.load offset=4
           (local.get $4)
          )
         )
         (br_if $block15
          (i32.eqz
           (i32.load offset=4
            (local.get $2)
           )
          )
         )
         (drop
          (call $235
           (local.get $4)
          )
         )
         (br $block15)
        )
       )
       (br_if $block15
        (i32.load offset=176
         (local.get $4)
        )
       )
       (local.set $5
        (i32.load offset=8
         (local.tee $2
          (i32.add
           (i32.load offset=40
            (local.get $0)
           )
           (i32.shl
            (local.get $3)
            (i32.const 4)
           )
          )
         )
        )
       )
       (local.set $6
        (call $160
         (i32.load
          (local.tee $2
           (i32.add
            (i32.load
             (i32.add
              (i32.load offset=4
               (local.get $0)
              )
              (i32.shl
               (i32.load
                (local.get $2)
               )
               (i32.const 2)
              )
             )
            )
            (i32.shl
             (i32.load offset=4
              (local.get $2)
             )
             (i32.const 2)
            )
           )
          )
         )
        )
       )
       (drop
        (call $234
         (i32.load
          (local.get $2)
         )
         (local.get $4)
         (i32.add
          (local.get $5)
          (local.get $6)
         )
        )
       )
      )
      (br_if $label2
       (i32.lt_s
        (local.tee $3
         (i32.add
          (local.get $3)
          (i32.const 1)
         )
        )
        (i32.load offset=8
         (local.get $1)
        )
       )
      )
     )
    )
   )
   (local.set $3
    (i32.const 1)
   )
   (br_if $block13
    (i32.le_s
     (i32.load offset=4
      (local.get $1)
     )
     (i32.const 0)
    )
   )
   (local.set $5
    (i32.const 0)
   )
   (loop $label4
    (local.set $8
     (i32.add
      (local.tee $6
       (i32.add
        (i32.load offset=32
         (local.get $0)
        )
        (i32.mul
         (local.get $5)
         (i32.const 176)
        )
       )
      )
      (i32.const 16)
     )
    )
    (local.set $9
     (i32.add
      (local.tee $4
       (i32.load
        (i32.add
         (i32.load offset=12
          (local.get $1)
         )
         (i32.shl
          (local.get $5)
          (i32.const 2)
         )
        )
       )
      )
      (i32.const 128)
     )
    )
    (local.set $3
     (i32.const 0)
    )
    (loop $label3
     (block $block16
      (br_if $block16
       (i32.eqz
        (local.tee $2
         (i32.load
          (i32.add
           (local.get $9)
           (i32.shl
            (local.get $3)
            (i32.const 2)
           )
          )
         )
        )
       )
      )
      (if
       (local.tee $7
        (i32.load offset=168
         (local.get $2)
        )
       )
       (then
        (br_if $block16
         (i32.load offset=4
          (local.get $2)
         )
        )
        (br_if $block16
         (i32.eqz
          (i32.load offset=4
           (local.get $7)
          )
         )
        )
        (drop
         (call $235
          (local.get $2)
         )
        )
        (br $block16)
       )
      )
      (br_if $block16
       (i32.load offset=176
        (local.get $2)
       )
      )
      (local.set $10
       (i32.load offset=8
        (local.tee $7
         (i32.add
          (local.get $8)
          (i32.shl
           (local.get $3)
           (i32.const 4)
          )
         )
        )
       )
      )
      (local.set $11
       (call $160
        (i32.load
         (local.tee $7
          (i32.add
           (i32.load
            (i32.add
             (i32.load offset=4
              (local.get $0)
             )
             (i32.shl
              (i32.load
               (local.get $7)
              )
              (i32.const 2)
             )
            )
           )
           (i32.shl
            (i32.load offset=4
             (local.get $7)
            )
            (i32.const 2)
           )
          )
         )
        )
       )
      )
      (drop
       (call $234
        (i32.load
         (local.get $7)
        )
        (local.get $2)
        (i32.add
         (local.get $10)
         (local.get $11)
        )
       )
      )
     )
     (br_if $label3
      (i32.ne
       (local.tee $3
        (i32.add
         (local.get $3)
         (i32.const 1)
        )
       )
       (i32.const 10)
      )
     )
    )
    (block $block17
     (if
      (local.tee $3
       (i32.load offset=168
        (local.get $4)
       )
      )
      (then
       (br_if $block17
        (i32.load offset=4
         (local.get $4)
        )
       )
       (br_if $block17
        (i32.eqz
         (i32.load offset=4
          (local.get $3)
         )
        )
       )
       (drop
        (call $235
         (local.get $4)
        )
       )
       (br $block17)
      )
     )
     (br_if $block17
      (i32.load offset=176
       (local.get $4)
      )
     )
     (local.set $3
      (i32.load offset=8
       (local.get $6)
      )
     )
     (local.set $6
      (call $160
       (i32.load
        (local.tee $2
         (i32.add
          (i32.load
           (i32.add
            (i32.load offset=4
             (local.get $0)
            )
            (i32.shl
             (i32.load
              (local.get $6)
             )
             (i32.const 2)
            )
           )
          )
          (i32.shl
           (i32.load offset=4
            (local.get $6)
           )
           (i32.const 2)
          )
         )
        )
       )
      )
     )
     (drop
      (call $234
       (i32.load
        (local.get $2)
       )
       (local.get $4)
       (i32.add
        (local.get $3)
        (local.get $6)
       )
      )
     )
    )
    (local.set $3
     (i32.const 1)
    )
    (br_if $label4
     (i32.lt_s
      (local.tee $5
       (i32.add
        (local.get $5)
        (i32.const 1)
       )
      )
      (i32.load offset=4
       (local.get $1)
      )
     )
    )
   )
  )
  (local.get $3)
 )
