 (func $160 (param $0 i32) (result i32)
  (local $1 i32)
  (local $2 i32)
  (global.set $global$0
   (local.tee $1
    (i32.sub
     (global.get $global$0)
     (i32.const 32)
    )
   )
  )
  (block $block2
   (if
    (local.get $0)
    (then
     (block $block1
      (block $block
       (br_if $block
        (if (result i32)
         (local.get $0)
         (then
          (i32.eq
           (i32.load
            (local.get $0)
           )
           (i32.const 619)
          )
         )
         (else
          (i32.const 0)
         )
        )
       )
       (br_if $block
        (i32.load offset=52
         (local.get $0)
        )
       )
       (local.set $0
        (i32.const 0)
       )
       (br $block1)
      )
      (if
       (i32.eqz
        (local.tee $2
         (i32.load offset=4
          (local.get $0)
         )
        )
       )
       (then
        (local.set $0
         (i32.const 0)
        )
        (br $block1)
       )
      )
      (br_if $block2
       (i32.eqz
        (local.tee $0
         (call_indirect (type $1)
          (local.get $0)
          (local.get $2)
         )
        )
       )
      )
     )
     (global.set $global$0
      (i32.add
       (local.get $1)
       (i32.const 32)
      )
     )
     (return
      (local.get $0)
     )
    )
   )
   (i32.store
    (local.get $1)
    (i32.const 5817)
   )
   (call $0
    (i32.const 7147)
    (i32.const 124)
    (i32.const 10746)
    (local.get $1)
   )
   (unreachable)
  )
  (i32.store offset=16
   (local.get $1)
   (i32.const 27738)
  )
  (call $0
   (i32.const 7147)
   (i32.const 138)
   (i32.const 10746)
   (i32.add
    (local.get $1)
    (i32.const 16)
   )
  )
  (unreachable)
 )
