"""Compile only the reviewed adapter and relink the existing native archives.

--commands is inert. --compile requires a new exclusive grant for clean HEAD.
Prior build outputs are read only; a fresh attempt directory prevents retries.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shlex
import subprocess

ROOT = Path(__file__).resolve().parent.parent
PRIOR = ROOT / '.tmp/issue201-whispercpp-short-output-build'
ATTEMPT = ROOT / '.tmp/issue201-whispercpp-untimed-build'
ADAPTER = ROOT / 'scripts/issue201/whispercpp-untimed-review/adapter.cpp'
spec = importlib.util.spec_from_file_location('accepted_builder', ROOT / 'scripts/issue201/whispercpp/private-build.py')
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)


def read_pinned(path, digest):
    if path.is_symlink() or not path.is_file():
        raise RuntimeError('Expected an ordinary pinned input: ' + str(path))
    data = path.read_bytes()
    if hashlib.sha256(data).hexdigest() != digest:
        raise RuntimeError('Prior command evidence changed: ' + str(path))
    return data.decode()


def commands():
    database = json.loads(read_pinned(PRIOR / 'output/compile_commands.json', 'ec5de7eb1fa0c8dd00a78fa5a01ee2f578828f50245fa179bb8894d9147f5ee2'))
    entries = [row for row in database if row['file'] == str(PRIOR / 'recipe/adapter.cpp')]
    if len(entries) != 1:
        raise RuntimeError('Expected exactly one prior adapter command')
    compile_args = shlex.split(entries[0]['command'])
    old_object = 'CMakeFiles/myrelith-whisper.dir/adapter.cpp.o'
    replacements = {str(PRIOR / 'recipe/adapter.cpp'): str(ADAPTER),
                    old_object: str(ATTEMPT / 'adapter.cpp.o'),
                    'myrelith-whisper.mjs': str(ATTEMPT / 'myrelith-whisper.mjs')}
    log = read_pinned(PRIOR / 'logs/compile-link.txt', '27a54fb4f3d0d01c70ce1a05252c066bae3beb82444633c0c3197cfb046ac163')
    lines = [line for line in log.splitlines() if line.startswith('[32/32] : && ')]
    if len(lines) != 1 or not lines[0].endswith(' && :'):
        raise RuntimeError('Expected the exact prior final link command')
    link_args = shlex.split(lines[0][len('[32/32] : && '):-len(' && :')])
    # All libraries remain in the previous successful build. No core compile,
    # configure, download, source-tree mutation, or generated-module execution.
    for arg in link_args:
        if arg.endswith('.a'):
            replacements[arg] = str(PRIOR / 'output' / arg)
    result = [[replacements.get(arg, arg) for arg in args] for args in [compile_args, link_args]]
    if any(args[0] != str(base.EMSCRIPTEN / 'em++') for args in result):
        raise RuntimeError('Unexpected compiler')
    return result


def compile_once():
    git_env = {'PATH': '/usr/bin:/bin', 'DEVELOPER_DIR': '/Library/Developer/CommandLineTools'}
    head = subprocess.check_output(['/usr/bin/git', 'rev-parse', 'HEAD'], cwd=ROOT, env=git_env, text=True).strip()
    dirty = subprocess.check_output(['/usr/bin/git', 'status', '--porcelain'], cwd=ROOT, env=git_env, text=True).strip()
    if dirty or os.environ.get('ISSUE201_EXCLUSIVE_SLOT') != '1' or os.environ.get('ISSUE201_BUILD_COMMIT') != head:
        raise RuntimeError('A new exclusive compile grant for clean HEAD is required')
    planned = commands()
    ATTEMPT.mkdir()  # Existing success or failure is never overwritten/retried.
    (ATTEMPT / 'attempt.json').write_text(json.dumps({'commit': head, 'commands': planned,
        'adapterSha256': hashlib.sha256(ADAPTER.read_bytes()).hexdigest(), 'wasmExecuted': False}, indent=2) + '\n')
    env = base.environment()
    for key, name in [('TMPDIR', 'tmp'), ('EMCC_TEMP_DIR', 'tmp'), ('PYTHONPYCACHEPREFIX', 'pycache'),
                      ('XDG_CACHE_HOME', 'cache'), ('npm_config_cache', 'npm-cache')]:
        path = ATTEMPT / name
        path.mkdir(exist_ok=True)
        env[key] = str(path)
    # Reuse the accepted process-group timeout/cleanup runner with a fresh cwd.
    base.BUILD = ATTEMPT
    base.LOGS = ATTEMPT / 'logs'
    base.LOGS.mkdir()
    try:
        base.run('compile-adapter', planned[0], 180, env)
        base.run('link', planned[1], 300, env)
    except BaseException as error:
        (ATTEMPT / 'result.json').write_text(json.dumps({'status': 'failed-no-retry', 'error': str(error), 'wasmExecuted': False}) + '\n')
        raise
    (ATTEMPT / 'result.json').write_text(json.dumps({'status': 'built-unexecuted', 'wasmExecuted': False}) + '\n')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--commands', action='store_true')
    mode.add_argument('--compile', action='store_true')
    args = parser.parse_args()
    if args.commands:
        print(json.dumps({'commands': commands(), 'compilerExecuted': False, 'wasmExecuted': False}, indent=2))
    else:
        compile_once()
