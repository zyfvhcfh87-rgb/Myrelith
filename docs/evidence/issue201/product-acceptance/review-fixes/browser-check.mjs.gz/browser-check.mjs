import {chromium,expect} from '@playwright/test';
import {createServer} from 'node:http';
import {readFile,writeFile,rm} from 'node:fs/promises';
import path from 'node:path';
const out=path.resolve('.tmp/issue201-review-browser'),profile=path.join(out,'profile'),base=path.resolve('dist');
const server=createServer(async(req,res)=>{try{const p=new URL(req.url,'http://localhost').pathname;const name=p==='/'?'index.html':p.slice(1);const file=path.resolve(base,name);if(!file.startsWith(base+'/'))throw Error('path');const bytes=await readFile(file);res.setHeader('content-type',file.endsWith('.js')?'text/javascript':file.endsWith('.css')?'text/css':file.endsWith('.html')?'text/html':'application/octet-stream');res.end(bytes)}catch{res.writeHead(404);res.end()}});
let context;const result={pids:[],errors:[],speechWorkers:0};
const timer=setTimeout(()=>{void context?.close()},45000);
try{
 await new Promise((ok,bad)=>{server.once('error',bad);server.listen(5201,'127.0.0.1',ok)});
 context=await chromium.launchPersistentContext(profile,{headless:true,args:['--mute-audio','--disable-background-networking'],viewport:{width:1440,height:900}});
 await context.addInitScript(()=>{for(const n of ['showOpenFilePicker','showSaveFilePicker','showDirectoryPicker'])Object.defineProperty(window,n,{configurable:true,value:undefined})});
 const page=context.pages()[0];page.setDefaultTimeout(10000);page.on('pageerror',e=>result.errors.push(e.message));page.on('worker',w=>{if(w.url().includes('caption-transcription.worker-'))result.speechWorkers++});
 await page.goto('http://127.0.0.1:5201/');await page.getByRole('button',{name:'Start a new project',exact:true}).click();await page.getByLabel('Project name',{exact:true}).fill('Delayed source review');await page.getByRole('button',{name:'Create project',exact:true}).click();
 await page.getByLabel('Import media',{exact:true}).setInputFiles(path.join(out,'delayed-english.mkv'));
 await expect(page.getByRole('button',{name:'Captions',exact:true})).toBeVisible();await page.getByRole('button',{name:'Captions',exact:true}).click();await page.getByRole('button',{name:'Transcribe local audio',exact:true}).click();
 await expect(page.getByLabel('Source start (seconds)',{exact:true})).toHaveValue('0.25');await expect(page.getByLabel('Source end (seconds)',{exact:true})).toHaveValue('6.018');
 await expect(page.getByRole('button',{name:'Transcribe selected window',exact:true})).toBeDisabled();
 result.start=await page.getByLabel('Source start (seconds)',{exact:true}).inputValue();result.end=await page.getByLabel('Source end (seconds)',{exact:true}).inputValue();
 await page.screenshot({path:path.join(out,'delayed-window.png')});
 const cdp=await context.browser().newBrowserCDPSession();result.pids=(await cdp.send('SystemInfo.getProcessInfo')).processInfo.map(p=>p.id);result.browser=await cdp.send('Browser.getVersion');result.pass=result.errors.length===0&&result.speechWorkers===0;
}catch(error){result.errors.push(error.message);result.pass=false;if(context)await context.pages()[0]?.screenshot({path:path.join(out,'failure.png')}).catch(()=>{})}
finally{clearTimeout(timer);await context?.close();await new Promise(ok=>server.close(ok));await rm(profile,{recursive:true,force:true});await writeFile(path.join(out,'result.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));}
if(!result.pass)process.exitCode=1;
