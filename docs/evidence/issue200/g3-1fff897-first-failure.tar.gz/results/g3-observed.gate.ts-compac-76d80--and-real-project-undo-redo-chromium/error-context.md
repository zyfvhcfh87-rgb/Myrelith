# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: g3-observed.gate.ts >> compact upgrade, elements, static editing and real project undo/redo
- Location: tests/browser/issue-200-title-authoring.spec.ts:28:1

# Error details

```
Test timeout of 60000ms exceeded.
```

```
Error: locator.fill: Test timeout of 60000ms exceeded.
Call log:
  - waiting for getByLabel('Text content', { exact: true })

```

# Page snapshot

```yaml
- generic [ref=e4]:
  - banner [ref=e5]:
    - generic [ref=e6]:
      - strong [ref=e7]: Myrelith
      - generic [ref=e8]:
        - strong [ref=e9]: Title G3 authoring
        - generic [ref=e10]: Unsaved changes
        - 'alert "Could not update the recovery copy: Recovery journal belongs to a different document" [ref=e11]': Recovery copy failed
      - generic [ref=e12]: S splits at playhead · Del ripple-deletes
      - generic [ref=e13]:
        - button "Commands" [ref=e14] [cursor=pointer]:
          - generic [ref=e18]: Ctrl/⌘+K
        - button "Projects" [ref=e19] [cursor=pointer]
        - button "Save" [ref=e20] [cursor=pointer]
        - button "Save As" [ref=e21] [cursor=pointer]
        - button "Captions" [ref=e22] [cursor=pointer]
        - button "Plugins" [ref=e23] [cursor=pointer]
        - button "Export" [ref=e24] [cursor=pointer]
  - generic [ref=e25]:
    - group "Workspace layout" [ref=e26]:
      - generic [ref=e27]:
        - generic [ref=e28]: Workspace
        - combobox "Workspace preset" [ref=e29]:
          - option "Edit" [selected]
          - option "Inspect"
          - option "Media"
          - option "Custom" [disabled]
      - button "Media" [pressed] [ref=e31] [cursor=pointer]
      - button "Inspector" [pressed] [ref=e32] [cursor=pointer]
      - button "Timeline" [pressed] [ref=e33] [cursor=pointer]
      - button "Focus Inspector" [ref=e34] [cursor=pointer]
    - generic "Project sequences" [ref=e35]:
      - generic [ref=e36]:
        - generic [ref=e37]: Sequence
        - combobox "Active sequence" [ref=e38]:
          - option "root · Root" [selected]
          - option "dormant"
      - generic "Portable default render truth" [ref=e39]: "Root: root"
      - group "Sequence actions" [ref=e40]:
        - button "New" [ref=e41] [cursor=pointer]
        - button "Create compound" [ref=e42] [cursor=pointer]
        - button "Back to parent" [disabled] [ref=e43]
        - button "Duplicate" [ref=e44] [cursor=pointer]
        - button "Rename" [ref=e45] [cursor=pointer]
        - button "Make root" [disabled] [ref=e46]
        - button "Delete" [disabled] [ref=e47]
      - status [ref=e48]
    - status [ref=e49]
  - complementary [ref=e50]:
    - generic [ref=e51]:
      - generic [ref=e52]:
        - generic [ref=e53]:
          - heading "Media" [level=2] [ref=e54]
          - button "Import" [ref=e56] [cursor=pointer]
        - paragraph [ref=e60]: Import stores a browser-only file permission and its label. Myrelith never copies or uploads the file.
        - search "Filter media" [ref=e61]:
          - generic [ref=e62]:
            - generic [ref=e63]: Search
            - searchbox "Search" [ref=e64]
          - generic [ref=e65]:
            - generic [ref=e66]: Type
            - combobox "Type" [ref=e67]:
              - option "All types" [selected]
              - option "Video"
              - option "Audio"
              - option "Still images"
          - generic [ref=e68]:
            - generic [ref=e69]: Status
            - combobox "Status" [ref=e70]:
              - option "All statuses" [selected]
              - option "Ready media"
              - option "Offline media"
              - option "Checking media"
              - option "Limited media"
              - option "Unsupported media"
              - option "Media errors"
          - generic [ref=e71]: 0 of 0
        - group "View and sort" [ref=e73]:
          - radiogroup "Media Pool view" [ref=e74]:
            - radio "Thumbnail grid" [ref=e75] [cursor=pointer]
            - radio "Details" [checked] [ref=e78] [cursor=pointer]
            - radio "Compact list" [ref=e81] [cursor=pointer]
          - generic [ref=e84]:
            - generic [ref=e85]: Thumbnail size
            - combobox "Thumbnail size" [ref=e86]:
              - option "Small"
              - option "Medium" [selected]
              - option "Large"
          - generic [ref=e87]:
            - generic [ref=e88]: Sort
            - combobox "Sort media" [ref=e89]:
              - option "Project order" [selected]
              - option "Name"
              - option "Kind"
              - option "Duration"
              - option "Last modified"
              - option "Size"
          - button "Sort ascending" [ref=e90] [cursor=pointer]
        - generic [ref=e93]:
          - group "Local proxy storage" [ref=e94]:
            - generic "▸ Proxies 0 · 0 B" [ref=e95] [cursor=pointer]:
              - text: ▸
              - strong [ref=e96]: Proxies
              - generic [ref=e97]: 0 · 0 B
          - generic "Default still-image duration. Future imports only." [ref=e98]:
            - generic [ref=e99]: Stills
            - generic [ref=e100]:
              - spinbutton "Default still-image duration" [ref=e101]: "5"
              - generic [ref=e102]: s
            - generic [ref=e103]: Future imports only
      - region "Collections" [ref=e104]:
        - generic [ref=e105]:
          - generic [ref=e106]: Collections
          - generic "Collection history" [ref=e107]:
            - button "Undo collection change" [disabled] [ref=e108]
            - button "Redo collection change" [disabled] [ref=e111]
            - button "New collection" [ref=e114] [cursor=pointer]
        - tablist "Media collections" [ref=e117]:
          - tab "All media" [selected] [ref=e118] [cursor=pointer]:
            - generic [ref=e122]: "0"
      - grid "Media assets" [ref=e124]
      - paragraph [ref=e125]: no media yet — import video, audio, or a still image
      - generic [ref=e126]: Use arrow keys, Home, End, Page Up, and Page Down to move the Media Pool selection. Tab moves into that row's relink, collection, proxy, and remove actions.
      - generic [ref=e127]: No media selected
  - separator "Resize Media panel" [ref=e128]
  - main [ref=e129]:
    - generic [ref=e131]:
      - button "Scopes" [ref=e132] [cursor=pointer]
      - generic [ref=e133]:
        - generic [ref=e134]: Quality
        - combobox "Preview quality" [ref=e135]:
          - option "Auto" [selected]
          - option "Full"
          - option "Half"
          - option "Quarter"
      - generic "Visual clip canvas controls": Arrow keys adjust the focused control. Hold Shift for larger steps. Drag to preview; releasing commits one edit.
      - generic "Text overlay canvas controls": Use arrow keys to move one pixel. Hold Shift to move ten pixels. Use the resize handle arrow keys to change the text box.
      - generic "Title canvas controls":
        - generic:
          - button "Move title element Text" [pressed] [ref=e137]
          - button "Resize title element Text" [ref=e138]
      - status [ref=e139]:
        - strong [ref=e140]: Title font notice
        - text: "Title 世界 / Text: sans-serif uses this platform's fonts; appearance can differ on another device."
  - separator "Resize Inspector panel" [ref=e141]
  - complementary [ref=e142]:
    - region "Manual-sync multicam" [ref=e143]:
      - generic [ref=e144]:
        - generic [ref=e145]: Multicam
        - button "New multicam" [disabled] [ref=e146]
      - status "Multicam edit status" [ref=e147]
    - group [ref=e148]:
      - generic "Track and master video effects" [ref=e149]
      - option "Sequence master video" [selected]
      - option "V1"
      - option "V2"
      - option "V3"
      - option "V4"
    - generic [ref=e150]:
      - generic [ref=e151]: Inspector
      - generic [ref=e156]:
        - strong [ref=e157]: Title 世界
        - generic [ref=e158]: Video clip
      - tablist "Video inspector sections" [ref=e159]:
        - tab "Transform" [selected] [ref=e160] [cursor=pointer]
        - tab "Crop" [ref=e161] [cursor=pointer]
        - tab "Effects" [ref=e162] [cursor=pointer]
        - tab "Animation" [ref=e163] [cursor=pointer]
      - group "Audio/video linking" [ref=e164]:
        - button "Link selected audio and video clips" [disabled] [ref=e165]
        - generic [ref=e166]: Select one more clip with Ctrl/Cmd-click, or focus it and press Ctrl/Cmd+Enter.
        - status
      - region "Timing" [ref=e167]:
        - generic [ref=e168]:
          - heading "Timing" [level=3] [ref=e169]
          - button "Reset clip speed" [disabled] [ref=e170]: Reset
        - generic [ref=e171]:
          - generic [ref=e172]: Speed at playhead
          - combobox "Speed at playhead" [ref=e173]:
            - option "0% (Freeze)" [disabled]
            - option "25%"
            - option "50%"
            - option "75%"
            - option "100%" [selected]
            - option "125%"
            - option "150%"
            - option "175%"
            - option "200%"
            - option "225%"
            - option "250%"
            - option "275%"
            - option "300%"
            - option "325%"
            - option "350%"
            - option "375%"
            - option "400%"
        - generic [ref=e174]: Clip frame 0. Add a later positive speed boundary before choosing 0% (Freeze).
        - generic [ref=e175]:
          - generic [ref=e176]: Whole clip speed
          - combobox "Whole clip speed" [ref=e177]:
            - option "25%"
            - option "50%"
            - option "75%"
            - option "100%" [selected]
            - option "125%"
            - option "150%"
            - option "175%"
            - option "200%"
            - option "225%"
            - option "250%"
            - option "275%"
            - option "300%"
            - option "325%"
            - option "350%"
            - option "375%"
            - option "400%"
        - generic [ref=e178]: Timeline 100 frames · source 100 frames.
        - generic [ref=e179]: Audio stays enabled at 100% speed.
        - generic [ref=e180]:
          - generic "Speed ramp operations" [ref=e181]:
            - button "Add boundary at playhead" [ref=e182] [cursor=pointer]
            - button "Clear ramp" [disabled] [ref=e183]
          - paragraph [ref=e184]: Choose a speed at the playhead or add a boundary to start a timed section. The current whole-clip speed becomes frame 0.
          - status [ref=e185]: "Playhead: clip frame 0. A 0% freeze must be bounded by a later positive point."
      - region "Clip attribute actions" [ref=e187]:
        - generic [ref=e188]:
          - button "Copy attributes" [ref=e189] [cursor=pointer]
          - button "Paste attributes…" [disabled] [ref=e190]
          - button "Reset attributes…" [ref=e191] [cursor=pointer]
      - region "Title authoring" [ref=e192]:
        - heading "Title elements" [level=3] [ref=e193]
        - paragraph [ref=e194]: Back to front. Select several elements for a shared edit.
        - list [ref=e195]:
          - listitem [ref=e196]:
            - generic [ref=e197]:
              - checkbox "Text text" [checked] [ref=e198]
              - text: Text
              - generic [ref=e199]: text
            - button "Move Text backward" [disabled] [ref=e200]: ↓
            - button "Move Text forward" [disabled] [ref=e201]: ↑
        - group "Edit title elements" [ref=e202]:
          - generic [ref=e204]:
            - button "Add text" [ref=e205]
            - button "Add rectangle" [ref=e206]
            - button "Add ellipse" [ref=e207]
          - generic [ref=e208]:
            - button "Duplicate elements" [ref=e209]
            - button "Delete elements" [disabled] [ref=e210]
          - paragraph [ref=e211]: Base values. Existing keys override these at animated frames.
          - generic [ref=e212]:
            - text: Element name
            - textbox "Element name" [ref=e213]: Text
          - generic [ref=e214]:
            - checkbox "Enabled" [checked] [ref=e215]
            - text: Enabled
          - generic [ref=e216]:
            - generic [ref=e218]:
              - generic [ref=e219]: Position X
              - spinbutton "Position X" [ref=e220]: "0"
            - generic [ref=e222]:
              - generic [ref=e223]: Position Y
              - spinbutton "Position Y" [ref=e224]: "0"
            - generic [ref=e226]:
              - generic [ref=e227]: Scale X
              - spinbutton "Scale X" [ref=e228]: "1"
            - generic [ref=e230]:
              - generic [ref=e231]: Scale Y
              - spinbutton "Scale Y" [ref=e232]: "1"
            - generic [ref=e234]:
              - generic [ref=e235]: Rotation
              - spinbutton "Rotation" [ref=e236]: "0"
            - generic [ref=e238]:
              - generic [ref=e239]: Opacity
              - spinbutton "Opacity" [ref=e240]: "1"
            - generic [ref=e242]:
              - generic [ref=e243]: Box width
              - spinbutton "Box width" [ref=e244]: "1248"
            - generic [ref=e246]:
              - generic [ref=e247]: Box height
              - spinbutton "Box height" [ref=e248]: "238"
            - generic [ref=e250]:
              - generic [ref=e251]: Font size
              - spinbutton "Font size" [ref=e252]: "72"
            - generic [ref=e254]:
              - generic [ref=e255]: Outline width
              - spinbutton "Outline width" [ref=e256]: "2"
            - generic [ref=e258]:
              - generic [ref=e259]: Shadow blur
              - spinbutton "Shadow blur" [ref=e260]: "4"
            - generic [ref=e262]:
              - generic [ref=e263]: Shadow offset X
              - spinbutton "Shadow offset X" [ref=e264]: "2"
            - generic [ref=e266]:
              - generic [ref=e267]: Shadow offset Y
              - spinbutton "Shadow offset Y" [ref=e268]: "2"
          - generic [ref=e269]:
            - checkbox "Lock scale ratio (X when enabling)" [checked] [ref=e270]
            - text: Lock scale ratio (X when enabling)
          - generic [ref=e271]:
            - generic [ref=e272]:
              - generic [ref=e273]: Anchor X
              - spinbutton "Anchor X" [ref=e274]: "0.5"
            - generic [ref=e275]:
              - generic [ref=e276]: Anchor Y
              - spinbutton "Anchor Y" [ref=e277]: "0.5"
            - generic [ref=e278]:
              - generic [ref=e279]: Crop left
              - spinbutton "Crop left" [ref=e280]: "0"
            - generic [ref=e281]:
              - generic [ref=e282]: Crop right
              - spinbutton "Crop right" [ref=e283]: "0"
            - generic [ref=e284]:
              - generic [ref=e285]: Crop top
              - spinbutton "Crop top" [ref=e286]: "0"
            - generic [ref=e287]:
              - generic [ref=e288]: Crop bottom
              - spinbutton "Crop bottom" [ref=e289]: "0"
          - generic [ref=e290]:
            - checkbox "Flip horizontal" [ref=e291]
            - text: Flip horizontal
          - generic [ref=e292]:
            - checkbox "Flip vertical" [ref=e293]
            - text: Flip vertical
          - generic [ref=e294]:
            - text: Text content
            - textbox "Text content" [ref=e295]: Title 世界 Second line
          - status [ref=e296]: sans-serif · platform-dependent.
          - generic [ref=e297]:
            - text: Font family
            - combobox "Font family" [ref=e298]:
              - option "sans-serif" [selected]
              - option "serif"
              - option "monospace"
              - option "cursive"
              - option "fantasy"
              - option "system-ui"
          - generic [ref=e299]:
            - text: Explicit font fallback
            - combobox "Explicit font fallback" [ref=e300]:
              - option "No fallback" [selected]
              - option "sans-serif"
              - option "serif"
              - option "monospace"
              - option "cursive"
              - option "fantasy"
              - option "system-ui"
          - generic [ref=e301]:
            - text: Text alignment
            - combobox "Text alignment" [ref=e302]:
              - option "left"
              - option "center" [selected]
              - option "right"
          - generic [ref=e303]:
            - text: Text color
            - textbox "Text color" [ref=e304]: "#ffffff"
          - generic [ref=e305]:
            - generic [ref=e306]: Text padding
            - spinbutton "Text padding" [ref=e307]: "18"
          - generic [ref=e308]:
            - checkbox "Bold" [checked] [ref=e309]
            - text: Bold
          - generic [ref=e310]:
            - checkbox "Italic" [ref=e311]
            - text: Italic
          - generic [ref=e312]:
            - checkbox "Background" [ref=e313]
            - text: Background
          - generic [ref=e314]:
            - checkbox "Outline" [checked] [ref=e315]
            - text: Outline
          - generic [ref=e316]:
            - checkbox "Shadow" [checked] [ref=e317]
            - text: Shadow
          - generic [ref=e318]:
            - text: Background color
            - textbox "Background color" [ref=e319]: "#000000"
          - generic [ref=e320]:
            - text: Outline color
            - textbox "Outline color" [ref=e321]: "#000000"
          - generic [ref=e322]:
            - text: Shadow color
            - textbox "Shadow color" [ref=e323]: "#000000"
          - generic [ref=e324]:
            - button "Roll / crawl…" [ref=e325]
            - button "Save title template…" [ref=e326]
        - generic [ref=e327]:
          - checkbox "Safe guides · title 90% / action 95%" [ref=e328]
          - text: Safe guides · title 90% / action 95%
      - generic [ref=e329]:
        - generic [ref=e330]: Video · Title 世界
        - tabpanel "Transform" [ref=e331]:
          - paragraph [ref=e332]: Use Title elements to transform this title.
          - region "Compositing" [ref=e333]:
            - generic [ref=e334]:
              - heading "Compositing" [level=3] [ref=e335]
              - button "Reset video blend mode" [ref=e336] [cursor=pointer]: Reset
            - generic [ref=e337]:
              - generic [ref=e338]: Blend mode
              - combobox "Blend mode" [ref=e339]:
                - option "Normal" [selected]
                - option "Multiply"
                - option "Screen"
                - option "Overlay"
                - option "Darken"
                - option "Lighten"
                - option "Difference"
                - option "Exclusion"
            - generic [ref=e340]: Normal is applied after transform, crop, and opacity.
          - region "Opacity" [ref=e341]:
            - generic [ref=e342]:
              - heading "Opacity" [level=3] [ref=e343]
              - button "Reset video opacity" [ref=e344] [cursor=pointer]: Reset
            - generic [ref=e345]:
              - slider "Opacity slider" [ref=e346]: "1"
              - generic [ref=e347]:
                - generic [ref=e348]: Opacity
                - spinbutton "Opacity" [ref=e349]: "1"
      - region [ref=e350]:
        - generic [ref=e351]:
          - heading "Clip audio effects" [level=3] [ref=e352]
          - generic "Add clip audio effects" [ref=e353]:
            - button "Add EQ" [ref=e354] [cursor=pointer]
            - button "Add compressor" [ref=e355] [cursor=pointer]
            - button "Add limiter" [ref=e356] [cursor=pointer]
            - button "Add noise gate" [ref=e357] [cursor=pointer]
            - button "Voice preset" [ref=e358] [cursor=pointer]
            - button "Music preset" [ref=e359] [cursor=pointer]
            - button "Podcast preset" [ref=e360] [cursor=pointer]
        - generic [ref=e361]: Audio effects run in authored order at this mix stage. Live playback and export share the same processors; bypass, reorder, reset, and unknown descriptors are preserved.
        - generic [ref=e362]: No audio effects on this stack.
      - region [ref=e363]:
        - generic [ref=e364]:
          - heading "V1 audio effects" [level=3] [ref=e365]
          - generic "Add v1 audio effects" [ref=e366]:
            - button "Add EQ" [ref=e367] [cursor=pointer]
            - button "Add compressor" [ref=e368] [cursor=pointer]
            - button "Add limiter" [ref=e369] [cursor=pointer]
            - button "Add noise gate" [ref=e370] [cursor=pointer]
            - button "Voice preset" [ref=e371] [cursor=pointer]
            - button "Music preset" [ref=e372] [cursor=pointer]
            - button "Podcast preset" [ref=e373] [cursor=pointer]
        - generic [ref=e374]: Audio effects run in authored order at this mix stage. Live playback and export share the same processors; bypass, reorder, reset, and unknown descriptors are preserved.
        - generic [ref=e375]: No audio effects on this stack.
      - region [ref=e376]:
        - generic [ref=e377]:
          - heading "Master audio effects" [level=3] [ref=e378]
          - generic "Add master audio effects" [ref=e379]:
            - button "Add EQ" [ref=e380] [cursor=pointer]
            - button "Add compressor" [ref=e381] [cursor=pointer]
            - button "Add limiter" [ref=e382] [cursor=pointer]
            - button "Add noise gate" [ref=e383] [cursor=pointer]
            - button "Voice preset" [ref=e384] [cursor=pointer]
            - button "Music preset" [ref=e385] [cursor=pointer]
            - button "Podcast preset" [ref=e386] [cursor=pointer]
        - generic [ref=e387]: Audio effects run in authored order at this mix stage. Live playback and export share the same processors; bypass, reorder, reset, and unknown descriptors are preserved.
        - generic [ref=e388]: No audio effects on this stack.
      - region "Loudness" [ref=e389]:
        - generic [ref=e390]:
          - heading "Loudness" [level=3] [ref=e391]
          - button "Measure" [ref=e392]
        - generic [ref=e393]:
          - generic [ref=e394]: Measurement range
          - combobox "Loudness measurement range" [ref=e395]:
            - option "Full timeline" [selected]
            - option "Timeline In/Out" [disabled]
        - generic [ref=e396]: Measurement is derived from the mixed program. It never writes gain. Incomplete coverage cannot claim a complete reading.
        - generic [ref=e397]: "Selected range: 0–100 (end exclusive)."
        - button "Normalize master to -16 LUFS" [disabled] [ref=e398]
  - generic [ref=e399]:
    - group "timeline tools" [ref=e400]:
      - button "Select — move clips, drag edges to trim (A)" [pressed] [ref=e401] [cursor=pointer]
      - button "Razor — click a clip to cut it (B)" [ref=e404] [cursor=pointer]
      - button "Ripple trim — drag edges, later clips follow (T)" [ref=e407] [cursor=pointer]
      - button "Slip — drag to change WHICH material plays (Y)" [ref=e410] [cursor=pointer]
      - button "Slide — drag between neighbors, they absorb it (U)" [ref=e413] [cursor=pointer]
      - button "Add text" [ref=e416] [cursor=pointer]
      - button "Title templates" [ref=e419] [cursor=pointer]: T+
      - button "Add adjustment layer" [ref=e420] [cursor=pointer]
      - button "Snapping on — hold Alt to temporarily bypass snapping" [pressed] [ref=e423] [cursor=pointer]
    - generic [ref=e426]:
      - button "one frame back" [ref=e427] [cursor=pointer]
      - button "play" [ref=e430] [cursor=pointer]
      - button "one frame forward" [ref=e433] [cursor=pointer]
      - button "Insert edit" [disabled] [ref=e436] [cursor=pointer]: Insert
      - button "Overwrite edit" [disabled] [ref=e437] [cursor=pointer]: Overwrite
      - button "Lift" [disabled] [ref=e438] [cursor=pointer]
      - button "Extract" [disabled] [ref=e439] [cursor=pointer]
      - button "Replace edit" [disabled] [ref=e440] [cursor=pointer]: Replace
      - region "Playback audio levels" [ref=e441]:
        - generic [ref=e442]: Playback is paused
        - generic [ref=e443]:
          - generic [ref=e444]:
            - generic [ref=e445]: L
            - meter "Left playback level" [ref=e446]
          - generic [ref=e448]:
            - generic [ref=e449]: R
            - meter "Right playback level" [ref=e450]
          - generic [ref=e452]:
            - generic [ref=e453]: M
            - meter "Master playback level" [ref=e454]
        - button "Reset audio overload warning" [disabled] [ref=e456]: "0"
    - group "Timeline zoom controls" [ref=e457]:
      - button "Full Extent Zoom" [ref=e458] [cursor=pointer]
      - button "Detail Zoom" [ref=e461] [cursor=pointer]
      - button "Custom Zoom" [pressed] [ref=e464] [cursor=pointer]
      - button "Zoom Out" [ref=e467] [cursor=pointer]
      - slider "Custom timeline zoom" [ref=e470] [cursor=pointer]: "0.693"
      - button "Zoom In" [ref=e471] [cursor=pointer]
  - separator "Resize Timeline panel" [ref=e474]
  - generic [ref=e475]:
    - region "Audio mixer" [ref=e476]:
      - article [ref=e477]:
        - generic: A1
        - generic [ref=e478]:
          - slider "A1 volume" [ref=e479]: "1"
          - generic [ref=e480]:
            - generic [ref=e481]:
              - meter "A1 left level" [ref=e482]
              - generic [ref=e483]: L
            - generic [ref=e484]:
              - meter "A1 right level" [ref=e485]
              - generic [ref=e486]: R
        - slider "A1 balance" [ref=e487]: "0"
        - generic [ref=e488]:
          - button "solo track A1" [ref=e489] [cursor=pointer]: S
          - button "mute track A1" [ref=e490] [cursor=pointer]: M
      - article [ref=e491]:
        - generic: A2
        - generic [ref=e492]:
          - slider "A2 volume" [ref=e493]: "1"
          - generic [ref=e494]:
            - generic [ref=e495]:
              - meter "A2 left level" [ref=e496]
              - generic [ref=e497]: L
            - generic [ref=e498]:
              - meter "A2 right level" [ref=e499]
              - generic [ref=e500]: R
        - slider "A2 balance" [ref=e501]: "0"
        - generic [ref=e502]:
          - button "solo track A2" [ref=e503] [cursor=pointer]: S
          - button "mute track A2" [ref=e504] [cursor=pointer]: M
      - article [ref=e505]:
        - generic: A3
        - generic [ref=e506]:
          - slider "A3 volume" [ref=e507]: "1"
          - generic [ref=e508]:
            - generic [ref=e509]:
              - meter "A3 left level" [ref=e510]
              - generic [ref=e511]: L
            - generic [ref=e512]:
              - meter "A3 right level" [ref=e513]
              - generic [ref=e514]: R
        - slider "A3 balance" [ref=e515]: "0"
        - generic [ref=e516]:
          - button "solo track A3" [ref=e517] [cursor=pointer]: S
          - button "mute track A3" [ref=e518] [cursor=pointer]: M
      - article [ref=e519]:
        - generic: A4
        - generic [ref=e520]:
          - slider "A4 volume" [ref=e521]: "1"
          - generic [ref=e522]:
            - generic [ref=e523]:
              - meter "A4 left level" [ref=e524]
              - generic [ref=e525]: L
            - generic [ref=e526]:
              - meter "A4 right level" [ref=e527]
              - generic [ref=e528]: R
        - slider "A4 balance" [ref=e529]: "0"
        - generic [ref=e530]:
          - button "solo track A4" [ref=e531] [cursor=pointer]: S
          - button "mute track A4" [ref=e532] [cursor=pointer]: M
      - article [ref=e533]:
        - generic: Master
        - generic [ref=e534]:
          - slider "Master volume" [ref=e535]: "1"
          - generic [ref=e536]:
            - generic [ref=e537]:
              - meter "Master left level" [ref=e538]
              - generic [ref=e539]: L
            - generic [ref=e540]:
              - meter "Master right level" [ref=e541]
              - generic [ref=e542]: R
        - slider "Master balance" [ref=e543]: "0"
        - button "mute master" [ref=e545] [cursor=pointer]: M
    - generic [ref=e547]:
      - generic [ref=e548]:
        - generic "Rename from the Rename button, or double-click the header" [ref=e550]:
          - generic [ref=e551]: V4
          - generic [ref=e552]:
            - generic [ref=e553]: Video
            - generic [ref=e554]: 0 clips
          - generic [ref=e555]:
            - button "target track V4" [ref=e556] [cursor=pointer]: T
            - button "rename track V4" [ref=e557] [cursor=pointer]
            - button "hide track V4" [ref=e560] [cursor=pointer]
            - button "lock track V4" [ref=e563] [cursor=pointer]
            - button "delete track V4" [ref=e566] [cursor=pointer]
        - generic "Rename from the Rename button, or double-click the header" [ref=e569]:
          - generic [ref=e570]: V3
          - generic [ref=e571]:
            - generic [ref=e572]: Video
            - generic [ref=e573]: 0 clips
          - generic [ref=e574]:
            - button "target track V3" [ref=e575] [cursor=pointer]: T
            - button "rename track V3" [ref=e576] [cursor=pointer]
            - button "hide track V3" [ref=e579] [cursor=pointer]
            - button "lock track V3" [ref=e582] [cursor=pointer]
            - button "delete track V3" [ref=e585] [cursor=pointer]
        - generic "Rename from the Rename button, or double-click the header" [ref=e588]:
          - generic [ref=e589]: V2
          - generic [ref=e590]:
            - generic [ref=e591]: Video
            - generic [ref=e592]: 0 clips
          - generic [ref=e593]:
            - button "target track V2" [ref=e594] [cursor=pointer]: T
            - button "rename track V2" [ref=e595] [cursor=pointer]
            - button "hide track V2" [ref=e598] [cursor=pointer]
            - button "lock track V2" [ref=e601] [cursor=pointer]
            - button "delete track V2" [ref=e604] [cursor=pointer]
        - generic "Rename from the Rename button, or double-click the header" [ref=e607]:
          - generic [ref=e608]: V1
          - generic [ref=e609]:
            - generic [ref=e610]: Video
            - generic [ref=e611]: 1 clip
          - generic [ref=e612]:
            - button "target track V1" [pressed] [ref=e613] [cursor=pointer]: T
            - button "rename track V1" [ref=e614] [cursor=pointer]
            - button "hide track V1" [ref=e617] [cursor=pointer]
            - button "lock track V1" [ref=e620] [cursor=pointer]
            - button "delete track V1" [ref=e623] [cursor=pointer]
        - generic "Rename from the Rename button, or double-click the header" [ref=e626]:
          - generic [ref=e627]: A1
          - generic [ref=e628]:
            - generic [ref=e629]: Audio
            - generic [ref=e630]: 0 clips
          - generic [ref=e631]:
            - button "target track A1" [pressed] [ref=e632] [cursor=pointer]: T
            - button "rename track A1" [ref=e633] [cursor=pointer]
            - button "solo track A1" [ref=e636] [cursor=pointer]: S
            - button "mute track A1" [ref=e637] [cursor=pointer]: M
            - button "lock track A1" [ref=e638] [cursor=pointer]
            - button "delete track A1" [ref=e641] [cursor=pointer]
        - generic "Rename from the Rename button, or double-click the header" [ref=e644]:
          - generic [ref=e645]: A2
          - generic [ref=e646]:
            - generic [ref=e647]: Audio
            - generic [ref=e648]: 0 clips
          - generic [ref=e649]:
            - button "target track A2" [ref=e650] [cursor=pointer]: T
            - button "rename track A2" [ref=e651] [cursor=pointer]
            - button "solo track A2" [ref=e654] [cursor=pointer]: S
            - button "mute track A2" [ref=e655] [cursor=pointer]: M
            - button "lock track A2" [ref=e656] [cursor=pointer]
            - button "delete track A2" [ref=e659] [cursor=pointer]
        - generic "Rename from the Rename button, or double-click the header" [ref=e662]:
          - generic [ref=e663]: A3
          - generic [ref=e664]:
            - generic [ref=e665]: Audio
            - generic [ref=e666]: 0 clips
          - generic [ref=e667]:
            - button "target track A3" [ref=e668] [cursor=pointer]: T
            - button "rename track A3" [ref=e669] [cursor=pointer]
            - button "solo track A3" [ref=e672] [cursor=pointer]: S
            - button "mute track A3" [ref=e673] [cursor=pointer]: M
            - button "lock track A3" [ref=e674] [cursor=pointer]
            - button "delete track A3" [ref=e677] [cursor=pointer]
        - generic "Rename from the Rename button, or double-click the header" [ref=e680]:
          - generic [ref=e681]: A4
          - generic [ref=e682]:
            - generic [ref=e683]: Audio
            - generic [ref=e684]: 0 clips
          - generic [ref=e685]:
            - button "target track A4" [ref=e686] [cursor=pointer]: T
            - button "rename track A4" [ref=e687] [cursor=pointer]
            - button "solo track A4" [ref=e690] [cursor=pointer]: S
            - button "mute track A4" [ref=e691] [cursor=pointer]: M
            - button "lock track A4" [ref=e692] [cursor=pointer]
            - button "delete track A4" [ref=e695] [cursor=pointer]
        - generic [ref=e698]:
          - button "add video track" [ref=e699] [cursor=pointer]: + Video
          - button "add audio track" [ref=e700] [cursor=pointer]: + Audio
      - generic [ref=e701]:
        - generic [ref=e702]:
          - slider "Timeline playhead"
          - generic [ref=e703]: Arrow keys move one frame, Shift+arrow moves ten, Page Up and Page Down move one second, Home and End jump to the bounds, Escape restores the playhead from when this ruler received focus, and Alt bypasses snapping.
          - generic: 00:00:00:00
          - generic: 00:00:05:00
          - generic: 00:00:10:00
          - generic: 00:00:15:00
          - generic: 00:00:20:00
          - generic: 00:00:25:00
          - generic: 00:00:30:00
          - generic: 00:00:35:00
          - generic: 00:00:40:00
          - generic: 00:00:45:00
          - generic: 00:00:50:00
          - generic: 00:00:55:00
          - generic: 00:01:00:00
          - generic: 00:01:05:00
          - generic: 00:01:10:00
          - generic "Timeline markers"
        - button "Title 世界, video clip" [pressed] [ref=e709]: Title 世界
  - status [ref=e717]
```

# Test source

```ts
  1   | /** G3 observable protocol: actual UI mutations; imports are fixture setup and read-only evidence. */
  2   | import { expect, test, type Page } from '@playwright/test'
  3   | async function enter(page: Page, expanded = true) {
  4   |   await page.goto('/')
  5   |   await page.getByRole('button', { name: 'Start a new project' }).click()
  6   |   await page.getByLabel('Project name').fill('Title G3 authoring')
  7   |   await page.getByLabel('Resolution').selectOption('720')
  8   |   await page.getByRole('button', { name: 'Create project', exact: true }).click()
  9   |   await expect(page.getByRole('button', { name: 'Commands' })).toBeVisible()
  10  |   await page.evaluate(async (expanded) => {
  11  |     const f = '/src/test/titleOwnerFixtures.ts', d = '/src/state/documentStore.ts', t = '/src/state/transportStore.ts', s = '/src/state/titleEditorStore.ts'
  12  |     const fixture = await import(f), store = (await import(d)).useDocumentStore, transport = (await import(t)).useTransportStore
  13  |     store.getState().setProject(expanded ? fixture.expandedTitleProject() : fixture.legacyTitleProject())
  14  |     transport.getState().setSelectedClip('root-text'); transport.getState().setPlayheadFrame(0)
  15  |     ;(await import(s)).useTitleEditorStore.getState().select('root-text', ['root-element'])
  16  |   }, expanded)
  17  | }
  18  | async function snapshot(page: Page) {
  19  |   return page.evaluate(async () => {
  20  |     const d = '/src/state/documentStore.ts', t = '/src/state/transportStore.ts', f = '/src/domain/projectFile.ts'
  21  |     const state = (await import(d)).useDocumentStore.getState(), transport = (await import(t)).useTransportStore.getState(), files = await import(f)
  22  |     const clip = state.doc.tracks[0].clips[0]
  23  |     return { clip, past: state.past.length, future: state.future.length, previewOwner: transport.effectDocumentPreview?.owner ?? null,
  24  |       history: JSON.stringify({ past: state.past, future: state.future }),
  25  |       wire: files.serializeProjectFile(files.createProjectFileSnapshot(state.project, [], [])) }
  26  |   })
  27  | }
  28  | test('compact upgrade, elements, static editing and real project undo/redo', async ({ page }, info) => {
  29  |   await enter(page, false)
  30  |   const before = await snapshot(page)
  31  |   await page.getByRole('button', { name: 'Upgrade to title', exact: true }).click()
> 32  |   await page.getByLabel('Text content', { exact: true }).fill('G3 title 世界')
      |                                                          ^ Error: locator.fill: Test timeout of 60000ms exceeded.
  33  |   await page.getByLabel('Text content', { exact: true }).press('Tab')
  34  |   await page.getByRole('button', { name: 'Add rectangle', exact: true }).click()
  35  |   await page.getByRole('checkbox', { name: /Rectangle rectangle/ }).check()
  36  |   await page.getByTestId('title-opacity').fill('0.5'); await page.getByTestId('title-opacity').press('Tab')
  37  |   await page.getByRole('button', { name: 'Move Rectangle backward' }).click()
  38  |   const after = await snapshot(page)
  39  |   expect(after.past - before.past).toBe(5)
  40  |   expect(after.clip.text).toBeUndefined()
  41  |   expect(after.clip.title.elements.map((e: { kind: string; opacity: number }) => [e.kind, e.opacity])).toEqual([['rectangle', .5], ['text', .5]])
  42  |   await page.screenshot({ path: info.outputPath('elements-1280.png') })
  43  |   await page.getByRole('button', { name: 'Commands', exact: true }).click()
  44  |   await page.getByRole('searchbox', { name: 'Search commands' }).fill('Undo')
  45  |   await page.getByRole('button', { name: 'Undo', exact: true }).click()
  46  |   expect((await snapshot(page)).clip.title.elements[0].kind).toBe('text')
  47  |   await page.getByRole('button', { name: 'Commands', exact: true }).click()
  48  |   await page.getByRole('searchbox', { name: 'Search commands' }).fill('Redo')
  49  |   await page.getByRole('button', { name: 'Redo', exact: true }).click()
  50  |   expect((await snapshot(page)).wire).toBe(after.wire)
  51  | })
  52  | test('direct manipulation, Escape cancellation and editor-only safe guides', async ({ page }, info) => {
  53  |   await enter(page)
  54  |   const handle = page.getByRole('button', { name: 'Move title element Text', exact: true })
  55  |   await expect(handle).toBeVisible()
  56  |   const before = await snapshot(page), bounds = await handle.boundingBox()
  57  |   expect(bounds).not.toBeNull()
  58  |   await page.mouse.move(bounds!.x + bounds!.width / 2, bounds!.y + bounds!.height / 2)
  59  |   await page.mouse.down(); await page.mouse.move(bounds!.x + bounds!.width / 2 + 20, bounds!.y + bounds!.height / 2 + 10, { steps: 4 }); await page.mouse.up()
  60  |   const moved = await snapshot(page)
  61  |   expect(moved.past).toBe(before.past + 1); expect(moved.clip.title.elements[0].transform.x).toBeGreaterThan(0)
  62  |   const next = await handle.boundingBox()
  63  |   await page.mouse.move(next!.x + next!.width / 2, next!.y + next!.height / 2); await page.mouse.down(); await page.mouse.move(next!.x + next!.width / 2 + 20, next!.y + next!.height / 2)
  64  |   await page.keyboard.press('Escape'); await page.mouse.up()
  65  |   expect((await snapshot(page)).wire).toBe(moved.wire)
  66  |   await page.getByRole('checkbox', { name: /Safe guides/ }).check()
  67  |   expect((await snapshot(page)).wire).toBe(moved.wire)
  68  |   await expect(page.getByTestId('title-safe-0.9')).toBeVisible(); await expect(page.getByTestId('title-safe-0.95')).toBeVisible()
  69  |   await page.screenshot({ path: info.outputPath('guides-and-handles.png') })
  70  |   await page.evaluate(async () => {
  71  |     const d = '/src/state/documentStore.ts', t = '/src/state/transportStore.ts'
  72  |     const store = (await import(d)).useDocumentStore, project = structuredClone(store.getState().project)
  73  |     const clip = project.sequences[0].tracks[0].clips[0], element = clip.title.elements[0]
  74  |     const values = { 'position-x': element.transform.x, 'position-y': element.transform.y, 'box-width': element.text.boxWidthPx, 'box-height': element.text.boxHeightPx }
  75  |     clip.animation = { ...clip.animation, titleTracks: Object.entries(values).map(([property, value]) => ({ elementId: element.id, propertyVersion: 1, property,
  76  |       keyframes: [{ frame: 0, value, easing: { type: 'linear' } }, { frame: 99, value: Number(value) + 100, easing: { type: 'linear' } }] })) }
  77  |     store.getState().setProject(project); (await import(t)).useTransportStore.getState().setPlayheadFrame(50)
  78  |   })
  79  |   const observations: unknown[] = []
  80  |   for (const mode of ['Move', 'Resize']) {
  81  |     const control = page.getByRole('button', { name: `${mode} title element Text`, exact: true })
  82  |     await expect(control).toBeVisible()
  83  |     await control.evaluate((element) => {
  84  |       const data: { down: { pointerId: number; trusted: boolean } | null; loss: { pointerId: number; trusted: boolean } | null; moves: { pointerId: number; trusted: boolean; buttons: number }[]; clickTrusted: boolean | null } = { down: null, loss: null, moves: [], clickTrusted: null }
  85  |       const down = (event: Event) => { const e = event as PointerEvent; data.down = { pointerId: e.pointerId, trusted: e.isTrusted } }
  86  |       const lost = (event: Event) => { const e = event as PointerEvent; data.loss = { pointerId: e.pointerId, trusted: e.isTrusted } }
  87  |       const move = (event: PointerEvent) => { if (data.moves.length < 32) data.moves.push({ pointerId: event.pointerId, trusted: event.isTrusted, buttons: event.buttons }) }
  88  |       const click = (event: Event) => { data.clickTrusted = event.isTrusted }
  89  |       element.addEventListener('pointerdown', down); element.addEventListener('lostpointercapture', lost); element.addEventListener('click', click)
  90  |       window.addEventListener('pointermove', move)
  91  |       Object.assign(element, { g3CaptureProbe: { data, dispose: () => { element.removeEventListener('pointerdown', down); element.removeEventListener('lostpointercapture', lost); element.removeEventListener('click', click); window.removeEventListener('pointermove', move) } } })
  92  |     })
  93  |     const probe = () => control.evaluate((element) => (element as HTMLElement & { g3CaptureProbe: { data: { down: { pointerId: number; trusted: boolean } | null; loss: { pointerId: number; trusted: boolean } | null; moves: { pointerId: number; trusted: boolean; buttons: number }[]; clickTrusted: boolean | null } } }).g3CaptureProbe.data)
  94  |     const observation: Record<string, unknown> = { mode }
  95  |     observations.push(observation)
  96  |     try {
  97  |       const clickBefore = await snapshot(page)
  98  |       await control.click()
  99  |       expect((await probe()).clickTrusted).toBe(true)
  100 |       const clicked = await snapshot(page)
  101 |       expect({ wire: clicked.wire, past: clicked.past, future: clicked.future, history: clicked.history }).toEqual({ wire: clickBefore.wire, past: clickBefore.past, future: clickBefore.future, history: clickBefore.history })
  102 |       expect(clicked.previewOwner).toBeNull()
  103 |       observation.clickPreservedProjectAndHistory = true
  104 |       observation.click = await probe()
  105 |       await control.evaluate((element) => { const probe = (element as HTMLElement & { g3CaptureProbe: { data: { down: unknown; loss: unknown; moves: unknown[] } } }).g3CaptureProbe; probe.data.down = null; probe.data.loss = null; probe.data.moves = [] })
  106 |       const beforeLoss = await snapshot(page), box = await control.boundingBox()
  107 |       expect(box).not.toBeNull()
  108 |       const x = box!.x + box!.width / 2, y = box!.y + box!.height / 2
  109 |       await page.mouse.move(x, y); await page.mouse.down(); await page.mouse.move(x + 8, y + 4, { steps: 2 })
  110 |       await expect.poll(async () => (await snapshot(page)).previewOwner).toBe('title-authoring')
  111 |       const releasedPointer = await control.evaluate((element) => {
  112 |         const probe = (element as HTMLElement & { g3CaptureProbe: { data: { down: { pointerId: number; trusted: boolean } | null; moves: unknown[] } } }).g3CaptureProbe
  113 |         const down = probe.data.down
  114 |         if (!down?.trusted || !element.hasPointerCapture(down.pointerId)) throw new Error('The actual pointer never acquired capture.')
  115 |         probe.data.moves = [] // Evidence below can only come from the next native held move.
  116 |         element.releasePointerCapture(down.pointerId)
  117 |         return down.pointerId
  118 |       })
  119 |       observation.releasedPointer = releasedPointer
  120 |       // A release request is not event proof: the next real move still holds the same mouse button.
  121 |       await page.mouse.move(x + 16, y + 8)
  122 |       await expect.poll(async () => (await probe()).loss?.trusted).toBe(true)
  123 |       const captured = await probe()
  124 |       observation.beforeMouseUp = captured
  125 |       expect(captured.loss?.pointerId).toBe(releasedPointer)
  126 |       expect(captured.moves.some((event) => event.trusted && event.pointerId === releasedPointer && (event.buttons & 1) === 1)).toBe(true)
  127 |       expect((await snapshot(page)).previewOwner).toBeNull()
  128 |       await page.mouse.up()
  129 |       const afterLoss = await snapshot(page)
  130 |       expect({ wire: afterLoss.wire, past: afterLoss.past, future: afterLoss.future, history: afterLoss.history }).toEqual({ wire: beforeLoss.wire, past: beforeLoss.past, future: beforeLoss.future, history: beforeLoss.history })
  131 |       observation.lossAndLateUpPreservedProjectAndHistory = true
  132 |     } finally {
```