# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: keyboard.gate.ts >> 1280x720 >> keyboard title controls and status
- Location: tests/diagnostics/issue200/keyboard.gate.ts:327:5

# Error details

```
Error: safe-guides label clipped

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Test source

```ts
  1   | /** Four independent native-keyboard cases. No corrective focus/scroll/store writes. */
  2   | import { test, expect, type Page, type TestInfo, type Locator } from '@playwright/test'
  3   | import { writeFile } from 'node:fs/promises'
  4   | import type * as Client from './keyboard-client'
  5   | import { inside, requireNativeKeys, requireSessionLedger, requireTabBudget } from './keyboard-model'
  6   | 
  7   | type State = ReturnType<typeof Client.snapshot>
  8   | type Run = { warnings: unknown[]; errors: unknown[]; pageErrors: string[]; cleanupErrors: string[]; events: unknown[]; tabs: number; images: string[]; probe: boolean }
  9   | const runs = new Map<string, Run>()
  10  | function run() { const value = runs.get(test.info().testId); if (!value) throw new Error('Run missing'); return value }
  11  | async function call<K extends keyof typeof Client>(page: Page, method: K, ...args: Parameters<typeof Client[K]>): Promise<Awaited<ReturnType<typeof Client[K]>>> {
  12  |   return page.evaluate(async ({ method, args }) => {
  13  |     const path = '/tests/diagnostics/issue200/keyboard-client.ts'
  14  |     return (await import(path))[method](...args)
  15  |   }, { method, args })
  16  | }
  17  | async function json(info: TestInfo, name: string, value: unknown) {
  18  |   const path = info.outputPath(name)
  19  |   await writeFile(path, JSON.stringify(value, null, 2) + '\n')
  20  |   if (!info.attachments.some((item) => item.path === path)) await info.attach(name, { path, contentType: 'application/json' })
  21  | }
  22  | async function state(page: Page, label: string) {
  23  |   const value = await call(page, 'snapshot')
  24  |   run().events.push({ kind: 'state', label, value })
  25  |   await call(page, 'checkSession')
  26  |   return value
  27  | }
  28  | function unchanged(before: State, after: State) {
  29  |   expect({ wire: after.wire, history: after.history, frame: after.frame, generation: after.generation, sequenceId: after.sequenceId })
  30  |     .toEqual({ wire: before.wire, history: before.history, frame: before.frame, generation: before.generation, sequenceId: before.sequenceId })
  31  | }
  32  | function oneEdit(before: State, after: State) {
  33  |   expect(after.wire).not.toBe(before.wire)
  34  |   expect(after.past).toBe(before.past + 1); expect(after.future).toBe(0)
  35  |   const a = JSON.parse(after.history), b = JSON.parse(before.history)
  36  |   expect(a.past.slice(0, -1)).toEqual(b.past)
  37  |   expect(after.frame).toBe(before.frame); expect(after.generation).toBe(before.generation)
  38  | }
  39  | function elements(value: State) {
  40  |   const title = value.clip.title
  41  |   if (!title || title.version !== 1 || !Array.isArray(title.elements)) throw new Error('Expected bounded title')
  42  |   return title.elements
  43  | }
  44  | function textElement(value: State) {
  45  |   const e = elements(value).find((element) => element.id === 'root-element')
  46  |   if (!e || e.version !== 1 || e.kind !== 'text') throw new Error('Original text element missing')
  47  |   return e
  48  | }
  49  | function onlyElementsChange(before: State, after: State, expected: ReturnType<typeof elements>) {
  50  |   const project = structuredClone(before.project)
  51  |   project.sequences[0].tracks[0].clips[0].title = { version: 1, elements: expected }
  52  |   expect(after.project).toEqual(project)
  53  | }
  54  | async function recordFocus(page: Page, label: string) {
  55  |   const focus = await call(page, 'active')
  56  |   run().events.push({ kind: 'focus', label, focus })
  57  |   return focus
  58  | }
  59  | async function tab(page: Page, targetSteps: number, backwards = false) {
  60  |   requireTabBudget(targetSteps, ++run().tabs)
  61  |   await page.keyboard.press(backwards ? 'Shift+Tab' : 'Tab')
  62  |   return recordFocus(page, backwards ? 'Shift+Tab' : 'Tab')
  63  | }
  64  | async function seek(page: Page, target: Locator, name: string, backwards = false) {
  65  |   await expect(target).toHaveCount(1)
  66  |   for (let steps = 0; steps <= 128; steps++) {
  67  |     if (await target.evaluate((node) => node === document.activeElement)) return recordFocus(page, name)
  68  |     if (steps === 128) throw new Error(`Could not keyboard-reach ${name}`)
  69  |     await tab(page, steps + 1, backwards)
  70  |   }
  71  |   throw new Error(`Unreachable traversal: ${name}`)
  72  | }
  73  | async function screenshot(page: Page, label: string) {
  74  |   const info = test.info(), path = info.outputPath(`${run().images.length.toString().padStart(2, '0')}-${label}.png`)
  75  |   await page.screenshot({ path }); run().images.push(path)
  76  |   await info.attach(label, { path, contentType: 'image/png' })
  77  |   await json(info, 'keyboard-evidence.json', run())
  78  | }
  79  | async function focused(page: Page, target: Locator, label: string, backwards = false) {
  80  |   await seek(page, target, label, backwards)
  81  |   const evidence = await call(page, 'inspectFocused'), layout = await call(page, 'titleLayout')
  82  |   run().events.push({ kind: 'control', label, evidence, layout, accessibility: await target.ariaSnapshot() })
  83  |   await screenshot(page, label)
  84  |   expect(evidence.fullyVisible, `${label} clipped`).toBe(true)
  85  |   expect(evidence.focusVisible, `${label} lacks focus-visible`).toBe(true)
  86  |   expect(evidence.outline.width).toBeGreaterThan(0); expect(evidence.outline.style).not.toBe('none')
  87  |   expect(evidence.outline.measured.ratio, `${label} focus contrast`).toBeGreaterThanOrEqual(3)
  88  |   if (evidence.text.trim() || evidence.value) expect(evidence.paint.measured.ratio, `${label} text contrast`).toBeGreaterThanOrEqual(4.5)
  89  |   for (const item of evidence.labels) {
> 90  |     expect(item.fullyVisible, `${label} label clipped`).toBe(true)
      |                                                         ^ Error: safe-guides label clipped
  91  |     expect(item.paint.measured.ratio, `${label} label contrast`).toBeGreaterThanOrEqual(4.5)
  92  |     for (const inline of item.inlineText) { expect(inline.fullyVisible).toBe(true); expect(inline.paint.measured.ratio).toBeGreaterThanOrEqual(4.5) }
  93  |   }
  94  |   for (const item of layout.containers) expect(item.scrollWidth, `${item.className} horizontal overflow`).toBeLessThanOrEqual(item.width + 1)
  95  |   return evidence
  96  | }
  97  | const button = (page: Page, name: string) => page.getByRole('button', { name, exact: true })
  98  | async function activate(page: Page, name: string, backwards = false) { await focused(page, button(page, name), name.replaceAll(/[^a-z0-9]+/gi, '-'), backwards); await page.keyboard.press('Enter') }
  99  | async function type(page: Page, value: string) { await page.keyboard.press('ControlOrMeta+A'); await page.keyboard.type(value) }
  100 | 
  101 | /** Canonical G3 portable leave/open/activate and selection, with fixed frame 12. */
  102 | async function openPortableTitle(page: Page, wire: string, frame: number) {
  103 |   const evidence = await page.evaluate(async ({ wire, frame }) => {
  104 |     const p = '/src/app/projectController.ts', d = '/src/state/documentStore.ts', f = '/src/domain/projectFile.ts'
  105 |     const t = '/src/state/transportStore.ts', s = '/src/state/titleEditorStore.ts', session = '/src/state/projectSessionStore.ts'
  106 |     const lifecycle = await import(p), files = await import(f), store = (await import(d)).useDocumentStore
  107 |     const left = await lifecycle.leaveActiveProject()
  108 |     if (left.status !== 'ready') throw new Error(JSON.stringify(left))
  109 |     const opened = await lifecycle.openProjectFile(new File([wire], 'title-keyboard.myrelith', { type: 'application/json' }))
  110 |     if (opened.status !== 'ready') throw new Error(JSON.stringify(opened))
  111 |     const activated = await lifecycle.activateResumedProject()
  112 |     if (activated.status !== 'activated') throw new Error(JSON.stringify(activated))
  113 |     const state = store.getState(), transport = (await import(t)).useTransportStore
  114 |     const clip = state.doc.tracks[0].clips[0]
  115 |     transport.getState().setSelectedClip(clip.id); transport.getState().setPlayheadFrame(frame)
  116 |     ;(await import(s)).useTitleEditorStore.getState().select(clip.id, clip.title?.elements.slice(0, 1).map((element: { id: string }) => element.id) ?? [])
  117 |     const active = (await import(session)).useProjectSessionStore.getState()
  118 |     return { left: left.status, opened: opened.status, activated: activated.status, past: state.past.length, future: state.future.length,
  119 |       wire: files.serializeProjectFile(files.createProjectFileSnapshot(state.project, [], [])),
  120 |       session: { screen: active.screen, phase: active.phase, error: active.error, saveError: active.saveError, recoveryError: active.recoveryError } }
  121 |   }, { wire, frame })
  122 |   run().events.push({ kind: 'canonical-entry', evidence })
  123 |   expect(evidence).toEqual({ left: 'ready', opened: 'ready', activated: 'activated', past: 0, future: 0, wire,
  124 |     session: { screen: 'editor', phase: 'idle', error: null, saveError: null, recoveryError: null } })
  125 | }
  126 | async function enter(page: Page) {
  127 |   await page.goto('/')
  128 |   await page.getByRole('button', { name: 'Start a new project' }).click()
  129 |   await page.getByLabel('Project name').fill('Title keyboard evidence')
  130 |   await page.getByLabel('Resolution').selectOption('720')
  131 |   await button(page, 'Create project').click()
  132 |   await expect(button(page, 'Commands')).toBeVisible()
  133 |   await call(page, 'observe'); run().probe = true
  134 |   const fixture = await call(page, 'fixture')
  135 |   run().events.push({ kind: 'fixed-fixture', fixture })
  136 |   await openPortableTitle(page, fixture.wire, fixture.frame)
  137 |   const before = await state(page, 'before-declared-layout-setup')
  138 |   await button(page, 'Focus Inspector').click()
  139 |   await expect(button(page, 'Focus Inspector')).toHaveAttribute('aria-pressed', 'true')
  140 |   unchanged(before, await state(page, 'after-declared-layout-setup'))
  141 |   run().events.push({ kind: 'keyboard-boundary', layout: await call(page, 'titleLayout') })
  142 | }
  143 | async function status(page: Page, expected: string, label: string) {
  144 |   await expect(page.getByRole('region', { name: 'Title authoring' }).getByRole('status')).toContainText(expected)
  145 |   const evidence = await call(page, 'statuses')
  146 |   run().events.push({ kind: 'status', label, evidence, accessibility: await page.getByRole('region', { name: 'Title authoring' }).ariaSnapshot() })
  147 |   await screenshot(page, label)
  148 |   expect(evidence.length).toBeGreaterThan(0)
  149 |   for (const item of evidence) { expect(item.fullyVisible).toBe(true); expect(item.paint.measured.ratio).toBeGreaterThanOrEqual(4.5) }
  150 | }
  151 | 
  152 | async function controls(page: Page) {
  153 |   await enter(page)
  154 |   const initial = await state(page, 'initial'), textChoice = page.getByRole('checkbox', { name: 'Text text', exact: true })
  155 |   const disabled = { deleteOnlyElement: await button(page, 'Delete elements').isDisabled(), moveFirstBackward: await button(page, 'Move Text backward').isDisabled(), moveLastForward: await button(page, 'Move Text forward').isDisabled() }
  156 |   run().events.push({ kind: 'disabled-boundaries', disabled }); expect(disabled).toEqual({ deleteOnlyElement: true, moveFirstBackward: true, moveLastForward: true })
  157 |   await focused(page, textChoice, 'text-selection')
  158 |   expect(initial.selectedElements).toEqual(['root-element'])
  159 |   await activate(page, 'Add rectangle')
  160 |   const added = await state(page, 'added'); oneEdit(initial, added)
  161 |   const addedElements = elements(added), rectId = addedElements[1].id
  162 |   expect(addedElements.map((e) => e.kind)).toEqual(['text', 'rectangle']); expect(rectId).not.toBe('root-element')
  163 |   onlyElementsChange(initial, added, [...elements(initial), addedElements[1]])
  164 |   await focused(page, page.getByRole('checkbox', { name: 'Rectangle rectangle', exact: true }), 'rectangle-selection', true)
  165 |   await page.keyboard.press('Space')
  166 |   const multi = await state(page, 'selected-both'); unchanged(added, multi); expect(multi.selectedElements).toEqual(['root-element', rectId])
  167 |   await focused(page, textChoice, 'text-deselection', true); await page.keyboard.press('Space')
  168 |   const selected = await state(page, 'selected-rectangle'); unchanged(multi, selected); expect(selected.selectedElements).toEqual([rectId])
  169 |   await activate(page, 'Move Rectangle backward')
  170 |   const ordered = await state(page, 'ordered'); oneEdit(selected, ordered); expect(elements(ordered).map((e) => e.id)).toEqual([rectId, 'root-element'])
  171 |   onlyElementsChange(selected, ordered, [addedElements[1], addedElements[0]])
  172 |   await activate(page, 'Delete elements')
  173 |   const deleted = await state(page, 'deleted'); oneEdit(ordered, deleted); expect(elements(deleted)).toEqual(elements(initial))
  174 |   expect(deleted.project).toEqual(initial.project)
  175 |   await focused(page, page.getByRole('spinbutton', { name: 'Position X', exact: true }), 'position-x')
  176 |   await type(page, '20'); await page.keyboard.press('Enter')
  177 |   const entered = await state(page, 'number-enter'); oneEdit(deleted, entered); expect(textElement(entered).transform.x).toBe(20)
  178 |   onlyElementsChange(deleted, entered, [{ ...textElement(deleted), transform: { ...textElement(deleted).transform, x: 20 } }])
  179 |   await tab(page, 1); unchanged(entered, await state(page, 'number-blur'))
  180 |   await focused(page, page.getByRole('spinbutton', { name: 'Position X', exact: true }), 'position-x-cancel', true)
  181 |   await type(page, '45'); await page.keyboard.press('Escape'); await tab(page, 1)
  182 |   unchanged(entered, await state(page, 'number-escape'))
  183 |   await focused(page, button(page, 'Move title element Text'), 'move-title', true)
  184 |   await page.keyboard.press('ArrowRight'); const right = await state(page, 'move-right'); oneEdit(entered, right); expect(textElement(right).transform.x).toBe(21)
  185 |   onlyElementsChange(entered, right, [{ ...textElement(entered), transform: { ...textElement(entered).transform, x: 21 } }])
  186 |   await page.keyboard.press('Shift+ArrowUp'); const up = await state(page, 'move-up'); oneEdit(right, up); expect(textElement(up).transform.y).toBe(-10)
  187 |   onlyElementsChange(right, up, [{ ...textElement(right), transform: { ...textElement(right).transform, y: -10 } }])
  188 |   await focused(page, button(page, 'Resize title element Text'), 'resize-title')
  189 |   await page.keyboard.press('ArrowRight'); const resized = await state(page, 'resize-right'); oneEdit(up, resized); expect(textElement(resized).text.boxWidthPx).toBe(802)
  190 |   onlyElementsChange(up, resized, [{ ...textElement(up), text: { ...textElement(up).text, boxWidthPx: 802 } }])
```