import copy, hashlib, json, pathlib, zipfile
root=pathlib.Path('/private/tmp/issue200-keyboard-4727236-01')
manifest=json.loads((root/'artifact-manifest.json').read_text())
for record in manifest['files']:
 data=(root/record['path']).read_bytes()
 assert len(data)==record['bytes'] and hashlib.sha256(data).hexdigest()==record['sha256']
evidence=json.loads(next(root.rglob('keyboard-evidence.json')).read_text())
states={e['label']:e['value'] for e in evidence['events'] if e['kind']=='state'}
def unchanged(a,b):
 for key in ['wire','history','frame','generation','sequenceId']:assert states[a][key]==states[b][key],(a,b,key)
def edit(a,b):
 before,after=states[a],states[b]
 assert before['wire']!=after['wire'] and after['past']==before['past']+1 and after['future']==0
 assert json.loads(after['history'])['past'][:-1]==json.loads(before['history'])['past']
 assert after['frame']==before['frame'] and after['generation']==before['generation']
def elements(label):return states[label]['clip']['title']['elements']
def only_elements(a,b,expected):
 p=copy.deepcopy(states[a]['project']);p['sequences'][0]['tracks'][0]['clips'][0]['title']={'version':1,'elements':expected}
 assert states[b]['project']==p,(a,b)
for a,b in [('before-declared-layout-setup','after-declared-layout-setup'),('added','selected-both'),('selected-both','selected-rectangle'),('number-enter','number-blur'),('number-enter','number-escape'),('undo-resize','guides-on'),('guides-on','no-fallback')]:unchanged(a,b)
for a,b in [('initial','added'),('selected-rectangle','ordered'),('ordered','deleted'),('deleted','number-enter'),('number-enter','move-right'),('move-right','move-up'),('move-up','resize-right')]:edit(a,b)
initial,added=elements('initial'),elements('added');rect=added[1]
assert [e['kind']for e in added]==['text','rectangle'] and rect['id']!='root-element'
only_elements('initial','added',initial+[rect]);only_elements('selected-rectangle','ordered',[rect,initial[0]])
only_elements('ordered','deleted',initial);assert states['deleted']['project']==states['initial']['project']
assert states['selected-both']['selectedElements']==['root-element',rect['id']]
assert states['selected-rectangle']['selectedElements']==[rect['id']]
for a,b,field,key,value in [('deleted','number-enter','transform','x',20),('number-enter','move-right','transform','x',21),('move-right','move-up','transform','y',-10),('move-up','resize-right','text','boxWidthPx',802)]:
 expected=copy.deepcopy(elements(a));expected[0][field][key]=value;only_elements(a,b,expected)
u,up=states['undo-resize'],states['move-up'];assert u['wire']==up['wire'] and u['past']==up['past'] and u['future']==1
assert json.loads(u['history'])['past']==json.loads(up['history'])['past']
assert not u['guides'] and states['guides-on']['guides']
control=next(e['evidence']for e in evidence['events']if e['kind']=='control' and e['label']=='safe-guides')
assert control['fullyVisible'] and control['focusVisible'] and all(e['fullyVisible']for e in control['labels'])
label=control['labels'][0];region=label['region'];assert label['rect']['y']+label['rect']['height']<=region['y']+region['height']
g=next(e['evidence']for e in evidence['events']if e['kind']=='safe-guide-geometry');assert [e['ratio']for e in g['guides']]==[.9,.95]
for e in g['guides']:
 assert e['ariaHidden']=='true' and e['stroke']=='dashed'
 for key in ['x','y','width','height']:
  expected=g['canvas'][key]*e['ratio'] if key in ['width','height'] else g['canvas'][key]+g['canvas']['width'if key=='x'else'height']*(1-e['ratio'])/2
  assert abs(e['bounds'][key]-expected)<.05
fallback=next(e['evidence']for e in evidence['events']if e['kind']=='control' and e['label']=='fallback')
released=next(e['released']for e in evidence['events']if e['kind']=='observer-release')
assert released['disposed'] and released['subscriptions']==0 and not released['issues'] and released['dropped']==released['droppedKeys']==0
assert all(e['healthy']for e in released['events']) and all(k['trusted']for k in released['keys'])
last=released['keys'][-1];assert last['key']=='Home' and last['targetId']==fallback['id'] and fallback['value']=='serif'
font=elements('no-fallback')[0]['font'];assert font=={'family':'Missing Keyboard Face','fallbackFamily':'serif'}
assert all(evidence[key]==[]for key in ['warnings','errors','pageErrors','cleanupErrors'])
report=json.loads((root/'playwright-report.json').read_text());results=[]
def walk(suites):
 for suite in suites:
  for spec in suite.get('specs',[]):
   for test in spec['tests']:results.extend(test['results'])
  walk(suite.get('suites',[]))
walk(report['suites']);attachments=[a for r in results for a in r.get('attachments',[])]
assert all(pathlib.Path(a['path']).is_file()for a in attachments)
trace=next(root.rglob('trace.zip'))
with zipfile.ZipFile(trace)as z:assert z.testzip()is None;trace_count=len(z.namelist())
audit={'testedHead':'47272362c6d65a1f0a75d4527642d0c8e3de6816','result':'0 complete cases passed; 1 failed; 3 unrun; zero retries',
'originalFiles':len(manifest['files']),'originalBytes':sum(r['bytes']for r in manifest['files']),'allOriginalHashesVerified':True,
'reportedAttachments':len(attachments),'allAttachmentPathsExist':True,'traceMembers':trace_count,'traceCrcValid':True,
'stateSnapshots':len(states),'verifiedAcceptedEditsBeforeFailure':7,'undoRestoresExactProjectAndPast':True,'tabs':evidence['tabs'],
'sessionEvents':len(released['events']),'trustedNativeKeys':len(released['keys']),'browserProblems':0,'observerSubscriptionsAfterRelease':0,
'safeGuidesControl':control,'safeGuideGeometry':g,'safeGuideActivationPreservesFullProjectAndHistory':True,
'fallbackBeforeHome':fallback,'lastTrustedKey':last,'fontAfterHome':font,'unchangedProjectAndFullHistoryAfterHome':True,
'qualification':'Home on the closed select did not commit a selection. This observation alone does not establish a product bug. Later font/status, dialogs and narrow cases did not run.'}
(root/'offline-assertion-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
groups=json.loads((root/'png-identity-groups.json').read_text())
visual={'reviewedDistinctImages':len(groups),'pngCopies':sum(map(len,groups.values())),'allDistinctImagesViewed':True,
'images':[{'sha256':h,'representative':paths[0],'copies':len(paths)}for h,paths in groups.items()],
'observations':['All 16 distinct PNGs viewed individually, including native checkbox/button/select outlines and canvas move/resize focus indicators.',
'Safe-guides label and focused checkbox fit within the Inspector after native scrolling; checked-state screenshot shows both dashed guides.',
'Fallback screenshot shows serif selected with a visible focus indicator. Failure screenshot still shows serif. End screenshot retains the platform-dependent serif status.',
'Native Home causes viewport/scroll observations to differ across the retained end/failure images; no selection commit is inferred from their layout.',
'General workspace truncation, meter overlap and Program notice overlay are retained for supervisor disposition. No whole-workspace accessibility certification or pixel-exact native focus-ring claim.']}
(root/'offline-visual-review.json').write_text(json.dumps(visual,indent=2)+'\n')
print(json.dumps({k:v for k,v in audit.items()if k not in ['safeGuidesControl','safeGuideGeometry','fallbackBeforeHome']},indent=2))
