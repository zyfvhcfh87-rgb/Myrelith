# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: keyboard.gate.ts >> 1280x720 >> keyboard title controls and status
- Location: tests/diagnostics/issue200/keyboard.gate.ts:327:5

# Error details

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "{\"assets\":[],\"collections\":[],\"colorLuts\":[],\"format\":\"myrelith-project\",\"formatVersion\":8,\"id\":\"title-project\",\"multicams\":[],\"name\":\"Title project\",\"rootSequenceId\":\"root\",\"sequences\":[{\"audioSampleRate\":48000,\"captionTracks\":[],\"frameRate\":{\"den\":1,\"num\":30},\"height\":1080,\"id\":\"root\",\"markers\":[],\"masterAudio\":{\"audioEffects\":[],\"balance\":0,\"muted\":false,\"volume\":1},\"masterVideoEffects\":[],\"name\":\"root\",\"schemaVersion\":24,\"tracks\":[{\"adjustments\":[],\"audioEffects\":[],\"balance\":0,\"clips\":[{\"animation\":{\"effectTracks\":[],\"tracks\":[]},\"assetId\":\"__myrelith_text__:root-text\",\"audio\":{\"balance\":0,\"enabled\":true,\"fadeInFrames\":0,\"fadeOutFrames\":0},\"audioEffects\":[],\"blendMode\":\"normal\",\"effects\":[],\"id\":\"root-text\",\"lensCorrection\":null,\"name\":\"Title 世界\",\"opacity\":1,\"sourceMode\":\"timed\",\"sourceRange\":{\"durationFrames\":100,\"startFrame\":0},\"sourceTimeMap\":{\"rate\":{\"denominator\":1,\"numerator\":1},\"sourceDurationTicks\":100000000,\"sourceStartTicks\":0,\"speedCurve\":{\"originFrame\":0,\"points\":[]}},\"timelineRange\":{\"durationFrames\":100,\"startFrame\":0},\"title\":{\"elements\":[{\"enabled\":true,\"font\":{\"fallbackFamily\":\"serif\",\"family\":\"Missing Keyboard Face\"},\"id\":\"root-element\",\"kind\":\"text\",\"name\":\"Text\",\"opacity\":1,\"text\":{\"align\":\"center\",\"backgroundColor\":\"#000000\",\"backgroundEnabled\":false,\"bold\":true,\"boxHeightPx\":180,\"boxWidthPx\":800,\"color\":\"#ffffff\",\"content\":\"Keyboard title\",\"fontSizePx\":48,\"italic\":false,\"outlineColor\":\"#000000\",\"outlineEnabled\":true,\"outlineWidthPx\":2,\"paddingPx\":18,\"shadowBlurPx\":4,\"shadowColor\":\"#000000\",\"shadowEnabled\":true,\"shadowOffsetXPx\":2,\"shadowOffsetYPx\":2},\"transform\":{\"anchorX\":0.5,\"anchorY\":0.5,\"rotation\":0,\"scaleX\":1,\"scaleY\":1,\"x\":21,\"y\":-10},\"version\":1,\"visual\":{\"crop\":{\"bottom\":0,\"left\":0,\"right\":0,\"top\":0},\"flipHorizontal\":false,\"flipVertical\":false,\"scaleLocked\":true}}],\"version\":1},\"transform\":{\"anchorX\":0.5,\"anchorY\":0.5,\"rotation\":0,\"scaleX\":1,\"scaleY\":1,\"x\":0,\"y\":0},\"visual\":{\"crop\":{\"bottom\":0,\"left\":0,\"right\":0,\"top\":0},\"flipHorizontal\":false,\"flipVertical\":false,\"scaleLocked\":true},\"volume\":1}],\"hidden\":false,\"id\":\"root-V1\",\"kind\":\"video\",\"locked\":false,\"multicamInstances\":[],\"muted\":false,\"name\":\"V1\",\"sequenceInstances\":[],\"solo\":false,\"transitions\":[],\"videoEffects\":[],\"volume\":1},{\"adjustments\":[],\"audioEffects\":[],\"balance\":0,\"clips\":[],\"hidden\":false,\"id\":\"root-V2\",\"kind\":\"video\",\"locked\":false,\"multicamInstances\":[],\"muted\":false,\"name\":\"V2\",\"sequenceInstances\":[],\"solo\":false,\"transitions\":[],\"videoEffects\":[],\"volume\":1},{\"adjustments\":[],\"audioEffects\":[],\"balance\":0,\"clips\":[],\"hidden\":false,\"id\":\"root-V3\",\"kind\":\"video\",\"locked\":false,\"multicamInstances\":[],\"muted\":false,\"name\":\"V3\",\"sequenceInstances\":[],\"solo\":false,\"transitions\":[],\"videoEffects\":[],\"volume\":1},{\"adjustments\":[],\"audioEffects\":[],\"balance\":0,\"clips\":[],\"hidden\":false,\"id\":\"root-V4\",\"kind\":\"video\",\"locked\":false,\"multicamInstances\":[],\"muted\":false,\"name\":\"V4\",\"sequenceInstances\":[],\"solo\":false,\"transitions\":[],\"videoEffects\":[],\"volume\":1},{\"adjustments\":[],\"audioEffects\":[],\"balance\":0,\"clips\":[],\"hidden\":false,\"id\":\"root-A1\",\"kind\":\"audio\",\"locked\":false,\"multicamInstances\":[],\"muted\":false,\"name\":\"A1\",\"sequenceInstances\":[],\"solo\":false,\"transitions\":[],\"videoEffects\":[],\"volume\":1},{\"adjustments\":[],\"audioEffects\":[],\"balance\":0,\"clips\":[],\"hidden\":false,\"id\":\"root-A2\",\"kind\":\"audio\",\"locked\":false,\"multicamInstances\":[],\"muted\":false,\"name\":\"A2\",\"sequenceInstances\":[],\"solo\":false,\"transitions\":[],\"videoEffects\":[],\"volume\":1},{\"adjustments\":[],\"audioEffects\":[],\"balance\":0,\"clips\":[],\"hidden\":false,\"id\":\"root-A3\",\"kind\":\"audio\",\"locked\":false,\"multicamInstances\":[],\"muted\":false,\"name\":\"A3\",\"sequenceInstances\":[],\"solo\":false,\"transitions\":[],\"videoEffects\":[],\"volume\":1},{\"adjustments\":[],\"audioEffects\":[],\"balance\":0,\"clips\":[],\"hidden\":false,\"id\":\"root-A4\",\"kind\":\"audio\",\"locked\":false,\"multicamInstances\":[],\"muted\":false,\"name\":\"A4\",\"sequenceInstances\":[],\"solo\":false,\"transitions\":[],\"videoEffects\":[],\"volume\":1}],\"width\":1920},{\"audioSampleRate\":48000,\"captionTracks\":[],\"frameRate\":{\"den\":1,\"num\":30},\"height\":1080,\"id\":\"dormant\",\"markers\":[],\"masterAudio\":{\"audioEffects\":[],\"balance\":0,\"muted\":false,\"volume\":1},\"masterVideoEffects\":[],\"name\":\"dormant\",\"schemaVersion\":24,\"tracks\":[{\"adjustments\":[],\"audioEffects\":[],\"balance\":0,\"clips\":[{\"animation\":{\"effectTracks\":[],\"tracks\":[]},\"assetId\":\"__myrelith_text__:dormant-text\",\"audio\":{\"balance\":0,\"enabled\":true,\"fadeInFrames\":0,\"fadeOutFrames\":0},\"audioEffects\":[],\"blendMode\":\"normal\",\"effects\":[],\"id\":\"dormant-text\",\"lensCorrection\":null,\"name\":\"Title 世界\",\"opacity\":1,\"sourceMode\":\"timed\",\"sourceRange\":{\"durationFrames\":100,\"startFrame\":0},\"sourceTimeMap\":{\"rate\":{\"denominator\":1,\"numerator\":1},\"sourceDurationTicks\":100000000,\"sourceStartTicks\":0,\"speedCurve\":{\"originFrame\":0,\"points\":[]}},\"text\":{\"align\":\"center\",\"backgroundColor\":\"#000000\",\"backgroundEnabled\":false,\"bold\":true,\"boxHeightPx\":238,\"boxWidthPx\":1248,\"color\":\"#ffffff\",\"content\":\"Title 世界\\nSecond line\",\"fontFamily\":\"sans-serif\",\"fontSizePx\":72,\"italic\":false,\"outlineColor\":\"#000000\",\"outlineEnabled\":true,\"outlineWidthPx\":2,\"paddingPx\":18,\"shadowBlurPx\":4,\"shadowColor\":\"#000000\",\"shadowEnabled\":true,\"shadowOffsetXPx\":2,\"shadowOffsetYPx\":2},\"timelineRange\":{\"durationFrames\":100,\"startFrame\":0},\"transform\":{\"anchorX\":0.5,\"anchorY\":0.5,\"rotation\":0,\"scaleX\":1,\"scaleY\":1,\"x\":0,\"y\":0},\"visual\":{\"crop\":{\"bottom\":0,\"left\":0,\"right\":0,\"top\":0},\"flipHorizontal\":false,\"flipVertical\":false,\"scaleLocked\":true},\"volume\":1}],\"hidden\":false,\"id\":\"dormant-V1\",\"kind\":\"video\",\"locked\":false,\"multicamInstances\":[],\"muted\":false,\"name\":\"V1\",\"sequenceInstances\":[],\"solo\":false,\"transitions\":[],\"videoEffects\":[],\"volume\":1},{\"adjustments\":[],\"audioEffects\":[],\"balance\":0,\"clips\":[],\"hidden\":false,\"id\":\"dormant-V2\",\"kind\":\"video\",\"locked\":false,\"multicamInstances\":[],\"muted\":false,\"name\":\"V2\",\"sequenceInstances\":[],\"solo\":false,\"transitions\":[],\"videoEffects\":[],\"volume\":1},{\"adjustments\":[],\"audioEffects\":[],\"balance\":0,\"clips\":[],\"hidden\":false,\"id\":\"dormant-V3\",\"kind\":\"video\",\"locked\":false,\"multicamInstances\":[],\"muted\":false,\"name\":\"V3\",\"sequenceInstances\":[],\"solo\":false,\"transitions\":[],\"videoEffects\":[],\"volume\":1},{\"adjustments\":[],\"audioEffects\":[],\"balance\":0,\"clips\":[],\"hidden\":false,\"id\":\"dormant-V4\",\"kind\":\"video\",\"locked\":false,\"multicamInstances\":[],\"muted\":false,\"name\":\"V4\",\"sequenceInstances\":[],\"solo\":false,\"transitions\":[],\"videoEffects\":[],\"volume\":1},{\"adjustments\":[],\"audioEffects\":[],\"balance\":0,\"clips\":[],\"hidden\":false,\"id\":\"dormant-A1\",\"kind\":\"audio\",\"locked\":false,\"multicamInstances\":[],\"muted\":false,\"name\":\"A1\",\"sequenceInstances\":[],\"solo\":false,\"transitions\":[],\"videoEffects\":[],\"volume\":1},{\"adjustments\":[],\"audioEffects\":[],\"balance\":0,\"clips\":[],\"hidden\":false,\"id\":\"dormant-A2\",\"kind\":\"audio\",\"locked\":false,\"multicamInstances\":[],\"muted\":false,\"name\":\"A2\",\"sequenceInstances\":[],\"solo\":false,\"transitions\":[],\"videoEffects\":[],\"volume\":1},{\"adjustments\":[],\"audioEffects\":[],\"balance\":0,\"clips\":[],\"hidden\":false,\"id\":\"dormant-A3\",\"kind\":\"audio\",\"locked\":false,\"multicamInstances\":[],\"muted\":false,\"name\":\"A3\",\"sequenceInstances\":[],\"solo\":false,\"transitions\":[],\"videoEffects\":[],\"volume\":1},{\"adjustments\":[],\"audioEffects\":[],\"balance\":0,\"clips\":[],\"hidden\":false,\"id\":\"dormant-A4\",\"kind\":\"audio\",\"locked\":false,\"multicamInstances\":[],\"muted\":false,\"name\":\"A4\",\"sequenceInstances\":[],\"solo\":false,\"transitions\":[],\"videoEffects\":[],\"volume\":1}],\"width\":1920}]}"
```

# Test source

```ts
  1   | /** Four independent native-keyboard cases. No corrective focus/scroll/store writes. */
  2   | import { test, expect, type Page, type TestInfo, type Locator } from '@playwright/test'
  3   | import { writeFile } from 'node:fs/promises'
  4   | import type * as Client from './keyboard-client'
  5   | import { inside, requireNativeKeys, requireSessionLedger, requireTabBudget } from './keyboard-model'
  6   | 
  7   | type State = ReturnType<typeof Client.snapshot>
  8   | type Run = { warnings: unknown[]; errors: unknown[]; pageErrors: string[]; cleanupErrors: string[]; events: unknown[]; tabs: number; images: string[]; probe: boolean }
  9   | const runs = new Map<string, Run>()
  10  | function run() { const value = runs.get(test.info().testId); if (!value) throw new Error('Run missing'); return value }
  11  | async function call<K extends keyof typeof Client>(page: Page, method: K, ...args: Parameters<typeof Client[K]>): Promise<Awaited<ReturnType<typeof Client[K]>>> {
  12  |   return page.evaluate(async ({ method, args }) => {
  13  |     const path = '/tests/diagnostics/issue200/keyboard-client.ts'
  14  |     return (await import(path))[method](...args)
  15  |   }, { method, args })
  16  | }
  17  | async function json(info: TestInfo, name: string, value: unknown) {
  18  |   const path = info.outputPath(name)
  19  |   await writeFile(path, JSON.stringify(value, null, 2) + '\n')
  20  |   if (!info.attachments.some((item) => item.path === path)) await info.attach(name, { path, contentType: 'application/json' })
  21  | }
  22  | async function state(page: Page, label: string) {
  23  |   const value = await call(page, 'snapshot')
  24  |   run().events.push({ kind: 'state', label, value })
  25  |   await call(page, 'checkSession')
  26  |   return value
  27  | }
  28  | function unchanged(before: State, after: State) {
  29  |   expect({ wire: after.wire, history: after.history, frame: after.frame, generation: after.generation, sequenceId: after.sequenceId })
  30  |     .toEqual({ wire: before.wire, history: before.history, frame: before.frame, generation: before.generation, sequenceId: before.sequenceId })
  31  | }
  32  | function oneEdit(before: State, after: State) {
> 33  |   expect(after.wire).not.toBe(before.wire)
      |                          ^ Error: expect(received).not.toBe(expected) // Object.is equality
  34  |   expect(after.past).toBe(before.past + 1); expect(after.future).toBe(0)
  35  |   const a = JSON.parse(after.history), b = JSON.parse(before.history)
  36  |   expect(a.past.slice(0, -1)).toEqual(b.past)
  37  |   expect(after.frame).toBe(before.frame); expect(after.generation).toBe(before.generation)
  38  | }
  39  | function elements(value: State) {
  40  |   const title = value.clip.title
  41  |   if (!title || title.version !== 1 || !Array.isArray(title.elements)) throw new Error('Expected bounded title')
  42  |   return title.elements
  43  | }
  44  | function textElement(value: State) {
  45  |   const e = elements(value).find((element) => element.id === 'root-element')
  46  |   if (!e || e.version !== 1 || e.kind !== 'text') throw new Error('Original text element missing')
  47  |   return e
  48  | }
  49  | function onlyElementsChange(before: State, after: State, expected: ReturnType<typeof elements>) {
  50  |   const project = structuredClone(before.project)
  51  |   project.sequences[0].tracks[0].clips[0].title = { version: 1, elements: expected }
  52  |   expect(after.project).toEqual(project)
  53  | }
  54  | async function recordFocus(page: Page, label: string) {
  55  |   const focus = await call(page, 'active')
  56  |   run().events.push({ kind: 'focus', label, focus })
  57  |   return focus
  58  | }
  59  | async function tab(page: Page, targetSteps: number, backwards = false) {
  60  |   requireTabBudget(targetSteps, ++run().tabs)
  61  |   await page.keyboard.press(backwards ? 'Shift+Tab' : 'Tab')
  62  |   return recordFocus(page, backwards ? 'Shift+Tab' : 'Tab')
  63  | }
  64  | async function seek(page: Page, target: Locator, name: string, backwards = false) {
  65  |   await expect(target).toHaveCount(1)
  66  |   for (let steps = 0; steps <= 128; steps++) {
  67  |     if (await target.evaluate((node) => node === document.activeElement)) return recordFocus(page, name)
  68  |     if (steps === 128) throw new Error(`Could not keyboard-reach ${name}`)
  69  |     await tab(page, steps + 1, backwards)
  70  |   }
  71  |   throw new Error(`Unreachable traversal: ${name}`)
  72  | }
  73  | async function screenshot(page: Page, label: string) {
  74  |   const info = test.info(), path = info.outputPath(`${run().images.length.toString().padStart(2, '0')}-${label}.png`)
  75  |   await page.screenshot({ path }); run().images.push(path)
  76  |   await info.attach(label, { path, contentType: 'image/png' })
  77  |   await json(info, 'keyboard-evidence.json', run())
  78  | }
  79  | async function focused(page: Page, target: Locator, label: string, backwards = false) {
  80  |   await seek(page, target, label, backwards)
  81  |   const evidence = await call(page, 'inspectFocused'), layout = await call(page, 'titleLayout')
  82  |   run().events.push({ kind: 'control', label, evidence, layout, accessibility: await target.ariaSnapshot() })
  83  |   await screenshot(page, label)
  84  |   expect(evidence.fullyVisible, `${label} clipped`).toBe(true)
  85  |   expect(evidence.focusVisible, `${label} lacks focus-visible`).toBe(true)
  86  |   expect(evidence.outline.width).toBeGreaterThan(0); expect(evidence.outline.style).not.toBe('none')
  87  |   expect(evidence.outline.measured.ratio, `${label} focus contrast`).toBeGreaterThanOrEqual(3)
  88  |   if (evidence.text.trim() || evidence.value) expect(evidence.paint.measured.ratio, `${label} text contrast`).toBeGreaterThanOrEqual(4.5)
  89  |   for (const item of evidence.labels) {
  90  |     expect(item.fullyVisible, `${label} label clipped`).toBe(true)
  91  |     expect(item.paint.measured.ratio, `${label} label contrast`).toBeGreaterThanOrEqual(4.5)
  92  |     for (const inline of item.inlineText) { expect(inline.fullyVisible).toBe(true); expect(inline.paint.measured.ratio).toBeGreaterThanOrEqual(4.5) }
  93  |   }
  94  |   for (const item of layout.containers) expect(item.scrollWidth, `${item.className} horizontal overflow`).toBeLessThanOrEqual(item.width + 1)
  95  |   return evidence
  96  | }
  97  | const button = (page: Page, name: string) => page.getByRole('button', { name, exact: true })
  98  | async function activate(page: Page, name: string, backwards = false) { await focused(page, button(page, name), name.replaceAll(/[^a-z0-9]+/gi, '-'), backwards); await page.keyboard.press('Enter') }
  99  | async function type(page: Page, value: string) { await page.keyboard.press('ControlOrMeta+A'); await page.keyboard.type(value) }
  100 | 
  101 | /** Canonical G3 portable leave/open/activate and selection, with fixed frame 12. */
  102 | async function openPortableTitle(page: Page, wire: string, frame: number) {
  103 |   const evidence = await page.evaluate(async ({ wire, frame }) => {
  104 |     const p = '/src/app/projectController.ts', d = '/src/state/documentStore.ts', f = '/src/domain/projectFile.ts'
  105 |     const t = '/src/state/transportStore.ts', s = '/src/state/titleEditorStore.ts', session = '/src/state/projectSessionStore.ts'
  106 |     const lifecycle = await import(p), files = await import(f), store = (await import(d)).useDocumentStore
  107 |     const left = await lifecycle.leaveActiveProject()
  108 |     if (left.status !== 'ready') throw new Error(JSON.stringify(left))
  109 |     const opened = await lifecycle.openProjectFile(new File([wire], 'title-keyboard.myrelith', { type: 'application/json' }))
  110 |     if (opened.status !== 'ready') throw new Error(JSON.stringify(opened))
  111 |     const activated = await lifecycle.activateResumedProject()
  112 |     if (activated.status !== 'activated') throw new Error(JSON.stringify(activated))
  113 |     const state = store.getState(), transport = (await import(t)).useTransportStore
  114 |     const clip = state.doc.tracks[0].clips[0]
  115 |     transport.getState().setSelectedClip(clip.id); transport.getState().setPlayheadFrame(frame)
  116 |     ;(await import(s)).useTitleEditorStore.getState().select(clip.id, clip.title?.elements.slice(0, 1).map((element: { id: string }) => element.id) ?? [])
  117 |     const active = (await import(session)).useProjectSessionStore.getState()
  118 |     return { left: left.status, opened: opened.status, activated: activated.status, past: state.past.length, future: state.future.length,
  119 |       wire: files.serializeProjectFile(files.createProjectFileSnapshot(state.project, [], [])),
  120 |       session: { screen: active.screen, phase: active.phase, error: active.error, saveError: active.saveError, recoveryError: active.recoveryError } }
  121 |   }, { wire, frame })
  122 |   run().events.push({ kind: 'canonical-entry', evidence })
  123 |   expect(evidence).toEqual({ left: 'ready', opened: 'ready', activated: 'activated', past: 0, future: 0, wire,
  124 |     session: { screen: 'editor', phase: 'idle', error: null, saveError: null, recoveryError: null } })
  125 | }
  126 | async function enter(page: Page) {
  127 |   await page.goto('/')
  128 |   await page.getByRole('button', { name: 'Start a new project' }).click()
  129 |   await page.getByLabel('Project name').fill('Title keyboard evidence')
  130 |   await page.getByLabel('Resolution').selectOption('720')
  131 |   await button(page, 'Create project').click()
  132 |   await expect(button(page, 'Commands')).toBeVisible()
  133 |   await call(page, 'observe'); run().probe = true
```