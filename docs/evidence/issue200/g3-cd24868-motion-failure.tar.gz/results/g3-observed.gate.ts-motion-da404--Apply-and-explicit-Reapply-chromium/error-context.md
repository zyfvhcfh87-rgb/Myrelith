# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: g3-observed.gate.ts >> motion preview, cancellation, Apply and explicit Reapply
- Location: tests/browser/issue-200-title-authoring.spec.ts:169:1

# Error details

```
Test timeout of 60000ms exceeded.
```

```
Error: locator.click: Test timeout of 60000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: 'Preview motion', exact: true })
    - locator resolved to <button disabled type="button">Preview motion</button>
  - attempting click action
    2 × waiting for element to be visible, enabled and stable
      - element is not enabled
    - retrying click action
    - waiting 20ms
    2 × waiting for element to be visible, enabled and stable
      - element is not enabled
    - retrying click action
      - waiting 100ms
    111 × waiting for element to be visible, enabled and stable
        - element is not enabled
      - retrying click action
        - waiting 500ms

```

# Page snapshot

```yaml
- generic [ref=e4]:
  - banner [ref=e5]:
    - generic [ref=e6]:
      - strong [ref=e7]: Myrelith
      - generic "title-g3.myrelith" [ref=e8]:
        - strong [ref=e9]: Title project
        - generic [ref=e10]: Opened · Save to enable live save
      - generic [ref=e11]: S splits at playhead · Del ripple-deletes
      - generic [ref=e12]:
        - button "Commands" [ref=e13] [cursor=pointer]:
          - generic [ref=e17]: Ctrl/⌘+K
        - button "Projects" [ref=e18] [cursor=pointer]
        - button "Save" [ref=e19] [cursor=pointer]
        - button "Save As" [ref=e20] [cursor=pointer]
        - button "Captions" [ref=e21] [cursor=pointer]
        - button "Plugins" [ref=e22] [cursor=pointer]
        - button "Export" [ref=e23] [cursor=pointer]
  - generic [ref=e24]:
    - group "Workspace layout" [ref=e25]:
      - generic [ref=e26]:
        - generic [ref=e27]: Workspace
        - combobox "Workspace preset" [ref=e28]:
          - option "Edit" [selected]
          - option "Inspect"
          - option "Media"
          - option "Custom" [disabled]
      - button "Media" [pressed] [ref=e30] [cursor=pointer]
      - button "Inspector" [pressed] [ref=e31] [cursor=pointer]
      - button "Timeline" [pressed] [ref=e32] [cursor=pointer]
      - button "Focus Inspector" [ref=e33] [cursor=pointer]
    - generic "Project sequences" [ref=e34]:
      - generic [ref=e35]:
        - generic [ref=e36]: Sequence
        - combobox "Active sequence" [ref=e37]:
          - option "root · Root" [selected]
          - option "dormant"
      - generic "Portable default render truth" [ref=e38]: "Root: root"
      - group "Sequence actions" [ref=e39]:
        - button "New" [ref=e40] [cursor=pointer]
        - button "Create compound" [ref=e41] [cursor=pointer]
        - button "Back to parent" [disabled] [ref=e42]
        - button "Duplicate" [ref=e43] [cursor=pointer]
        - button "Rename" [ref=e44] [cursor=pointer]
        - button "Make root" [disabled] [ref=e45]
        - button "Delete" [disabled] [ref=e46]
      - status [ref=e47]
    - status [ref=e48]
  - complementary [ref=e49]:
    - generic [ref=e50]:
      - generic [ref=e51]:
        - generic [ref=e52]:
          - heading "Media" [level=2] [ref=e53]
          - button "Import" [ref=e55] [cursor=pointer]
        - paragraph [ref=e59]: Import stores a browser-only file permission and its label. Myrelith never copies or uploads the file.
        - search "Filter media" [ref=e60]:
          - generic [ref=e61]:
            - generic [ref=e62]: Search
            - searchbox "Search" [ref=e63]
          - generic [ref=e64]:
            - generic [ref=e65]: Type
            - combobox "Type" [ref=e66]:
              - option "All types" [selected]
              - option "Video"
              - option "Audio"
              - option "Still images"
          - generic [ref=e67]:
            - generic [ref=e68]: Status
            - combobox "Status" [ref=e69]:
              - option "All statuses" [selected]
              - option "Ready media"
              - option "Offline media"
              - option "Checking media"
              - option "Limited media"
              - option "Unsupported media"
              - option "Media errors"
          - generic [ref=e70]: 0 of 0
        - group "View and sort" [ref=e72]:
          - radiogroup "Media Pool view" [ref=e73]:
            - radio "Thumbnail grid" [ref=e74] [cursor=pointer]
            - radio "Details" [checked] [ref=e77] [cursor=pointer]
            - radio "Compact list" [ref=e80] [cursor=pointer]
          - generic [ref=e83]:
            - generic [ref=e84]: Thumbnail size
            - combobox "Thumbnail size" [ref=e85]:
              - option "Small"
              - option "Medium" [selected]
              - option "Large"
          - generic [ref=e86]:
            - generic [ref=e87]: Sort
            - combobox "Sort media" [ref=e88]:
              - option "Project order" [selected]
              - option "Name"
              - option "Kind"
              - option "Duration"
              - option "Last modified"
              - option "Size"
          - button "Sort ascending" [ref=e89] [cursor=pointer]
        - generic [ref=e92]:
          - group "Local proxy storage" [ref=e93]:
            - generic "▸ Proxies 0 · 0 B" [ref=e94] [cursor=pointer]:
              - text: ▸
              - strong [ref=e95]: Proxies
              - generic [ref=e96]: 0 · 0 B
          - generic "Default still-image duration. Future imports only." [ref=e97]:
            - generic [ref=e98]: Stills
            - generic [ref=e99]:
              - spinbutton "Default still-image duration" [ref=e100]: "5"
              - generic [ref=e101]: s
            - generic [ref=e102]: Future imports only
      - region "Collections" [ref=e103]:
        - generic [ref=e104]:
          - generic [ref=e105]: Collections
          - generic "Collection history" [ref=e106]:
            - button "Undo collection change" [disabled] [ref=e107]
            - button "Redo collection change" [disabled] [ref=e110]
            - button "New collection" [ref=e113] [cursor=pointer]
        - tablist "Media collections" [ref=e116]:
          - tab "All media" [selected] [ref=e117] [cursor=pointer]:
            - generic [ref=e121]: "0"
      - grid "Media assets" [ref=e123]
      - paragraph [ref=e124]: no media yet — import video, audio, or a still image
      - generic [ref=e125]: Use arrow keys, Home, End, Page Up, and Page Down to move the Media Pool selection. Tab moves into that row's relink, collection, proxy, and remove actions.
      - generic [ref=e126]: No media selected
  - separator "Resize Media panel" [ref=e127]
  - main [ref=e128]:
    - generic [ref=e130]:
      - button "Scopes" [ref=e131] [cursor=pointer]
      - generic [ref=e132]:
        - generic [ref=e133]: Quality
        - combobox "Preview quality" [ref=e134]:
          - option "Auto" [selected]
          - option "Full"
          - option "Half"
          - option "Quarter"
      - generic "Visual clip canvas controls": Arrow keys adjust the focused control. Hold Shift for larger steps. Drag to preview; releasing commits one edit.
      - generic "Text overlay canvas controls": Use arrow keys to move one pixel. Hold Shift to move ten pixels. Use the resize handle arrow keys to change the text box.
      - generic "Title canvas controls":
        - generic:
          - button "Move title element Text" [pressed] [ref=e136]
          - button "Resize title element Text" [ref=e137]
      - status [ref=e138]:
        - strong [ref=e139]: Title font notice
        - text: "Title 世界 / Text: sans-serif uses this platform's fonts; appearance can differ on another device."
  - separator "Resize Inspector panel" [ref=e140]
  - complementary [ref=e141]:
    - region "Manual-sync multicam" [ref=e142]:
      - generic [ref=e143]:
        - generic [ref=e144]: Multicam
        - button "New multicam" [disabled] [ref=e145]
      - status "Multicam edit status" [ref=e146]
    - group [ref=e147]:
      - generic "Track and master video effects" [ref=e148]
      - option "Sequence master video" [selected]
      - option "V1"
      - option "V2"
      - option "V3"
      - option "V4"
    - generic [ref=e149]:
      - generic [ref=e150]: Inspector
      - generic [ref=e155]:
        - strong [ref=e156]: Title 世界
        - generic [ref=e157]: Video clip
      - tablist "Video inspector sections" [ref=e158]:
        - tab "Transform" [selected] [ref=e159] [cursor=pointer]
        - tab "Crop" [ref=e160] [cursor=pointer]
        - tab "Effects" [ref=e161] [cursor=pointer]
        - tab "Animation" [ref=e162] [cursor=pointer]
      - group "Audio/video linking" [ref=e163]:
        - button "Link selected audio and video clips" [disabled] [ref=e164]
        - generic [ref=e165]: Select one more clip with Ctrl/Cmd-click, or focus it and press Ctrl/Cmd+Enter.
        - status
      - region "Timing" [ref=e166]:
        - generic [ref=e167]:
          - heading "Timing" [level=3] [ref=e168]
          - button "Reset clip speed" [disabled] [ref=e169]: Reset
        - generic [ref=e170]:
          - generic [ref=e171]: Speed at playhead
          - combobox "Speed at playhead" [ref=e172]:
            - option "0% (Freeze)" [disabled]
            - option "25%"
            - option "50%"
            - option "75%"
            - option "100%" [selected]
            - option "125%"
            - option "150%"
            - option "175%"
            - option "200%"
            - option "225%"
            - option "250%"
            - option "275%"
            - option "300%"
            - option "325%"
            - option "350%"
            - option "375%"
            - option "400%"
        - generic [ref=e173]: Clip frame 0. Add a later positive speed boundary before choosing 0% (Freeze).
        - generic [ref=e174]:
          - generic [ref=e175]: Whole clip speed
          - combobox "Whole clip speed" [ref=e176]:
            - option "25%"
            - option "50%"
            - option "75%"
            - option "100%" [selected]
            - option "125%"
            - option "150%"
            - option "175%"
            - option "200%"
            - option "225%"
            - option "250%"
            - option "275%"
            - option "300%"
            - option "325%"
            - option "350%"
            - option "375%"
            - option "400%"
        - generic [ref=e177]: Timeline 100 frames · source 100 frames.
        - generic [ref=e178]: Audio stays enabled at 100% speed.
        - generic [ref=e179]:
          - generic "Speed ramp operations" [ref=e180]:
            - button "Add boundary at playhead" [ref=e181] [cursor=pointer]
            - button "Clear ramp" [disabled] [ref=e182]
          - paragraph [ref=e183]: Choose a speed at the playhead or add a boundary to start a timed section. The current whole-clip speed becomes frame 0.
          - status [ref=e184]: "Playhead: clip frame 0. A 0% freeze must be bounded by a later positive point."
      - region "Clip attribute actions" [ref=e186]:
        - generic [ref=e187]:
          - button "Copy attributes" [ref=e188] [cursor=pointer]
          - button "Paste attributes…" [disabled] [ref=e189]
          - button "Reset attributes…" [ref=e190] [cursor=pointer]
      - region "Title authoring" [ref=e191]:
        - heading "Title elements" [level=3] [ref=e192]
        - paragraph [ref=e193]: Back to front. Select several elements for a shared edit.
        - list [ref=e194]:
          - listitem [ref=e195]:
            - generic [ref=e196]:
              - checkbox "Text text" [checked] [ref=e197]
              - text: Text
              - generic [ref=e198]: text
            - button "Move Text backward" [disabled] [ref=e199]: ↓
            - button "Move Text forward" [disabled] [ref=e200]: ↑
        - group "Edit title elements" [ref=e201]:
          - generic [ref=e203]:
            - button "Add text" [ref=e204]
            - button "Add rectangle" [ref=e205]
            - button "Add ellipse" [ref=e206]
          - generic [ref=e207]:
            - button "Duplicate elements" [ref=e208]
            - button "Delete elements" [disabled] [ref=e209]
          - paragraph [ref=e210]: Base values. Existing keys override these at animated frames.
          - generic [ref=e211]:
            - text: Element name
            - textbox "Element name" [ref=e212]: Text
          - generic [ref=e213]:
            - checkbox "Enabled" [checked] [ref=e214]
            - text: Enabled
          - generic [ref=e215]:
            - generic [ref=e217]:
              - generic [ref=e218]: Position X
              - spinbutton "Position X" [ref=e219]: "0"
            - generic [ref=e221]:
              - generic [ref=e222]: Position Y
              - spinbutton "Position Y" [ref=e223]: "0"
            - generic [ref=e225]:
              - generic [ref=e226]: Scale X
              - spinbutton "Scale X" [ref=e227]: "1"
            - generic [ref=e229]:
              - generic [ref=e230]: Scale Y
              - spinbutton "Scale Y" [ref=e231]: "1"
            - generic [ref=e233]:
              - generic [ref=e234]: Rotation
              - spinbutton "Rotation" [ref=e235]: "0"
            - generic [ref=e237]:
              - generic [ref=e238]: Opacity
              - spinbutton "Opacity" [ref=e239]: "1"
            - generic [ref=e241]:
              - generic [ref=e242]: Box width
              - spinbutton "Box width" [ref=e243]: "1248"
            - generic [ref=e245]:
              - generic [ref=e246]: Box height
              - spinbutton "Box height" [ref=e247]: "238"
            - generic [ref=e249]:
              - generic [ref=e250]: Font size
              - spinbutton "Font size" [ref=e251]: "72"
            - generic [ref=e253]:
              - generic [ref=e254]: Outline width
              - spinbutton "Outline width" [ref=e255]: "2"
            - generic [ref=e257]:
              - generic [ref=e258]: Shadow blur
              - spinbutton "Shadow blur" [ref=e259]: "4"
            - generic [ref=e261]:
              - generic [ref=e262]: Shadow offset X
              - spinbutton "Shadow offset X" [ref=e263]: "2"
            - generic [ref=e265]:
              - generic [ref=e266]: Shadow offset Y
              - spinbutton "Shadow offset Y" [ref=e267]: "2"
          - generic [ref=e268]:
            - checkbox "Lock scale ratio (X when enabling)" [checked] [ref=e269]
            - text: Lock scale ratio (X when enabling)
          - generic [ref=e270]:
            - generic [ref=e271]:
              - generic [ref=e272]: Anchor X
              - spinbutton "Anchor X" [ref=e273]: "0.5"
            - generic [ref=e274]:
              - generic [ref=e275]: Anchor Y
              - spinbutton "Anchor Y" [ref=e276]: "0.5"
            - generic [ref=e277]:
              - generic [ref=e278]: Crop left
              - spinbutton "Crop left" [ref=e279]: "0"
            - generic [ref=e280]:
              - generic [ref=e281]: Crop right
              - spinbutton "Crop right" [ref=e282]: "0"
            - generic [ref=e283]:
              - generic [ref=e284]: Crop top
              - spinbutton "Crop top" [ref=e285]: "0"
            - generic [ref=e286]:
              - generic [ref=e287]: Crop bottom
              - spinbutton "Crop bottom" [ref=e288]: "0"
          - generic [ref=e289]:
            - checkbox "Flip horizontal" [ref=e290]
            - text: Flip horizontal
          - generic [ref=e291]:
            - checkbox "Flip vertical" [ref=e292]
            - text: Flip vertical
          - generic [ref=e293]:
            - text: Text content
            - textbox "Text content" [ref=e294]: Title 世界 Second line
          - status [ref=e295]: sans-serif · platform-dependent.
          - generic [ref=e296]:
            - text: Font family
            - combobox "Font family" [ref=e297]:
              - option "sans-serif" [selected]
              - option "serif"
              - option "monospace"
              - option "cursive"
              - option "fantasy"
              - option "system-ui"
          - generic [ref=e298]:
            - text: Explicit font fallback
            - combobox "Explicit font fallback" [ref=e299]:
              - option "No fallback" [selected]
              - option "sans-serif"
              - option "serif"
              - option "monospace"
              - option "cursive"
              - option "fantasy"
              - option "system-ui"
          - generic [ref=e300]:
            - text: Text alignment
            - combobox "Text alignment" [ref=e301]:
              - option "left"
              - option "center" [selected]
              - option "right"
          - generic [ref=e302]:
            - text: Text color
            - textbox "Text color" [ref=e303]: "#ffffff"
          - generic [ref=e304]:
            - generic [ref=e305]: Text padding
            - spinbutton "Text padding" [ref=e306]: "18"
          - generic [ref=e307]:
            - checkbox "Bold" [checked] [ref=e308]
            - text: Bold
          - generic [ref=e309]:
            - checkbox "Italic" [ref=e310]
            - text: Italic
          - generic [ref=e311]:
            - checkbox "Background" [ref=e312]
            - text: Background
          - generic [ref=e313]:
            - checkbox "Outline" [checked] [ref=e314]
            - text: Outline
          - generic [ref=e315]:
            - checkbox "Shadow" [checked] [ref=e316]
            - text: Shadow
          - generic [ref=e317]:
            - text: Background color
            - textbox "Background color" [ref=e318]: "#000000"
          - generic [ref=e319]:
            - text: Outline color
            - textbox "Outline color" [ref=e320]: "#000000"
          - generic [ref=e321]:
            - text: Shadow color
            - textbox "Shadow color" [ref=e322]: "#000000"
          - generic [ref=e323]:
            - button "Roll / crawl…" [ref=e324]
            - button "Save title template…" [ref=e325]
        - generic [ref=e326]:
          - checkbox "Safe guides · title 90% / action 95%" [ref=e327]
          - text: Safe guides · title 90% / action 95%
        - dialog [ref=e328]:
          - heading "Roll / crawl" [level=2] [ref=e329]
          - paragraph [ref=e330]: Generate two linear position keys per selected element. The group starts and ends fully offscreen; its spacing is preserved. Keys remain editable and keep their frame numbers after trimming.
          - generic [ref=e331]:
            - text: Direction
            - combobox "Direction" [active] [ref=e332]:
              - option "Roll up" [selected]
              - option "Roll down"
              - option "Crawl left"
              - option "Crawl right"
          - generic [ref=e333]:
            - generic [ref=e334]:
              - text: Start frame
              - spinbutton "Start frame" [ref=e335]: "0"
            - generic [ref=e336]:
              - text: End frame
              - spinbutton "End frame" [ref=e337]: "99"
          - generic [ref=e338]:
            - text: Preview local frame
            - spinbutton "Preview local frame" [ref=e339]: "50"
          - paragraph [ref=e340]: Preview samples title elements at this local frame. Put the playhead inside the title first.
          - status [ref=e341]: This review has ended. Close and reopen it to edit again.
          - generic [ref=e342]:
            - button "Preview motion" [disabled] [ref=e343]
            - button "Apply motion" [disabled] [ref=e344]
            - button "Cancel" [ref=e345]
      - generic [ref=e346]:
        - generic [ref=e347]: Video · Title 世界
        - tabpanel "Transform" [ref=e348]:
          - paragraph [ref=e349]: Use Title elements to transform this title.
          - region "Compositing" [ref=e350]:
            - generic [ref=e351]:
              - heading "Compositing" [level=3] [ref=e352]
              - button "Reset video blend mode" [ref=e353] [cursor=pointer]: Reset
            - generic [ref=e354]:
              - generic [ref=e355]: Blend mode
              - combobox "Blend mode" [ref=e356]:
                - option "Normal" [selected]
                - option "Multiply"
                - option "Screen"
                - option "Overlay"
                - option "Darken"
                - option "Lighten"
                - option "Difference"
                - option "Exclusion"
            - generic [ref=e357]: Normal is applied after transform, crop, and opacity.
          - region "Opacity" [ref=e358]:
            - generic [ref=e359]:
              - heading "Opacity" [level=3] [ref=e360]
              - button "Reset video opacity" [ref=e361] [cursor=pointer]: Reset
            - generic [ref=e362]:
              - slider "Opacity slider" [ref=e363]: "1"
              - generic [ref=e364]:
                - generic [ref=e365]: Opacity
                - spinbutton "Opacity" [ref=e366]: "1"
      - region [ref=e367]:
        - generic [ref=e368]:
          - heading "Clip audio effects" [level=3] [ref=e369]
          - generic "Add clip audio effects" [ref=e370]:
            - button "Add EQ" [ref=e371] [cursor=pointer]
            - button "Add compressor" [ref=e372] [cursor=pointer]
            - button "Add limiter" [ref=e373] [cursor=pointer]
            - button "Add noise gate" [ref=e374] [cursor=pointer]
            - button "Voice preset" [ref=e375] [cursor=pointer]
            - button "Music preset" [ref=e376] [cursor=pointer]
            - button "Podcast preset" [ref=e377] [cursor=pointer]
        - generic [ref=e378]: Audio effects run in authored order at this mix stage. Live playback and export share the same processors; bypass, reorder, reset, and unknown descriptors are preserved.
        - generic [ref=e379]: No audio effects on this stack.
      - region [ref=e380]:
        - generic [ref=e381]:
          - heading "V1 audio effects" [level=3] [ref=e382]
          - generic "Add v1 audio effects" [ref=e383]:
            - button "Add EQ" [ref=e384] [cursor=pointer]
            - button "Add compressor" [ref=e385] [cursor=pointer]
            - button "Add limiter" [ref=e386] [cursor=pointer]
            - button "Add noise gate" [ref=e387] [cursor=pointer]
            - button "Voice preset" [ref=e388] [cursor=pointer]
            - button "Music preset" [ref=e389] [cursor=pointer]
            - button "Podcast preset" [ref=e390] [cursor=pointer]
        - generic [ref=e391]: Audio effects run in authored order at this mix stage. Live playback and export share the same processors; bypass, reorder, reset, and unknown descriptors are preserved.
        - generic [ref=e392]: No audio effects on this stack.
      - region [ref=e393]:
        - generic [ref=e394]:
          - heading "Master audio effects" [level=3] [ref=e395]
          - generic "Add master audio effects" [ref=e396]:
            - button "Add EQ" [ref=e397] [cursor=pointer]
            - button "Add compressor" [ref=e398] [cursor=pointer]
            - button "Add limiter" [ref=e399] [cursor=pointer]
            - button "Add noise gate" [ref=e400] [cursor=pointer]
            - button "Voice preset" [ref=e401] [cursor=pointer]
            - button "Music preset" [ref=e402] [cursor=pointer]
            - button "Podcast preset" [ref=e403] [cursor=pointer]
        - generic [ref=e404]: Audio effects run in authored order at this mix stage. Live playback and export share the same processors; bypass, reorder, reset, and unknown descriptors are preserved.
        - generic [ref=e405]: No audio effects on this stack.
      - region "Loudness" [ref=e406]:
        - generic [ref=e407]:
          - heading "Loudness" [level=3] [ref=e408]
          - button "Measure" [ref=e409]
        - generic [ref=e410]:
          - generic [ref=e411]: Measurement range
          - combobox "Loudness measurement range" [ref=e412]:
            - option "Full timeline" [selected]
            - option "Timeline In/Out" [disabled]
        - generic [ref=e413]: Measurement is derived from the mixed program. It never writes gain. Incomplete coverage cannot claim a complete reading.
        - generic [ref=e414]: "Selected range: 0–100 (end exclusive)."
        - button "Normalize master to -16 LUFS" [disabled] [ref=e415]
  - generic [ref=e416]:
    - group "timeline tools" [ref=e417]:
      - button "Select — move clips, drag edges to trim (A)" [pressed] [ref=e418] [cursor=pointer]
      - button "Razor — click a clip to cut it (B)" [ref=e421] [cursor=pointer]
      - button "Ripple trim — drag edges, later clips follow (T)" [ref=e424] [cursor=pointer]
      - button "Slip — drag to change WHICH material plays (Y)" [ref=e427] [cursor=pointer]
      - button "Slide — drag between neighbors, they absorb it (U)" [ref=e430] [cursor=pointer]
      - button "Add text" [ref=e433] [cursor=pointer]
      - button "Title templates" [ref=e436] [cursor=pointer]: T+
      - button "Add adjustment layer" [ref=e437] [cursor=pointer]
      - button "Snapping on — hold Alt to temporarily bypass snapping" [pressed] [ref=e440] [cursor=pointer]
    - generic [ref=e443]:
      - button "one frame back" [ref=e444] [cursor=pointer]
      - button "play" [ref=e447] [cursor=pointer]
      - button "one frame forward" [ref=e450] [cursor=pointer]
      - button "Insert edit" [disabled] [ref=e453] [cursor=pointer]: Insert
      - button "Overwrite edit" [disabled] [ref=e454] [cursor=pointer]: Overwrite
      - button "Lift" [disabled] [ref=e455] [cursor=pointer]
      - button "Extract" [disabled] [ref=e456] [cursor=pointer]
      - button "Replace edit" [disabled] [ref=e457] [cursor=pointer]: Replace
      - region "Playback audio levels" [ref=e458]:
        - generic [ref=e459]: Playback is paused
        - generic [ref=e460]:
          - generic [ref=e461]:
            - generic [ref=e462]: L
            - meter "Left playback level" [ref=e463]
          - generic [ref=e465]:
            - generic [ref=e466]: R
            - meter "Right playback level" [ref=e467]
          - generic [ref=e469]:
            - generic [ref=e470]: M
            - meter "Master playback level" [ref=e471]
        - button "Reset audio overload warning" [disabled] [ref=e473]: "0"
    - group "Timeline zoom controls" [ref=e474]:
      - button "Full Extent Zoom" [ref=e475] [cursor=pointer]
      - button "Detail Zoom" [ref=e478] [cursor=pointer]
      - button "Custom Zoom" [pressed] [ref=e481] [cursor=pointer]
      - button "Zoom Out" [ref=e484] [cursor=pointer]
      - slider "Custom timeline zoom" [ref=e487] [cursor=pointer]: "0.693"
      - button "Zoom In" [ref=e488] [cursor=pointer]
  - separator "Resize Timeline panel" [ref=e491]
  - generic [ref=e492]:
    - region "Audio mixer" [ref=e493]:
      - article [ref=e494]:
        - generic: A1
        - generic [ref=e495]:
          - slider "A1 volume" [ref=e496]: "1"
          - generic [ref=e497]:
            - generic [ref=e498]:
              - meter "A1 left level" [ref=e499]
              - generic [ref=e500]: L
            - generic [ref=e501]:
              - meter "A1 right level" [ref=e502]
              - generic [ref=e503]: R
        - slider "A1 balance" [ref=e504]: "0"
        - generic [ref=e505]:
          - button "solo track A1" [ref=e506] [cursor=pointer]: S
          - button "mute track A1" [ref=e507] [cursor=pointer]: M
      - article [ref=e508]:
        - generic: A2
        - generic [ref=e509]:
          - slider "A2 volume" [ref=e510]: "1"
          - generic [ref=e511]:
            - generic [ref=e512]:
              - meter "A2 left level" [ref=e513]
              - generic [ref=e514]: L
            - generic [ref=e515]:
              - meter "A2 right level" [ref=e516]
              - generic [ref=e517]: R
        - slider "A2 balance" [ref=e518]: "0"
        - generic [ref=e519]:
          - button "solo track A2" [ref=e520] [cursor=pointer]: S
          - button "mute track A2" [ref=e521] [cursor=pointer]: M
      - article [ref=e522]:
        - generic: A3
        - generic [ref=e523]:
          - slider "A3 volume" [ref=e524]: "1"
          - generic [ref=e525]:
            - generic [ref=e526]:
              - meter "A3 left level" [ref=e527]
              - generic [ref=e528]: L
            - generic [ref=e529]:
              - meter "A3 right level" [ref=e530]
              - generic [ref=e531]: R
        - slider "A3 balance" [ref=e532]: "0"
        - generic [ref=e533]:
          - button "solo track A3" [ref=e534] [cursor=pointer]: S
          - button "mute track A3" [ref=e535] [cursor=pointer]: M
      - article [ref=e536]:
        - generic: A4
        - generic [ref=e537]:
          - slider "A4 volume" [ref=e538]: "1"
          - generic [ref=e539]:
            - generic [ref=e540]:
              - meter "A4 left level" [ref=e541]
              - generic [ref=e542]: L
            - generic [ref=e543]:
              - meter "A4 right level" [ref=e544]
              - generic [ref=e545]: R
        - slider "A4 balance" [ref=e546]: "0"
        - generic [ref=e547]:
          - button "solo track A4" [ref=e548] [cursor=pointer]: S
          - button "mute track A4" [ref=e549] [cursor=pointer]: M
      - article [ref=e550]:
        - generic: Master
        - generic [ref=e551]:
          - slider "Master volume" [ref=e552]: "1"
          - generic [ref=e553]:
            - generic [ref=e554]:
              - meter "Master left level" [ref=e555]
              - generic [ref=e556]: L
            - generic [ref=e557]:
              - meter "Master right level" [ref=e558]
              - generic [ref=e559]: R
        - slider "Master balance" [ref=e560]: "0"
        - button "mute master" [ref=e562] [cursor=pointer]: M
    - generic [ref=e564]:
      - generic [ref=e565]:
        - generic "Rename from the Rename button, or double-click the header" [ref=e567]:
          - generic [ref=e568]: V4
          - generic [ref=e569]:
            - generic [ref=e570]: Video
            - generic [ref=e571]: 0 clips
          - generic [ref=e572]:
            - button "target track V4" [ref=e573] [cursor=pointer]: T
            - button "rename track V4" [ref=e574] [cursor=pointer]
            - button "hide track V4" [ref=e577] [cursor=pointer]
            - button "lock track V4" [ref=e580] [cursor=pointer]
            - button "delete track V4" [ref=e583] [cursor=pointer]
        - generic "Rename from the Rename button, or double-click the header" [ref=e586]:
          - generic [ref=e587]: V3
          - generic [ref=e588]:
            - generic [ref=e589]: Video
            - generic [ref=e590]: 0 clips
          - generic [ref=e591]:
            - button "target track V3" [ref=e592] [cursor=pointer]: T
            - button "rename track V3" [ref=e593] [cursor=pointer]
            - button "hide track V3" [ref=e596] [cursor=pointer]
            - button "lock track V3" [ref=e599] [cursor=pointer]
            - button "delete track V3" [ref=e602] [cursor=pointer]
        - generic "Rename from the Rename button, or double-click the header" [ref=e605]:
          - generic [ref=e606]: V2
          - generic [ref=e607]:
            - generic [ref=e608]: Video
            - generic [ref=e609]: 0 clips
          - generic [ref=e610]:
            - button "target track V2" [ref=e611] [cursor=pointer]: T
            - button "rename track V2" [ref=e612] [cursor=pointer]
            - button "hide track V2" [ref=e615] [cursor=pointer]
            - button "lock track V2" [ref=e618] [cursor=pointer]
            - button "delete track V2" [ref=e621] [cursor=pointer]
        - generic "Rename from the Rename button, or double-click the header" [ref=e624]:
          - generic [ref=e625]: V1
          - generic [ref=e626]:
            - generic [ref=e627]: Video
            - generic [ref=e628]: 1 clip
          - generic [ref=e629]:
            - button "target track V1" [pressed] [ref=e630] [cursor=pointer]: T
            - button "rename track V1" [ref=e631] [cursor=pointer]
            - button "hide track V1" [ref=e634] [cursor=pointer]
            - button "lock track V1" [ref=e637] [cursor=pointer]
            - button "delete track V1" [ref=e640] [cursor=pointer]
        - generic "Rename from the Rename button, or double-click the header" [ref=e643]:
          - generic [ref=e644]: A1
          - generic [ref=e645]:
            - generic [ref=e646]: Audio
            - generic [ref=e647]: 0 clips
          - generic [ref=e648]:
            - button "target track A1" [pressed] [ref=e649] [cursor=pointer]: T
            - button "rename track A1" [ref=e650] [cursor=pointer]
            - button "solo track A1" [ref=e653] [cursor=pointer]: S
            - button "mute track A1" [ref=e654] [cursor=pointer]: M
            - button "lock track A1" [ref=e655] [cursor=pointer]
            - button "delete track A1" [ref=e658] [cursor=pointer]
        - generic "Rename from the Rename button, or double-click the header" [ref=e661]:
          - generic [ref=e662]: A2
          - generic [ref=e663]:
            - generic [ref=e664]: Audio
            - generic [ref=e665]: 0 clips
          - generic [ref=e666]:
            - button "target track A2" [ref=e667] [cursor=pointer]: T
            - button "rename track A2" [ref=e668] [cursor=pointer]
            - button "solo track A2" [ref=e671] [cursor=pointer]: S
            - button "mute track A2" [ref=e672] [cursor=pointer]: M
            - button "lock track A2" [ref=e673] [cursor=pointer]
            - button "delete track A2" [ref=e676] [cursor=pointer]
        - generic "Rename from the Rename button, or double-click the header" [ref=e679]:
          - generic [ref=e680]: A3
          - generic [ref=e681]:
            - generic [ref=e682]: Audio
            - generic [ref=e683]: 0 clips
          - generic [ref=e684]:
            - button "target track A3" [ref=e685] [cursor=pointer]: T
            - button "rename track A3" [ref=e686] [cursor=pointer]
            - button "solo track A3" [ref=e689] [cursor=pointer]: S
            - button "mute track A3" [ref=e690] [cursor=pointer]: M
            - button "lock track A3" [ref=e691] [cursor=pointer]
            - button "delete track A3" [ref=e694] [cursor=pointer]
        - generic "Rename from the Rename button, or double-click the header" [ref=e697]:
          - generic [ref=e698]: A4
          - generic [ref=e699]:
            - generic [ref=e700]: Audio
            - generic [ref=e701]: 0 clips
          - generic [ref=e702]:
            - button "target track A4" [ref=e703] [cursor=pointer]: T
            - button "rename track A4" [ref=e704] [cursor=pointer]
            - button "solo track A4" [ref=e707] [cursor=pointer]: S
            - button "mute track A4" [ref=e708] [cursor=pointer]: M
            - button "lock track A4" [ref=e709] [cursor=pointer]
            - button "delete track A4" [ref=e712] [cursor=pointer]
        - generic [ref=e715]:
          - button "add video track" [ref=e716] [cursor=pointer]: + Video
          - button "add audio track" [ref=e717] [cursor=pointer]: + Audio
      - generic [ref=e718]:
        - generic [ref=e719]:
          - slider "Timeline playhead"
          - generic [ref=e720]: Arrow keys move one frame, Shift+arrow moves ten, Page Up and Page Down move one second, Home and End jump to the bounds, Escape restores the playhead from when this ruler received focus, and Alt bypasses snapping.
          - generic: 00:00:00:00
          - generic: 00:00:05:00
          - generic: 00:00:10:00
          - generic: 00:00:15:00
          - generic: 00:00:20:00
          - generic: 00:00:25:00
          - generic: 00:00:30:00
          - generic: 00:00:35:00
          - generic: 00:00:40:00
          - generic: 00:00:45:00
          - generic: 00:00:50:00
          - generic: 00:00:55:00
          - generic: 00:01:00:00
          - generic: 00:01:05:00
          - generic: 00:01:10:00
          - generic "Timeline markers"
        - button "Title 世界, video clip" [pressed] [ref=e726]: Title 世界
  - status [ref=e734]
```

# Test source

```ts
  73  |   expect((await snapshot(page)).clip.title.elements[0].kind).toBe('text')
  74  |   await page.getByRole('button', { name: 'Commands', exact: true }).click()
  75  |   await page.getByRole('searchbox', { name: 'Search commands' }).fill('Redo')
  76  |   await page.getByRole('button', { name: 'Redo', exact: true }).click()
  77  |   expect((await snapshot(page)).wire).toBe(after.wire)
  78  | })
  79  | test('direct manipulation, Escape cancellation and editor-only safe guides', async ({ page }, info) => {
  80  |   await enter(page)
  81  |   const handle = page.getByRole('button', { name: 'Move title element Text', exact: true })
  82  |   await expect(handle).toBeVisible()
  83  |   const before = await snapshot(page), bounds = await handle.boundingBox()
  84  |   expect(bounds).not.toBeNull()
  85  |   await page.mouse.move(bounds!.x + bounds!.width / 2, bounds!.y + bounds!.height / 2)
  86  |   await page.mouse.down(); await page.mouse.move(bounds!.x + bounds!.width / 2 + 20, bounds!.y + bounds!.height / 2 + 10, { steps: 4 }); await page.mouse.up()
  87  |   const moved = await snapshot(page)
  88  |   expect(moved.past).toBe(before.past + 1); expect(moved.clip.title.elements[0].transform.x).toBeGreaterThan(0)
  89  |   const next = await handle.boundingBox()
  90  |   await page.mouse.move(next!.x + next!.width / 2, next!.y + next!.height / 2); await page.mouse.down(); await page.mouse.move(next!.x + next!.width / 2 + 20, next!.y + next!.height / 2)
  91  |   await page.keyboard.press('Escape'); await page.mouse.up()
  92  |   expect((await snapshot(page)).wire).toBe(moved.wire)
  93  |   await page.getByRole('checkbox', { name: /Safe guides/ }).check()
  94  |   expect((await snapshot(page)).wire).toBe(moved.wire)
  95  |   await expect(page.getByTestId('title-safe-0.9')).toBeVisible(); await expect(page.getByTestId('title-safe-0.95')).toBeVisible()
  96  |   await page.screenshot({ path: info.outputPath('guides-and-handles.png') })
  97  |   const animatedWire = await page.evaluate(async () => {
  98  |     const d = '/src/state/documentStore.ts', f = '/src/domain/projectFile.ts'
  99  |     const files = await import(f)
  100 |     const store = (await import(d)).useDocumentStore, project = structuredClone(store.getState().project)
  101 |     const clip = project.sequences[0].tracks[0].clips[0], element = clip.title.elements[0]
  102 |     const values = { 'position-x': element.transform.x, 'position-y': element.transform.y, 'box-width': element.text.boxWidthPx, 'box-height': element.text.boxHeightPx }
  103 |     clip.animation = { ...clip.animation, titleTracks: Object.entries(values).map(([property, value]) => ({ elementId: element.id, propertyVersion: 1, property,
  104 |       keyframes: [{ frame: 0, value, easing: { type: 'linear' } }, { frame: 99, value: Number(value) + 100, easing: { type: 'linear' } }] })) }
  105 |     return files.serializeProjectFile(files.createProjectFileSnapshot(project, [], []))
  106 |   })
  107 |   await openPortableTitle(page, animatedWire, 50)
  108 |   const observations: unknown[] = []
  109 |   for (const mode of ['Move', 'Resize']) {
  110 |     const control = page.getByRole('button', { name: `${mode} title element Text`, exact: true })
  111 |     await expect(control).toBeVisible()
  112 |     await control.evaluate((element) => {
  113 |       const data: { down: { pointerId: number; trusted: boolean } | null; loss: { pointerId: number; trusted: boolean } | null; moves: { pointerId: number; trusted: boolean; buttons: number }[]; clickTrusted: boolean | null } = { down: null, loss: null, moves: [], clickTrusted: null }
  114 |       const down = (event: Event) => { const e = event as PointerEvent; data.down = { pointerId: e.pointerId, trusted: e.isTrusted } }
  115 |       const lost = (event: Event) => { const e = event as PointerEvent; data.loss = { pointerId: e.pointerId, trusted: e.isTrusted } }
  116 |       const move = (event: PointerEvent) => { if (data.moves.length < 32) data.moves.push({ pointerId: event.pointerId, trusted: event.isTrusted, buttons: event.buttons }) }
  117 |       const click = (event: Event) => { data.clickTrusted = event.isTrusted }
  118 |       element.addEventListener('pointerdown', down); element.addEventListener('lostpointercapture', lost); element.addEventListener('click', click)
  119 |       window.addEventListener('pointermove', move)
  120 |       Object.assign(element, { g3CaptureProbe: { data, dispose: () => { element.removeEventListener('pointerdown', down); element.removeEventListener('lostpointercapture', lost); element.removeEventListener('click', click); window.removeEventListener('pointermove', move) } } })
  121 |     })
  122 |     const probe = () => control.evaluate((element) => (element as HTMLElement & { g3CaptureProbe: { data: { down: { pointerId: number; trusted: boolean } | null; loss: { pointerId: number; trusted: boolean } | null; moves: { pointerId: number; trusted: boolean; buttons: number }[]; clickTrusted: boolean | null } } }).g3CaptureProbe.data)
  123 |     const observation: Record<string, unknown> = { mode }
  124 |     observations.push(observation)
  125 |     try {
  126 |       const clickBefore = await snapshot(page)
  127 |       await control.click()
  128 |       expect((await probe()).clickTrusted).toBe(true)
  129 |       const clicked = await snapshot(page)
  130 |       expect({ wire: clicked.wire, past: clicked.past, future: clicked.future, history: clicked.history }).toEqual({ wire: clickBefore.wire, past: clickBefore.past, future: clickBefore.future, history: clickBefore.history })
  131 |       expect(clicked.previewOwner).toBeNull()
  132 |       observation.clickPreservedProjectAndHistory = true
  133 |       observation.click = await probe()
  134 |       await control.evaluate((element) => { const probe = (element as HTMLElement & { g3CaptureProbe: { data: { down: unknown; loss: unknown; moves: unknown[] } } }).g3CaptureProbe; probe.data.down = null; probe.data.loss = null; probe.data.moves = [] })
  135 |       const beforeLoss = await snapshot(page), box = await control.boundingBox()
  136 |       expect(box).not.toBeNull()
  137 |       const x = box!.x + box!.width / 2, y = box!.y + box!.height / 2
  138 |       await page.mouse.move(x, y); await page.mouse.down(); await page.mouse.move(x + 8, y + 4, { steps: 2 })
  139 |       await expect.poll(async () => (await snapshot(page)).previewOwner).toBe('title-authoring')
  140 |       const releasedPointer = await control.evaluate((element) => {
  141 |         const probe = (element as HTMLElement & { g3CaptureProbe: { data: { down: { pointerId: number; trusted: boolean } | null; moves: unknown[] } } }).g3CaptureProbe
  142 |         const down = probe.data.down
  143 |         if (!down?.trusted || !element.hasPointerCapture(down.pointerId)) throw new Error('The actual pointer never acquired capture.')
  144 |         probe.data.moves = [] // Evidence below can only come from the next native held move.
  145 |         element.releasePointerCapture(down.pointerId)
  146 |         return down.pointerId
  147 |       })
  148 |       observation.releasedPointer = releasedPointer
  149 |       // A release request is not event proof: the next real move still holds the same mouse button.
  150 |       await page.mouse.move(x + 16, y + 8)
  151 |       await expect.poll(async () => (await probe()).loss?.trusted).toBe(true)
  152 |       const captured = await probe()
  153 |       observation.beforeMouseUp = captured
  154 |       expect(captured.loss?.pointerId).toBe(releasedPointer)
  155 |       expect(captured.moves.some((event) => event.trusted && event.pointerId === releasedPointer && (event.buttons & 1) === 1)).toBe(true)
  156 |       expect((await snapshot(page)).previewOwner).toBeNull()
  157 |       await page.mouse.up()
  158 |       const afterLoss = await snapshot(page)
  159 |       expect({ wire: afterLoss.wire, past: afterLoss.past, future: afterLoss.future, history: afterLoss.history }).toEqual({ wire: beforeLoss.wire, past: beforeLoss.past, future: beforeLoss.future, history: beforeLoss.history })
  160 |       observation.lossAndLateUpPreservedProjectAndHistory = true
  161 |     } finally {
  162 |       observation.finalProbe = await probe().catch((error: unknown) => ({ unavailable: String(error) }))
  163 |       await info.attach(`trusted-title-${mode.toLowerCase()}-capture-and-click`, { body: JSON.stringify(observation, null, 2), contentType: 'application/json' })
  164 |       await control.evaluate((element) => (element as HTMLElement & { g3CaptureProbe: { dispose(): void } }).g3CaptureProbe.dispose()).catch(() => {})
  165 |     }
  166 |   }
  167 |   await info.attach('trusted-title-capture-and-clicks', { body: JSON.stringify(observations, null, 2), contentType: 'application/json' })
  168 | })
  169 | test('motion preview, cancellation, Apply and explicit Reapply', async ({ page }, info) => {
  170 |   await enter(page)
  171 |   await page.getByRole('button', { name: 'Roll / crawl…' }).click()
  172 |   const before = await snapshot(page)
> 173 |   await page.getByRole('button', { name: 'Preview motion', exact: true }).click()
      |                                                                           ^ Error: locator.click: Test timeout of 60000ms exceeded.
  174 |   expect((await snapshot(page)).previewOwner).toBe('title-authoring')
  175 |   expect((await snapshot(page)).wire).toBe(before.wire)
  176 |   await page.getByRole('button', { name: 'Cancel', exact: true }).click()
  177 |   expect((await snapshot(page)).previewOwner).toBeNull()
  178 |   await page.getByRole('button', { name: 'Roll / crawl…' }).click()
  179 |   await page.getByRole('button', { name: 'Apply motion', exact: true }).click()
  180 |   const applied = await snapshot(page)
  181 |   expect(applied.past).toBe(before.past + 1)
  182 |   expect(applied.clip.animation.titleTracks[0].keyframes.map((key: { frame: number }) => key.frame)).toEqual([0, 99])
  183 |   await page.getByRole('button', { name: 'Roll / crawl…' }).click()
  184 |   await expect(page.getByRole('button', { name: 'Reapply motion', exact: true })).toBeDisabled()
  185 |   await page.getByRole('checkbox', { name: 'Replace all listed movement tracks' }).check()
  186 |   await page.getByRole('spinbutton', { name: 'End frame', exact: true }).fill('90')
  187 |   await page.screenshot({ path: info.outputPath('reapply-review.png') })
  188 |   await page.getByRole('button', { name: 'Reapply motion', exact: true }).click()
  189 |   expect((await snapshot(page)).clip.animation.titleTracks[0].keyframes.map((key: { frame: number }) => key.frame)).toEqual([0, 90])
  190 | })
  191 | test('unknown font gets an explicit persisted fallback through real controls', async ({ page }, info) => {
  192 |   await enter(page)
  193 |   const unavailableWire = await page.evaluate(async () => {
  194 |     const d = '/src/state/documentStore.ts', f = '/src/domain/projectFile.ts'
  195 |     const files = await import(f), store = (await import(d)).useDocumentStore, project = structuredClone(store.getState().project)
  196 |     project.sequences[0].tracks[0].clips[0].title.elements[0].font = { family: 'Missing G3 Face', fallbackFamily: null }
  197 |     return files.serializeProjectFile(files.createProjectFileSnapshot(project, [], []))
  198 |   })
  199 |   await openPortableTitle(page, unavailableWire)
  200 |   await expect(page.locator('.preview-title-status')).toContainText('Title unavailable')
  201 |   await page.getByRole('combobox', { name: 'Explicit font fallback', exact: true }).selectOption('serif')
  202 |   await expect(page.locator('.preview-title-status')).toContainText('explicit serif fallback')
  203 |   const saved = await snapshot(page)
  204 |   expect(saved.clip.title.elements[0].font).toEqual({ family: 'Missing G3 Face', fallbackFamily: 'serif' })
  205 |   await openPortableTitle(page, saved.wire)
  206 |   await expect(page.locator('.preview-title-status')).toContainText('explicit serif fallback')
  207 |   expect((await snapshot(page)).wire).toBe(saved.wire)
  208 |   await page.screenshot({ path: info.outputPath('font-fallback-reopened.png') })
  209 | })
  210 | test('local template save/use/delete retains independent project copies and real IndexedDB data', async ({ page }, info) => {
  211 |   await enter(page)
  212 |   await page.getByRole('button', { name: 'Save title template…' }).click()
  213 |   await page.getByRole('textbox', { name: 'Template name', exact: true }).fill('My G3 title')
  214 |   await page.getByRole('button', { name: 'Save template', exact: true }).click()
  215 |   await expect(page.getByRole('dialog', { name: 'Save title template' })).not.toBeVisible()
  216 |   expect((await snapshot(page)).past).toBe(0)
  217 |   await page.evaluate(async () => { const t = '/src/state/transportStore.ts'; (await import(t)).useTransportStore.getState().setPlayheadFrame(200) })
  218 |   await page.getByRole('button', { name: 'Title templates', exact: true }).click()
  219 |   await page.getByRole('button', { name: 'My G3 title', exact: true }).click()
  220 |   await expect(page.locator('.title-template-review')).toContainText('My G3 title')
  221 |   await page.screenshot({ path: info.outputPath('template-review.png') })
  222 |   await page.getByRole('button', { name: 'Apply template', exact: true }).click()
  223 |   const inserted = await snapshot(page)
  224 |   expect(inserted.past).toBe(1)
  225 |   const ids = await page.evaluate(async () => { const d = '/src/state/documentStore.ts'; return (await import(d)).useDocumentStore.getState().doc.tracks[0].clips.map((clip: { title: { elements: { id: string }[] } }) => clip.title.elements[0].id) })
  226 |   expect(new Set(ids).size).toBe(2)
  227 |   await page.getByRole('button', { name: 'Title templates', exact: true }).click()
  228 |   await page.getByRole('button', { name: 'Delete template My G3 title', exact: true }).click()
  229 |   await expect(page.getByRole('button', { name: 'My G3 title', exact: true })).not.toBeVisible()
  230 |   expect((await snapshot(page)).wire).toBe(inserted.wire)
  231 | })
  232 | test('narrow dialog controls stay reachable and project changes invalidate open reviews', async ({ page }, info) => {
  233 |   await enter(page)
  234 |   await page.getByRole('button', { name: 'Roll / crawl…' }).click()
  235 |   // Qualify the modal after resizing; workspace-wide narrow layout remains separately qualified.
  236 |   await page.setViewportSize({ width: 720, height: 800 })
  237 |   const dialog = page.getByRole('dialog', { name: 'Roll / crawl', exact: true })
  238 |   const bounds = await dialog.boundingBox()
  239 |   expect(bounds!.x).toBeGreaterThanOrEqual(0); expect(bounds!.x + bounds!.width).toBeLessThanOrEqual(720)
  240 |   await expect(page.getByRole('button', { name: 'Apply motion', exact: true })).toBeVisible()
  241 |   await page.screenshot({ path: info.outputPath('motion-dialog-720.png') })
  242 |   await page.evaluate(async () => { const t = '/src/state/transportStore.ts'; (await import(t)).useTransportStore.getState().setPlayheadFrame(10) })
  243 |   await expect(page.getByRole('button', { name: 'Apply motion', exact: true })).toBeDisabled()
  244 |   expect((await snapshot(page)).past).toBe(0)
  245 | })
  246 | 
```