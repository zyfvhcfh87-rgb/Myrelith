# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: diagnostic.spec.ts >> diagnose frozen title pixels by canvas kind, realm, renderer and context policy
- Location: tests/diagnostics/issue200/diagnostic.spec.ts:11:1

# Error details

```
Error: Exact-zero diagnostic discrepancies; see saved raw samples

expect(received).toEqual(expected) // deep equality

- Expected  -    1
+ Received  + 1472

- Array []
+ Array [
+   Object {
+     "differingBytes": 6,
+     "id": "sans-serif-combining-emoji-half-proof-baseline-0-html-offscreen",
+     "maximumDelta": 113,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "sans-serif-combining-emoji-half-proof-compact-0-html-offscreen",
+     "maximumDelta": 113,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "sans-serif-combining-emoji-half-proof-expanded-0-html-offscreen",
+     "maximumDelta": 113,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "sans-serif-combining-emoji-half-proof-baseline-1-html-offscreen",
+     "maximumDelta": 113,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "sans-serif-combining-emoji-half-proof-compact-1-html-offscreen",
+     "maximumDelta": 113,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "sans-serif-combining-emoji-half-proof-expanded-1-html-offscreen",
+     "maximumDelta": 113,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "sans-serif-combining-emoji-half-production-baseline-0-html-offscreen",
+     "maximumDelta": 113,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "sans-serif-combining-emoji-half-production-compact-0-html-offscreen",
+     "maximumDelta": 113,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "sans-serif-combining-emoji-half-production-expanded-0-html-offscreen",
+     "maximumDelta": 113,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "sans-serif-combining-emoji-half-production-baseline-1-html-offscreen",
+     "maximumDelta": 113,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "sans-serif-combining-emoji-half-production-compact-1-html-offscreen",
+     "maximumDelta": 113,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "sans-serif-combining-emoji-half-production-expanded-1-html-offscreen",
+     "maximumDelta": 113,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "sans-serif-combining-emoji-quarter-proof-baseline-0-html-offscreen",
+     "maximumDelta": 24,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "sans-serif-combining-emoji-quarter-proof-compact-0-html-offscreen",
+     "maximumDelta": 24,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "sans-serif-combining-emoji-quarter-proof-expanded-0-html-offscreen",
+     "maximumDelta": 24,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "sans-serif-combining-emoji-quarter-proof-baseline-1-html-offscreen",
+     "maximumDelta": 24,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "sans-serif-combining-emoji-quarter-proof-compact-1-html-offscreen",
+     "maximumDelta": 24,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "sans-serif-combining-emoji-quarter-proof-expanded-1-html-offscreen",
+     "maximumDelta": 24,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "sans-serif-combining-emoji-quarter-production-baseline-0-html-offscreen",
+     "maximumDelta": 24,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "sans-serif-combining-emoji-quarter-production-compact-0-html-offscreen",
+     "maximumDelta": 24,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "sans-serif-combining-emoji-quarter-production-expanded-0-html-offscreen",
+     "maximumDelta": 24,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "sans-serif-combining-emoji-quarter-production-baseline-1-html-offscreen",
+     "maximumDelta": 24,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "sans-serif-combining-emoji-quarter-production-compact-1-html-offscreen",
+     "maximumDelta": 24,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "sans-serif-combining-emoji-quarter-production-expanded-1-html-offscreen",
+     "maximumDelta": 24,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 234,
+     "id": "sans-serif-crop-flip-full-proof-baseline-0-html-offscreen",
+     "maximumDelta": 129,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 234,
+     "id": "sans-serif-crop-flip-full-proof-compact-0-html-offscreen",
+     "maximumDelta": 129,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 234,
+     "id": "sans-serif-crop-flip-full-proof-expanded-0-html-offscreen",
+     "maximumDelta": 129,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 234,
+     "id": "sans-serif-crop-flip-full-proof-export-0-html",
+     "maximumDelta": 129,
+     "sameLines": true,
+     "scope": "finite-export",
+   },
+   Object {
+     "differingBytes": 234,
+     "id": "sans-serif-crop-flip-full-proof-baseline-1-html-offscreen",
+     "maximumDelta": 129,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 234,
+     "id": "sans-serif-crop-flip-full-proof-compact-1-html-offscreen",
+     "maximumDelta": 129,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 234,
+     "id": "sans-serif-crop-flip-full-proof-expanded-1-html-offscreen",
+     "maximumDelta": 129,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 234,
+     "id": "sans-serif-crop-flip-full-proof-export-1-html",
+     "maximumDelta": 129,
+     "sameLines": true,
+     "scope": "finite-export",
+   },
+   Object {
+     "differingBytes": 234,
+     "id": "sans-serif-crop-flip-full-production-baseline-0-html-offscreen",
+     "maximumDelta": 129,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 234,
+     "id": "sans-serif-crop-flip-full-production-compact-0-html-offscreen",
+     "maximumDelta": 129,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 234,
+     "id": "sans-serif-crop-flip-full-production-expanded-0-html-offscreen",
+     "maximumDelta": 129,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 234,
+     "id": "sans-serif-crop-flip-full-production-export-0-html",
+     "maximumDelta": 129,
+     "sameLines": true,
+     "scope": "finite-export",
+   },
+   Object {
+     "differingBytes": 234,
+     "id": "sans-serif-crop-flip-full-production-baseline-1-html-offscreen",
+     "maximumDelta": 129,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 234,
+     "id": "sans-serif-crop-flip-full-production-compact-1-html-offscreen",
+     "maximumDelta": 129,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 234,
+     "id": "sans-serif-crop-flip-full-production-expanded-1-html-offscreen",
+     "maximumDelta": 129,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 234,
+     "id": "sans-serif-crop-flip-full-production-export-1-html",
+     "maximumDelta": 129,
+     "sameLines": true,
+     "scope": "finite-export",
+   },
+   Object {
+     "differingBytes": 144,
+     "id": "sans-serif-crop-flip-half-proof-baseline-0-html-offscreen",
+     "maximumDelta": 120,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 144,
+     "id": "sans-serif-crop-flip-half-proof-compact-0-html-offscreen",
+     "maximumDelta": 120,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 144,
+     "id": "sans-serif-crop-flip-half-proof-expanded-0-html-offscreen",
+     "maximumDelta": 120,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 144,
+     "id": "sans-serif-crop-flip-half-proof-baseline-1-html-offscreen",
+     "maximumDelta": 120,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 144,
+     "id": "sans-serif-crop-flip-half-proof-compact-1-html-offscreen",
+     "maximumDelta": 120,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 144,
+     "id": "sans-serif-crop-flip-half-proof-expanded-1-html-offscreen",
+     "maximumDelta": 120,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 144,
+     "id": "sans-serif-crop-flip-half-production-baseline-0-html-offscreen",
+     "maximumDelta": 120,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 144,
+     "id": "sans-serif-crop-flip-half-production-compact-0-html-offscreen",
+     "maximumDelta": 120,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 144,
+     "id": "sans-serif-crop-flip-half-production-expanded-0-html-offscreen",
+     "maximumDelta": 120,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 144,
+     "id": "sans-serif-crop-flip-half-production-baseline-1-html-offscreen",
+     "maximumDelta": 120,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 144,
+     "id": "sans-serif-crop-flip-half-production-compact-1-html-offscreen",
+     "maximumDelta": 120,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 144,
+     "id": "sans-serif-crop-flip-half-production-expanded-1-html-offscreen",
+     "maximumDelta": 120,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 81,
+     "id": "sans-serif-crop-flip-quarter-proof-baseline-0-html-offscreen",
+     "maximumDelta": 95,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 81,
+     "id": "sans-serif-crop-flip-quarter-proof-compact-0-html-offscreen",
+     "maximumDelta": 95,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 81,
+     "id": "sans-serif-crop-flip-quarter-proof-expanded-0-html-offscreen",
+     "maximumDelta": 95,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 81,
+     "id": "sans-serif-crop-flip-quarter-proof-baseline-1-html-offscreen",
+     "maximumDelta": 95,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 81,
+     "id": "sans-serif-crop-flip-quarter-proof-compact-1-html-offscreen",
+     "maximumDelta": 95,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 81,
+     "id": "sans-serif-crop-flip-quarter-proof-expanded-1-html-offscreen",
+     "maximumDelta": 95,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 81,
+     "id": "sans-serif-crop-flip-quarter-production-baseline-0-html-offscreen",
+     "maximumDelta": 95,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 81,
+     "id": "sans-serif-crop-flip-quarter-production-compact-0-html-offscreen",
+     "maximumDelta": 95,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 81,
+     "id": "sans-serif-crop-flip-quarter-production-expanded-0-html-offscreen",
+     "maximumDelta": 95,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 81,
+     "id": "sans-serif-crop-flip-quarter-production-baseline-1-html-offscreen",
+     "maximumDelta": 95,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 81,
+     "id": "sans-serif-crop-flip-quarter-production-compact-1-html-offscreen",
+     "maximumDelta": 95,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 81,
+     "id": "sans-serif-crop-flip-quarter-production-expanded-1-html-offscreen",
+     "maximumDelta": 95,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 780,
+     "id": "sans-serif-background-half-proof-baseline-0-html-offscreen",
+     "maximumDelta": 21,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 780,
+     "id": "sans-serif-background-half-proof-compact-0-html-offscreen",
+     "maximumDelta": 21,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 780,
+     "id": "sans-serif-background-half-proof-expanded-0-html-offscreen",
+     "maximumDelta": 21,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 780,
+     "id": "sans-serif-background-half-proof-baseline-1-html-offscreen",
+     "maximumDelta": 21,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 780,
+     "id": "sans-serif-background-half-proof-compact-1-html-offscreen",
+     "maximumDelta": 21,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 780,
+     "id": "sans-serif-background-half-proof-expanded-1-html-offscreen",
+     "maximumDelta": 21,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 780,
+     "id": "sans-serif-background-half-production-baseline-0-html-offscreen",
+     "maximumDelta": 21,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 780,
+     "id": "sans-serif-background-half-production-compact-0-html-offscreen",
+     "maximumDelta": 21,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 780,
+     "id": "sans-serif-background-half-production-expanded-0-html-offscreen",
+     "maximumDelta": 21,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 780,
+     "id": "sans-serif-background-half-production-baseline-1-html-offscreen",
+     "maximumDelta": 21,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 780,
+     "id": "sans-serif-background-half-production-compact-1-html-offscreen",
+     "maximumDelta": 21,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 780,
+     "id": "sans-serif-background-half-production-expanded-1-html-offscreen",
+     "maximumDelta": 21,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 614,
+     "id": "sans-serif-background-quarter-proof-baseline-0-html-offscreen",
+     "maximumDelta": 21,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 614,
+     "id": "sans-serif-background-quarter-proof-compact-0-html-offscreen",
+     "maximumDelta": 21,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 614,
+     "id": "sans-serif-background-quarter-proof-expanded-0-html-offscreen",
+     "maximumDelta": 21,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 614,
+     "id": "sans-serif-background-quarter-proof-baseline-1-html-offscreen",
+     "maximumDelta": 21,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 614,
+     "id": "sans-serif-background-quarter-proof-compact-1-html-offscreen",
+     "maximumDelta": 21,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 614,
+     "id": "sans-serif-background-quarter-proof-expanded-1-html-offscreen",
+     "maximumDelta": 21,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 614,
+     "id": "sans-serif-background-quarter-production-baseline-0-html-offscreen",
+     "maximumDelta": 21,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 614,
+     "id": "sans-serif-background-quarter-production-compact-0-html-offscreen",
+     "maximumDelta": 21,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 614,
+     "id": "sans-serif-background-quarter-production-expanded-0-html-offscreen",
+     "maximumDelta": 21,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 614,
+     "id": "sans-serif-background-quarter-production-baseline-1-html-offscreen",
+     "maximumDelta": 21,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 614,
+     "id": "sans-serif-background-quarter-production-compact-1-html-offscreen",
+     "maximumDelta": 21,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 614,
+     "id": "sans-serif-background-quarter-production-expanded-1-html-offscreen",
+     "maximumDelta": 21,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 54,
+     "id": "sans-serif-outline-shadow-half-proof-baseline-0-html-offscreen",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 54,
+     "id": "sans-serif-outline-shadow-half-proof-compact-0-html-offscreen",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 54,
+     "id": "sans-serif-outline-shadow-half-proof-expanded-0-html-offscreen",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 54,
+     "id": "sans-serif-outline-shadow-half-proof-baseline-1-html-offscreen",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 54,
+     "id": "sans-serif-outline-shadow-half-proof-compact-1-html-offscreen",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 54,
+     "id": "sans-serif-outline-shadow-half-proof-expanded-1-html-offscreen",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 54,
+     "id": "sans-serif-outline-shadow-half-production-baseline-0-html-offscreen",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 54,
+     "id": "sans-serif-outline-shadow-half-production-compact-0-html-offscreen",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 54,
+     "id": "sans-serif-outline-shadow-half-production-expanded-0-html-offscreen",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 54,
+     "id": "sans-serif-outline-shadow-half-production-baseline-1-html-offscreen",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 54,
+     "id": "sans-serif-outline-shadow-half-production-compact-1-html-offscreen",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 54,
+     "id": "sans-serif-outline-shadow-half-production-expanded-1-html-offscreen",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 80,
+     "id": "sans-serif-outline-shadow-quarter-proof-baseline-0-html-offscreen",
+     "maximumDelta": 19,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 80,
+     "id": "sans-serif-outline-shadow-quarter-proof-compact-0-html-offscreen",
+     "maximumDelta": 19,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 80,
+     "id": "sans-serif-outline-shadow-quarter-proof-expanded-0-html-offscreen",
+     "maximumDelta": 19,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 80,
+     "id": "sans-serif-outline-shadow-quarter-proof-baseline-1-html-offscreen",
+     "maximumDelta": 19,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 80,
+     "id": "sans-serif-outline-shadow-quarter-proof-compact-1-html-offscreen",
+     "maximumDelta": 19,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 80,
+     "id": "sans-serif-outline-shadow-quarter-proof-expanded-1-html-offscreen",
+     "maximumDelta": 19,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 80,
+     "id": "sans-serif-outline-shadow-quarter-production-baseline-0-html-offscreen",
+     "maximumDelta": 19,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 80,
+     "id": "sans-serif-outline-shadow-quarter-production-compact-0-html-offscreen",
+     "maximumDelta": 19,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 80,
+     "id": "sans-serif-outline-shadow-quarter-production-expanded-0-html-offscreen",
+     "maximumDelta": 19,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 80,
+     "id": "sans-serif-outline-shadow-quarter-production-baseline-1-html-offscreen",
+     "maximumDelta": 19,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 80,
+     "id": "sans-serif-outline-shadow-quarter-production-compact-1-html-offscreen",
+     "maximumDelta": 19,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 80,
+     "id": "sans-serif-outline-shadow-quarter-production-expanded-1-html-offscreen",
+     "maximumDelta": 19,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 1098,
+     "id": "monospace-caption-canary-full-baseline-html-policy",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "context-policy",
+   },
+   Object {
+     "differingBytes": 1098,
+     "id": "monospace-caption-canary-full-baseline-offscreen-policy",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "context-policy",
+   },
+   Object {
+     "differingBytes": 1098,
+     "id": "monospace-caption-canary-full-baseline-worker-policy",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "context-policy",
+   },
+   Object {
+     "differingBytes": 1098,
+     "id": "monospace-caption-canary-full-compact-html-policy",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "context-policy",
+   },
+   Object {
+     "differingBytes": 1098,
+     "id": "monospace-caption-canary-full-compact-offscreen-policy",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "context-policy",
+   },
+   Object {
+     "differingBytes": 1098,
+     "id": "monospace-caption-canary-full-compact-worker-policy",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "context-policy",
+   },
+   Object {
+     "differingBytes": 1098,
+     "id": "monospace-caption-canary-full-expanded-html-policy",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "context-policy",
+   },
+   Object {
+     "differingBytes": 1098,
+     "id": "monospace-caption-canary-full-expanded-offscreen-policy",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "context-policy",
+   },
+   Object {
+     "differingBytes": 1098,
+     "id": "monospace-caption-canary-full-expanded-worker-policy",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "context-policy",
+   },
+   Object {
+     "differingBytes": 1098,
+     "id": "monospace-caption-canary-full-export-policy",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "context-policy",
+   },
+   Object {
+     "differingBytes": 602,
+     "id": "monospace-caption-canary-half-baseline-html-policy",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "context-policy",
+   },
+   Object {
+     "differingBytes": 602,
+     "id": "monospace-caption-canary-half-baseline-offscreen-policy",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "context-policy",
+   },
+   Object {
+     "differingBytes": 602,
+     "id": "monospace-caption-canary-half-baseline-worker-policy",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "context-policy",
+   },
+   Object {
+     "differingBytes": 602,
+     "id": "monospace-caption-canary-half-compact-html-policy",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "context-policy",
+   },
+   Object {
+     "differingBytes": 602,
+     "id": "monospace-caption-canary-half-compact-offscreen-policy",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "context-policy",
+   },
+   Object {
+     "differingBytes": 602,
+     "id": "monospace-caption-canary-half-compact-worker-policy",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "context-policy",
+   },
+   Object {
+     "differingBytes": 602,
+     "id": "monospace-caption-canary-half-expanded-html-policy",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "context-policy",
+   },
+   Object {
+     "differingBytes": 602,
+     "id": "monospace-caption-canary-half-expanded-offscreen-policy",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "context-policy",
+   },
+   Object {
+     "differingBytes": 602,
+     "id": "monospace-caption-canary-half-expanded-worker-policy",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "context-policy",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "monospace-caption-canary-quarter-proof-baseline-0-html-offscreen",
+     "maximumDelta": 1,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "monospace-caption-canary-quarter-proof-compact-0-html-offscreen",
+     "maximumDelta": 1,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "monospace-caption-canary-quarter-proof-expanded-0-html-offscreen",
+     "maximumDelta": 1,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "monospace-caption-canary-quarter-proof-baseline-1-html-offscreen",
+     "maximumDelta": 1,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "monospace-caption-canary-quarter-proof-compact-1-html-offscreen",
+     "maximumDelta": 1,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "monospace-caption-canary-quarter-proof-expanded-1-html-offscreen",
+     "maximumDelta": 1,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 428,
+     "id": "monospace-caption-canary-quarter-baseline-html-policy",
+     "maximumDelta": 4,
+     "sameLines": true,
+     "scope": "context-policy",
+   },
+   Object {
+     "differingBytes": 422,
+     "id": "monospace-caption-canary-quarter-baseline-offscreen-policy",
+     "maximumDelta": 4,
+     "sameLines": true,
+     "scope": "context-policy",
+   },
+   Object {
+     "differingBytes": 422,
+     "id": "monospace-caption-canary-quarter-baseline-worker-policy",
+     "maximumDelta": 4,
+     "sameLines": true,
+     "scope": "context-policy",
+   },
+   Object {
+     "differingBytes": 428,
+     "id": "monospace-caption-canary-quarter-compact-html-policy",
+     "maximumDelta": 4,
+     "sameLines": true,
+     "scope": "context-policy",
+   },
+   Object {
+     "differingBytes": 422,
+     "id": "monospace-caption-canary-quarter-compact-offscreen-policy",
+     "maximumDelta": 4,
+     "sameLines": true,
+     "scope": "context-policy",
+   },
+   Object {
+     "differingBytes": 422,
+     "id": "monospace-caption-canary-quarter-compact-worker-policy",
+     "maximumDelta": 4,
+     "sameLines": true,
+     "scope": "context-policy",
+   },
+   Object {
+     "differingBytes": 428,
+     "id": "monospace-caption-canary-quarter-expanded-html-policy",
+     "maximumDelta": 4,
+     "sameLines": true,
+     "scope": "context-policy",
+   },
+   Object {
+     "differingBytes": 422,
+     "id": "monospace-caption-canary-quarter-expanded-offscreen-policy",
+     "maximumDelta": 4,
+     "sameLines": true,
+     "scope": "context-policy",
+   },
+   Object {
+     "differingBytes": 422,
+     "id": "monospace-caption-canary-quarter-expanded-worker-policy",
+     "maximumDelta": 4,
+     "sameLines": true,
+     "scope": "context-policy",
+   },
+   Object {
+     "differingBytes": 12,
+     "id": "fantasy-fractional-full-proof-baseline-0-html-offscreen",
+     "maximumDelta": 38,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 12,
+     "id": "fantasy-fractional-full-proof-compact-0-html-offscreen",
+     "maximumDelta": 38,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 12,
+     "id": "fantasy-fractional-full-proof-expanded-0-html-offscreen",
+     "maximumDelta": 38,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 12,
+     "id": "fantasy-fractional-full-proof-export-0-html",
+     "maximumDelta": 38,
+     "sameLines": true,
+     "scope": "finite-export",
+   },
+   Object {
+     "differingBytes": 12,
+     "id": "fantasy-fractional-full-proof-baseline-1-html-offscreen",
+     "maximumDelta": 38,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 12,
+     "id": "fantasy-fractional-full-proof-compact-1-html-offscreen",
+     "maximumDelta": 38,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 12,
+     "id": "fantasy-fractional-full-proof-expanded-1-html-offscreen",
+     "maximumDelta": 38,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 12,
+     "id": "fantasy-fractional-full-proof-export-1-html",
+     "maximumDelta": 38,
+     "sameLines": true,
+     "scope": "finite-export",
+   },
+   Object {
+     "differingBytes": 12,
+     "id": "fantasy-fractional-full-production-baseline-0-html-offscreen",
+     "maximumDelta": 38,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 12,
+     "id": "fantasy-fractional-full-production-compact-0-html-offscreen",
+     "maximumDelta": 38,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 12,
+     "id": "fantasy-fractional-full-production-expanded-0-html-offscreen",
+     "maximumDelta": 38,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 12,
+     "id": "fantasy-fractional-full-production-export-0-html",
+     "maximumDelta": 38,
+     "sameLines": true,
+     "scope": "finite-export",
+   },
+   Object {
+     "differingBytes": 12,
+     "id": "fantasy-fractional-full-production-baseline-1-html-offscreen",
+     "maximumDelta": 38,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 12,
+     "id": "fantasy-fractional-full-production-compact-1-html-offscreen",
+     "maximumDelta": 38,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 12,
+     "id": "fantasy-fractional-full-production-expanded-1-html-offscreen",
+     "maximumDelta": 38,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 12,
+     "id": "fantasy-fractional-full-production-export-1-html",
+     "maximumDelta": 38,
+     "sameLines": true,
+     "scope": "finite-export",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "fantasy-fractional-half-proof-baseline-0-html-offscreen",
+     "maximumDelta": 9,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "fantasy-fractional-half-proof-compact-0-html-offscreen",
+     "maximumDelta": 9,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "fantasy-fractional-half-proof-expanded-0-html-offscreen",
+     "maximumDelta": 9,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "fantasy-fractional-half-proof-baseline-1-html-offscreen",
+     "maximumDelta": 9,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "fantasy-fractional-half-proof-compact-1-html-offscreen",
+     "maximumDelta": 9,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "fantasy-fractional-half-proof-expanded-1-html-offscreen",
+     "maximumDelta": 9,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "fantasy-fractional-half-production-baseline-0-html-offscreen",
+     "maximumDelta": 9,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "fantasy-fractional-half-production-compact-0-html-offscreen",
+     "maximumDelta": 9,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "fantasy-fractional-half-production-expanded-0-html-offscreen",
+     "maximumDelta": 9,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "fantasy-fractional-half-production-baseline-1-html-offscreen",
+     "maximumDelta": 9,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "fantasy-fractional-half-production-compact-1-html-offscreen",
+     "maximumDelta": 9,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "fantasy-fractional-half-production-expanded-1-html-offscreen",
+     "maximumDelta": 9,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "fantasy-fractional-quarter-proof-baseline-0-html-offscreen",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "fantasy-fractional-quarter-proof-compact-0-html-offscreen",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "fantasy-fractional-quarter-proof-expanded-0-html-offscreen",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "fantasy-fractional-quarter-proof-baseline-1-html-offscreen",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "fantasy-fractional-quarter-proof-compact-1-html-offscreen",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "fantasy-fractional-quarter-proof-expanded-1-html-offscreen",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "fantasy-fractional-quarter-production-baseline-0-html-offscreen",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "fantasy-fractional-quarter-production-compact-0-html-offscreen",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "fantasy-fractional-quarter-production-expanded-0-html-offscreen",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "fantasy-fractional-quarter-production-baseline-1-html-offscreen",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "fantasy-fractional-quarter-production-compact-1-html-offscreen",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "fantasy-fractional-quarter-production-expanded-1-html-offscreen",
+     "maximumDelta": 3,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 3,
+     "id": "fantasy-anchor-zero-quarter-proof-baseline-0-html-offscreen",
+     "maximumDelta": 1,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 3,
+     "id": "fantasy-anchor-zero-quarter-proof-compact-0-html-offscreen",
+     "maximumDelta": 1,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 3,
+     "id": "fantasy-anchor-zero-quarter-proof-expanded-0-html-offscreen",
+     "maximumDelta": 1,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 3,
+     "id": "fantasy-anchor-zero-quarter-proof-baseline-1-html-offscreen",
+     "maximumDelta": 1,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 3,
+     "id": "fantasy-anchor-zero-quarter-proof-compact-1-html-offscreen",
+     "maximumDelta": 1,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 3,
+     "id": "fantasy-anchor-zero-quarter-proof-expanded-1-html-offscreen",
+     "maximumDelta": 1,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 3,
+     "id": "fantasy-anchor-zero-quarter-production-baseline-0-html-offscreen",
+     "maximumDelta": 1,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 3,
+     "id": "fantasy-anchor-zero-quarter-production-compact-0-html-offscreen",
+     "maximumDelta": 1,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 3,
+     "id": "fantasy-anchor-zero-quarter-production-expanded-0-html-offscreen",
+     "maximumDelta": 1,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 3,
+     "id": "fantasy-anchor-zero-quarter-production-baseline-1-html-offscreen",
+     "maximumDelta": 1,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 3,
+     "id": "fantasy-anchor-zero-quarter-production-compact-1-html-offscreen",
+     "maximumDelta": 1,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 3,
+     "id": "fantasy-anchor-zero-quarter-production-expanded-1-html-offscreen",
+     "maximumDelta": 1,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "fantasy-anchor-one-quarter-proof-baseline-0-html-offscreen",
+     "maximumDelta": 2,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "fantasy-anchor-one-quarter-proof-compact-0-html-offscreen",
+     "maximumDelta": 2,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "fantasy-anchor-one-quarter-proof-expanded-0-html-offscreen",
+     "maximumDelta": 2,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "fantasy-anchor-one-quarter-proof-baseline-1-html-offscreen",
+     "maximumDelta": 2,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "fantasy-anchor-one-quarter-proof-compact-1-html-offscreen",
+     "maximumDelta": 2,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "fantasy-anchor-one-quarter-proof-expanded-1-html-offscreen",
+     "maximumDelta": 2,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "fantasy-anchor-one-quarter-production-baseline-0-html-offscreen",
+     "maximumDelta": 2,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "fantasy-anchor-one-quarter-production-compact-0-html-offscreen",
+     "maximumDelta": 2,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "fantasy-anchor-one-quarter-production-expanded-0-html-offscreen",
+     "maximumDelta": 2,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "fantasy-anchor-one-quarter-production-baseline-1-html-offscreen",
+     "maximumDelta": 2,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "fantasy-anchor-one-quarter-production-compact-1-html-offscreen",
+     "maximumDelta": 2,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+   Object {
+     "differingBytes": 6,
+     "id": "fantasy-anchor-one-quarter-production-expanded-1-html-offscreen",
+     "maximumDelta": 2,
+     "sameLines": true,
+     "scope": "same-realm-canvas-kind",
+   },
+ ]
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - region [ref=e4]:
    - generic [ref=e5]:
      - generic [ref=e6]:
        - heading "Plugin safety" [level=2] [ref=e7]
        - paragraph [ref=e8]: Start without loading third-party plugins. Built-in effects and saved plugin records stay available.
      - generic [ref=e9]:
        - button "Enter safe mode" [ref=e11] [cursor=pointer]
        - paragraph [ref=e12]: Installed plugins aren't checked here. Safe mode keeps every third-party package inactive.
  - main [ref=e13]:
    - generic [ref=e14]:
      - region [ref=e15]:
        - generic [ref=e17]:
          - strong [ref=e18]:
            - generic [ref=e19]: Myrelith
            - generic [ref=e20]:
              - generic [ref=e21]: M
              - generic [ref=e23]: "y"
              - generic [ref=e25]: r
              - generic [ref=e27]: e
              - generic [ref=e29]: l
              - generic [ref=e31]: i
              - generic [ref=e33]: t
              - generic [ref=e35]: h
          - generic [ref=e37]: Browser video editor
        - generic [ref=e38]:
          - heading "Your footage. Your space. Your cut." [level=1] [ref=e39]:
            - generic [ref=e41]:
              - generic [ref=e42]:
                - generic [ref=e43]: "Y"
                - generic [ref=e44]: o
                - generic [ref=e45]: u
                - generic [ref=e46]: r
                - generic [ref=e48]: f
                - generic [ref=e49]: o
                - generic [ref=e50]: o
                - generic [ref=e51]: t
                - generic [ref=e52]: a
                - generic [ref=e53]: g
                - generic [ref=e54]: e
                - generic [ref=e55]: .
              - generic [ref=e56]:
                - generic [ref=e57]: "Y"
                - generic [ref=e58]: o
                - generic [ref=e59]: u
                - generic [ref=e60]: r
                - generic [ref=e62]: s
                - generic [ref=e63]: p
                - generic [ref=e64]: a
                - generic [ref=e65]: c
                - generic [ref=e66]: e
                - generic [ref=e67]: .
              - generic [ref=e68]:
                - generic [ref=e69]: "Y"
                - generic [ref=e70]: o
                - generic [ref=e71]: u
                - generic [ref=e72]: r
                - generic [ref=e74]: c
                - generic [ref=e75]: u
                - generic [ref=e76]: t
                - generic [ref=e77]: .
          - paragraph [ref=e78]: Edit locally in your browser—no upload, no account, no rush.
          - generic "Project actions" [ref=e79]:
            - button [ref=e80] [cursor=pointer]:
              - strong [ref=e83]: Start a new project
            - button [ref=e86] [cursor=pointer]:
              - strong [ref=e89]: Open a project
        - figure "From first frame to final cut." [ref=e90]:
          - img "A traveler looking over a rugged coast at dusk" [ref=e91]
      - region [ref=e93]:
        - generic [ref=e94]:
          - heading "Back to your projects" [level=2] [ref=e96]
          - button "Refresh" [ref=e98] [cursor=pointer]
        - tablist "Project library" [ref=e102]:
          - tab "Recent projects" [selected] [ref=e103] [cursor=pointer]
          - tab "Recovery copies, 0" [ref=e104] [cursor=pointer]:
            - generic [ref=e105]: Recovery copies
            - generic [ref=e106]: "0"
        - tabpanel "Recent projects" [ref=e107]:
          - paragraph [ref=e108]: No recent project shortcuts yet.
        - region [ref=e109]:
          - generic [ref=e110]:
            - generic [ref=e111]:
              - heading "Local storage" [level=3] [ref=e112]
              - paragraph [ref=e113]: Project files stay separate from browser recovery and cache.
            - strong [ref=e114]: 0 B of 10 GB
          - generic [ref=e115]:
            - generic [ref=e116]:
              - term [ref=e117]:
                - generic [ref=e121]: Project files
              - definition [ref=e122]: Portable .myrelith · on your disk
            - generic [ref=e123]:
              - term [ref=e124]:
                - generic [ref=e128]: Recovery
              - definition [ref=e129]: 0 copies · 0 B protected
            - generic [ref=e130]:
              - term [ref=e131]:
                - generic [ref=e135]: Remembered access
              - definition [ref=e136]: 0 project shortcuts · files aren't copied
            - generic [ref=e137]:
              - term [ref=e138]:
                - generic [ref=e142]: Cache & proxies
              - definition [ref=e143]: 0 B · empty
              - button "Clear disposable data" [disabled] [ref=e144]: Clear cache & proxies
          - paragraph [ref=e145]: Projects and source media stay on your device. Recovery copies contain no source media; cache and proxies are disposable.
    - generic [ref=e146]:
      - generic [ref=e147]: Private by design. Portable by default.
      - navigation "Project information" [ref=e148]:
        - link "Privacy" [ref=e149] [cursor=pointer]:
          - /url: /privacy/
        - link "Licenses" [ref=e150] [cursor=pointer]:
          - /url: /licenses/
        - link "GitHub" [ref=e151] [cursor=pointer]:
          - /url: https://github.com/zyfvhcfh87-rgb/Myrelith
```

# Test source

```ts
  25  |   await page.exposeFunction('persistTitleCanvasDiagnostic', async (id: string, sample: Omit<DiagnosticSample, 'pixels'> & { pixels: Omit<DiagnosticSample['pixels'], 'rgba'>; rgbaBase64: string }) => {
  26  |     if (!/^[a-z0-9-]+$/.test(id)) throw new Error('Invalid diagnostic sample ID')
  27  |     const { rgbaBase64, ...metadata } = sample, rgba = Buffer.from(rgbaBase64, 'base64')
  28  |     expect(rgba.length, id).toBe(metadata.pixels.width * metadata.pixels.height * 4)
  29  |     const fixturePin = pins.fixtures.find((pin: { id: string }) => id.startsWith(`${pin.id}-`))
  30  |     expect(fixturePin, id).toBeDefined()
  31  |     expect(metadata.fixtureSha256, id).toBe(id.includes('-expanded-') || id.includes('-export-') ? fixturePin.expanded : fixturePin.legacy)
  32  |     // wx preserves partial evidence if a sample ID ever repeats unexpectedly.
  33  |     await writeFile(join(samples, `${id}.rgba.gz`), gzipSync(rgba), { flag: 'wx' })
  34  |     await writeFile(join(samples, `${id}.json`), JSON.stringify({ ...metadata, rgbaSha256: hash(rgba), rgbaBytes: rgba.length }, null, 2), { flag: 'wx' })
  35  |     sampleCount++
  36  |   })
  37  |   await page.goto('/')
  38  |   let result: unknown
  39  |   try {
  40  |     result = await page.evaluate(async (fixturesJson) => {
  41  |       const fixtures = JSON.parse(fixturesJson) as ReturnType<typeof diagnosticFixtures>
  42  |       const clientPath = '/tests/diagnostics/issue200/client.ts'
  43  |       const { diagnosticSample, openDiagnosticWorker } = await import(clientPath) as typeof import('./client')
  44  |       const proofPath = '/src/test/titleRenderProof.ts'
  45  |       const { compareTitleProof } = await import(proofPath) as typeof import('../../../src/test/titleRenderProof')
  46  |       const worker = openDiagnosticWorker()
  47  |       const comparisons: { id: string; scope: string; differingBytes: number; maximumDelta: number; sameLines: boolean }[] = []
  48  |       let completedSamples = 0, disposalAcknowledged = false
  49  |       const persist = (globalThis as unknown as { persistTitleCanvasDiagnostic(id: string, sample: unknown): Promise<void> }).persistTitleCanvasDiagnostic
  50  |       function compare(id: string, scope: string, a: DiagnosticSample, b: DiagnosticSample) {
  51  |         const value = { id, scope, ...compareTitleProof(a.pixels, b.pixels) }
  52  |         comparisons.push(value)
  53  |         return value.differingBytes === 0 && value.maximumDelta === 0 && value.sameLines
  54  |       }
  55  |       async function save(id: string, sample: DiagnosticSample) {
  56  |         const { rgba, ...pixels } = sample.pixels
  57  |         let bytes = ''
  58  |         for (let offset = 0; offset < rgba.length; offset += 8192) bytes += String.fromCharCode(...rgba.subarray(offset, offset + 8192))
  59  |         await persist(id, { ...sample, pixels, rgbaBase64: btoa(bytes) })
  60  |         completedSamples++
  61  |         if (!pixels.scratchCleared || pixels.requests !== 0 || pixels.liveCanvases !== 0 || pixels.peakCanvases > 3) throw new Error(`Ownership failure: ${id}`)
  62  |         if (sample.exportOwnership && (sample.exportOwnership.leases !== 1 || sample.exportOwnership.closed !== 1 || !sample.exportOwnership.finalized)) throw new Error(`Export ownership failure: ${id}`)
  63  |       }
  64  |       try {
  65  |         for (const fixture of fixtures) for (const quality of ['full', 'half', 'quarter'] as const) {
  66  |           const policies = new Map<string, Map<string, DiagnosticSample>>()
  67  |           for (const canvasPolicy of ['proof', 'production'] as const) {
  68  |             const first = new Map<string, DiagnosticSample>(); policies.set(canvasPolicy, first)
  69  |             for (const repeat of [0, 1]) {
  70  |               const current = new Map<string, DiagnosticSample>()
  71  |               for (const variant of ['baseline', 'compact', 'expanded'] as const) for (const host of ['html', 'offscreen', 'worker'] as const) {
  72  |                 const request = { project: variant === 'expanded' ? fixture.expanded : fixture.legacy,
  73  |                   renderer: variant === 'baseline' ? 'baseline' as const : 'current' as const, quality, offscreen: host !== 'html', canvasPolicy }
  74  |                 const id = `${fixture.id}-${quality}-${canvasPolicy}-${variant}-${host}-${repeat}`
  75  |                 const sample = host === 'worker' ? await worker.sample(request) : await diagnosticSample(request)
  76  |                 await save(id, sample); current.set(`${variant}-${host}`, sample)
  77  |                 if (repeat === 0) first.set(`${variant}-${host}`, sample)
  78  |                 else if (!compare(id, 'repeat', first.get(`${variant}-${host}`)!, sample)) throw new Error(`Nondeterministic sample: ${id}`)
  79  |               }
  80  |               // Persist all samples in this cell before stopping on a newly measured renderer regression.
  81  |               for (const host of ['html', 'offscreen', 'worker']) {
  82  |                 const id = `${fixture.id}-${quality}-${canvasPolicy}-${host}-${repeat}`
  83  |                 if (!compare(`${id}-baseline-compact`, 'same-host-renderer', current.get(`baseline-${host}`)!, current.get(`compact-${host}`)!)) throw new Error(`Baseline/current mismatch: ${id}`)
  84  |                 if (!compare(`${id}-compact-expanded`, 'same-host-upgrade', current.get(`compact-${host}`)!, current.get(`expanded-${host}`)!)) throw new Error(`Upgrade mismatch: ${id}`)
  85  |               }
  86  |               for (const variant of ['baseline', 'compact', 'expanded']) {
  87  |                 const id = `${fixture.id}-${quality}-${canvasPolicy}-${variant}-${repeat}`
  88  |                 compare(`${id}-html-offscreen`, 'same-realm-canvas-kind', current.get(`${variant}-html`)!, current.get(`${variant}-offscreen`)!)
  89  |                 compare(`${id}-offscreen-worker`, 'same-kind-realm', current.get(`${variant}-offscreen`)!, current.get(`${variant}-worker`)!)
  90  |               }
  91  |               if (quality === 'full') {
  92  |                 const id = `${fixture.id}-${quality}-${canvasPolicy}-export-${repeat}`
  93  |                 const exported = await diagnosticSample({ project: fixture.expanded, renderer: 'current', quality, offscreen: true, canvasPolicy, export: true })
  94  |                 await save(id, exported)
  95  |                 if (repeat === 0) first.set('export', exported)
  96  |                 else if (!compare(id, 'export-repeat', first.get('export')!, exported)) throw new Error(`Nondeterministic export: ${id}`)
  97  |                 for (const host of ['html', 'offscreen', 'worker']) compare(`${id}-${host}`, 'finite-export', current.get(`expanded-${host}`)!, exported)
  98  |               }
  99  |             }
  100 |           }
  101 |           for (const [key, original] of policies.get('proof')!) compare(`${fixture.id}-${quality}-${key}-policy`, 'context-policy', original, policies.get('production')!.get(key)!)
  102 |         }
  103 |       } finally {
  104 |         try { await worker.close(); disposalAcknowledged = true } finally {
  105 |           // Even an early integrity/renderer stop retains the comparisons already made.
  106 |           await (globalThis as unknown as { persistTitleCanvasDiagnosticSummary(value: unknown): Promise<void> }).persistTitleCanvasDiagnosticSummary({ comparisons, completedSamples, disposalAcknowledged })
  107 |         }
  108 |       }
  109 |       return { comparisons, completedSamples, disposalAcknowledged }
  110 |     }, JSON.stringify(fixtures))
  111 |   } finally {
  112 |     const body = await page.locator('body').innerText()
  113 |     const identity = { url: page.url(), title: await page.title(), viewport: page.viewportSize(), bodyTextLength: body.trim().length,
  114 |       bodyBounds: await page.locator('body').boundingBox(), viteErrorOverlays: await page.locator('vite-error-overlay').count() }
  115 |     await page.screenshot({ path: info.outputPath('diagnostic-page.png') })
  116 |     await writeFile(info.outputPath('browser-observations.json'), JSON.stringify({ browser: browser.version(), platform: process.platform, arch: process.arch, identity, warnings, errors, pageErrors, sampleCount }, null, 2))
  117 |     expect(identity.url).toBe('http://127.0.0.1:5200/')
  118 |     expect(identity.title).toMatch(/Myrelith/); expect(identity.bodyTextLength).toBeGreaterThan(50)
  119 |     expect(identity.bodyBounds?.height).toBeGreaterThan(0); expect(identity.viteErrorOverlays).toBe(0)
  120 |   }
  121 |   const completed = result as { comparisons: { differingBytes: number; maximumDelta: number; sameLines: boolean }[]; completedSamples: number; disposalAcknowledged: boolean }
  122 |   expect(completed.comparisons).toHaveLength(2160); expect(completed.completedSamples).toBe(1008); expect(sampleCount).toBe(1008); expect(completed.disposalAcknowledged).toBe(true)
  123 |   expect(errors).toEqual([]); expect(pageErrors).toEqual([])
  124 |   // A completed diagnostic is never silently promoted to a parity pass.
> 125 |   expect(completed.comparisons.filter((row) => row.differingBytes !== 0 || row.maximumDelta !== 0 || !row.sameLines), 'Exact-zero diagnostic discrepancies; see saved raw samples').toEqual([])
      |                                                                                                                                                                                     ^ Error: Exact-zero diagnostic discrepancies; see saved raw samples
  126 | })
  127 | 
  128 | test.beforeEach(async ({ page }, info) => {
  129 |   await page.exposeFunction('persistTitleCanvasDiagnosticSummary', async (value: unknown) => {
  130 |     await writeFile(info.outputPath('diagnostic-comparisons.json'), JSON.stringify(value, null, 2))
  131 |   })
  132 | })
  133 | 
```